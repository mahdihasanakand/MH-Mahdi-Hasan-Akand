var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// node_modules/@netlify/runtime-utils/dist/main.cjs
var require_main = __commonJS({
  "node_modules/@netlify/runtime-utils/dist/main.cjs"(exports2, module2) {
    "use strict";
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var main_exports = {};
    __export(main_exports, {
      base64Decode: () => base64Decode,
      base64Encode: () => base64Encode,
      getEnvironment: () => getEnvironment
    });
    module2.exports = __toCommonJS(main_exports);
    var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
    var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
    var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));
    var getEnvironment = () => {
      const { Deno, Netlify, process: process2 } = globalThis;
      return Netlify?.env ?? Deno?.env ?? {
        delete: (key) => delete process2?.env[key],
        get: (key) => process2?.env[key],
        has: (key) => Boolean(process2?.env[key]),
        set: (key, value) => {
          if (process2?.env) {
            process2.env[key] = value;
          }
        },
        toObject: () => process2?.env ?? {}
      };
    };
  }
});

// node_modules/@netlify/otel/dist/main.cjs
var require_main2 = __commonJS({
  "node_modules/@netlify/otel/dist/main.cjs"(exports2, module2) {
    "use strict";
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var main_exports = {};
    __export(main_exports, {
      getTracer: () => getTracer,
      shutdownTracers: () => shutdownTracers,
      withActiveSpan: () => withActiveSpan
    });
    module2.exports = __toCommonJS(main_exports);
    var GET_TRACER = "__netlify__getTracer";
    var SHUTDOWN_TRACERS = "__netlify__shutdownTracers";
    var getTracer = (name, version) => {
      return globalThis[GET_TRACER]?.(name, version);
    };
    var shutdownTracers = async () => {
      return globalThis[SHUTDOWN_TRACERS]?.();
    };
    function withActiveSpan(tracer, name, optionsOrFn, contextOrFn, fn) {
      const func = typeof contextOrFn === "function" ? contextOrFn : typeof optionsOrFn === "function" ? optionsOrFn : fn;
      if (!func) {
        throw new Error("function to execute with active span is missing");
      }
      if (!tracer) {
        return func();
      }
      return tracer.withActiveSpan(name, optionsOrFn, contextOrFn, func);
    }
  }
});

// node_modules/@netlify/blobs/dist/main.cjs
var require_main3 = __commonJS({
  "node_modules/@netlify/blobs/dist/main.cjs"(exports2, module2) {
    "use strict";
    var __create = Object.create;
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __getProtoOf = Object.getPrototypeOf;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
      // If the importer is in node compatibility mode or this is not an ESM
      // file that has been converted to a CommonJS file using a Babel-
      // compatible transform (i.e. "__esModule" has not been set), then set
      // "default" to the CommonJS "module.exports" for node compatibility.
      isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
      mod
    ));
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var main_exports = {};
    __export(main_exports, {
      connectLambda: () => connectLambda2,
      getDeployStore: () => getDeployStore,
      getStore: () => getStore2,
      listStores: () => listStores,
      setEnvironmentContext: () => setEnvironmentContext
    });
    module2.exports = __toCommonJS(main_exports);
    var import_runtime_utils = require_main();
    var getEnvironmentContext = () => {
      const context = globalThis.netlifyBlobsContext || (0, import_runtime_utils.getEnvironment)().get("NETLIFY_BLOBS_CONTEXT");
      if (typeof context !== "string" || !context) {
        return {};
      }
      const data = (0, import_runtime_utils.base64Decode)(context);
      try {
        return JSON.parse(data);
      } catch {
      }
      return {};
    };
    var setEnvironmentContext = (context) => {
      const encodedContext = (0, import_runtime_utils.base64Encode)(JSON.stringify(context));
      (0, import_runtime_utils.getEnvironment)().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
    };
    var MissingBlobsEnvironmentError = class extends Error {
      constructor(requiredProperties) {
        super(
          `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
            ", "
          )}`
        );
        this.name = "MissingBlobsEnvironmentError";
      }
    };
    var import_runtime_utils2 = require_main();
    var connectLambda2 = (event) => {
      const rawData = (0, import_runtime_utils2.base64Decode)(event.blobs);
      const data = JSON.parse(rawData);
      const environmentContext = {
        deployID: event.headers["x-nf-deploy-id"],
        edgeURL: data.url,
        siteID: event.headers["x-nf-site-id"],
        token: data.token
      };
      setEnvironmentContext(environmentContext);
    };
    var BlobsConsistencyError = class extends Error {
      constructor() {
        super(
          `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
        );
        this.name = "BlobsConsistencyError";
      }
    };
    var import_runtime_utils3 = require_main();
    var BASE64_PREFIX = "b64;";
    var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
    var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
    var METADATA_MAX_SIZE = 2 * 1024;
    var encodeMetadata = (metadata) => {
      if (!metadata) {
        return null;
      }
      const encodedObject = (0, import_runtime_utils3.base64Encode)(JSON.stringify(metadata));
      const payload = `b64;${encodedObject}`;
      if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
        throw new Error("Metadata object exceeds the maximum size");
      }
      return payload;
    };
    var decodeMetadata = (header) => {
      if (!header?.startsWith(BASE64_PREFIX)) {
        return {};
      }
      const encodedData = header.slice(BASE64_PREFIX.length);
      const decodedData = (0, import_runtime_utils3.base64Decode)(encodedData);
      const metadata = JSON.parse(decodedData);
      return metadata;
    };
    var getMetadataFromResponse = (response) => {
      if (!response.headers) {
        return {};
      }
      const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
      try {
        return decodeMetadata(value);
      } catch {
        throw new Error(
          "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
        );
      }
    };
    var REGION_AUTO = "auto";
    var regions = {
      "us-east-1": true,
      "us-east-2": true,
      "eu-central-1": true,
      "ap-southeast-1": true,
      "ap-southeast-2": true
    };
    var isValidRegion = (input) => Object.keys(regions).includes(input);
    var InvalidBlobsRegionError = class extends Error {
      constructor(region) {
        super(
          `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
        );
        this.name = "InvalidBlobsRegionError";
      }
    };
    var import_runtime_utils4 = require_main();
    var import_node_process = __toESM(require("process"), 1);
    var import_otel = require_main2();
    var NF_ERROR = "x-nf-error";
    var NF_REQUEST_ID = "x-nf-request-id";
    var DEPLOY_STORE_PREFIX = "deploy:";
    var SITE_STORE_PREFIX = "site:";
    var isDeniedWrite = (res, { method, storeName }) => (res.status === 401 || res.status === 403) && (method === "put" || method === "delete") && storeName !== void 0 && !storeName.startsWith(DEPLOY_STORE_PREFIX);
    var blobsErrorMessage = (res, context, responseBody) => {
      let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
      if (res.headers.has(NF_REQUEST_ID)) {
        details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
      }
      if (isDeniedWrite(res, context)) {
        const storeName = context.storeName?.startsWith(SITE_STORE_PREFIX) ? context.storeName.slice(SITE_STORE_PREFIX.length) : context.storeName;
        const summary = `Netlify Blobs could not write to store '${storeName}' (${details}).`;
        if (context.edgeAccess) {
          return summary;
        }
        return `${summary} Builds and build plugins can only write to deploy-specific stores: use 'getDeployStore' instead of 'getStore', or pass a 'token' with write access to the store. If this code is not running in a build, check that the token and site ID are valid. See https://docs.netlify.com/build/data-and-storage/netlify-blobs/#deploy-specific-stores`;
      }
      let message = `Netlify Blobs has generated an internal error (${details})`;
      if (!res.headers.get(NF_ERROR) && responseBody) {
        message += `: ${responseBody}`;
      }
      return message;
    };
    var BlobsInternalError = class extends Error {
      constructor(res, context = {}, responseBody) {
        super(blobsErrorMessage(res, context, responseBody));
        this.name = "BlobsInternalError";
        this.status = res.status;
        this.responseBody = responseBody;
      }
    };
    var createBlobsInternalError = async (res, context = {}) => {
      const responseBody = await res.clone().text().catch(() => void 0);
      return new BlobsInternalError(res, context, responseBody);
    };
    var discardBody = async (res) => {
      await res.body?.cancel().catch(() => {
      });
    };
    var collectIterator = async (iterator) => {
      const result = [];
      for await (const item of iterator) {
        result.push(item);
      }
      return result;
    };
    function withSpan(span, name, fn) {
      if (span) return fn(span);
      return (0, import_otel.withActiveSpan)((0, import_otel.getTracer)(), name, (span2) => {
        return fn(span2);
      });
    }
    var DEFAULT_RETRY_DELAY = (0, import_runtime_utils4.getEnvironment)().get("NODE_ENV") === "test" ? 1 : 5e3;
    var MIN_RETRY_DELAY = 1e3;
    var MAX_RETRY = 5;
    var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
    var fetchAndRetry = async (fetch, url, options, attemptsLeft = MAX_RETRY, getRetryUrl) => {
      try {
        const res = await fetch(url, options);
        const isRetryable = res.status === 429 || res.status >= 500 || getRetryUrl !== void 0 && res.status === 403;
        if (attemptsLeft > 0 && isRetryable) {
          await discardBody(res);
          const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
          await sleep(delay);
          const retryUrl = getRetryUrl ? await getRetryUrl() : url;
          return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
        }
        return res;
      } catch (error) {
        if (attemptsLeft === 0) {
          throw error;
        }
        const delay = getDelay();
        await sleep(delay);
        const retryUrl = getRetryUrl ? await getRetryUrl() : url;
        return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
      }
    };
    var getDelay = (rateLimitReset) => {
      if (!rateLimitReset) {
        return DEFAULT_RETRY_DELAY;
      }
      return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
    };
    var sleep = (ms) => new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
    var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
    var Client = class {
      /**
       * Whether requests reach Blobs through the edge rather than the API. Only
       * runtime environments are given an edge URL.
       */
      get edgeAccess() {
        return this.edgeURL !== void 0;
      }
      constructor({ apiURL, consistency, edgeURL, fetch, region, siteID, token, uncachedEdgeURL }) {
        this.apiURL = apiURL;
        this.consistency = consistency ?? "eventual";
        this.edgeURL = edgeURL;
        this.fetch = fetch ?? globalThis.fetch;
        this.region = region;
        this.siteID = siteID;
        this.token = token;
        this.uncachedEdgeURL = uncachedEdgeURL;
        if (!this.fetch) {
          throw new Error(
            "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
          );
        }
      }
      async getFinalRequest({
        consistency: opConsistency,
        key,
        metadata,
        method,
        parameters = {},
        storeName
      }) {
        const encodedMetadata = encodeMetadata(metadata);
        const consistency = opConsistency ?? this.consistency;
        let urlPath = `/${this.siteID}`;
        if (storeName) {
          urlPath += `/${storeName}`;
        }
        if (key) {
          urlPath += `/${key}`;
        }
        if (this.edgeURL) {
          if (consistency === "strong" && !this.uncachedEdgeURL) {
            throw new BlobsConsistencyError();
          }
          const headers = {
            authorization: `Bearer ${this.token}`
          };
          if (encodedMetadata) {
            headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
          }
          if (this.region) {
            urlPath = `/region:${this.region}${urlPath}`;
          }
          const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
          for (const key2 in parameters) {
            url2.searchParams.set(key2, parameters[key2]);
          }
          return {
            headers,
            url: url2.toString()
          };
        }
        const apiHeaders = { authorization: `Bearer ${this.token}` };
        const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
        for (const key2 in parameters) {
          url.searchParams.set(key2, parameters[key2]);
        }
        if (this.region) {
          url.searchParams.set("region", this.region);
        }
        if (storeName === void 0 || key === void 0) {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        if (encodedMetadata) {
          apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
        }
        if (method === "head" || method === "delete") {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        const res = await this.fetch(url.toString(), {
          headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
          method
        });
        if (res.status !== 200) {
          throw await createBlobsInternalError(res, { edgeAccess: this.edgeAccess, method, storeName });
        }
        const { url: signedURL } = await res.json();
        const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
        return {
          headers: userHeaders,
          url: signedURL
        };
      }
      async makeRequest({
        body,
        conditions = {},
        consistency,
        headers: extraHeaders,
        key,
        metadata,
        method,
        parameters,
        storeName
      }) {
        const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
          consistency,
          key,
          metadata,
          method,
          parameters,
          storeName
        });
        const headers = {
          ...baseHeaders,
          ...extraHeaders
        };
        if (method === "put") {
          headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
        }
        if ("onlyIfMatch" in conditions && conditions.onlyIfMatch) {
          headers["if-match"] = conditions.onlyIfMatch;
        } else if ("onlyIfNew" in conditions && conditions.onlyIfNew) {
          headers["if-none-match"] = "*";
        }
        const options = {
          body,
          headers,
          method
        };
        if (body instanceof ReadableStream) {
          options.duplex = "half";
        }
        const usesSignedUrl = !this.edgeURL && key !== void 0 && storeName !== void 0 && method !== "head" && method !== "delete";
        let getRetryUrl;
        if (usesSignedUrl) {
          getRetryUrl = async () => {
            const finalRequest = await this.getFinalRequest({ consistency, key, metadata, method, parameters, storeName });
            return finalRequest.url;
          };
        }
        return fetchAndRetry(this.fetch, url, options, void 0, getRetryUrl);
      }
    };
    var getClientOptions = (options, contextOverride) => {
      const context = contextOverride ?? getEnvironmentContext();
      const siteID = context.siteID ?? options.siteID;
      const token = context.token ?? options.token;
      if (!siteID || !token) {
        throw new MissingBlobsEnvironmentError(["siteID", "token"]);
      }
      if (options.region !== void 0 && !isValidRegion(options.region)) {
        throw new InvalidBlobsRegionError(options.region);
      }
      const clientOptions = {
        apiURL: context.apiURL ?? options.apiURL,
        consistency: options.consistency,
        edgeURL: context.edgeURL ?? options.edgeURL,
        fetch: options.fetch,
        region: options.region,
        siteID,
        token,
        uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
      };
      return clientOptions;
    };
    var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
    var STATUS_OK = 200;
    var STATUS_PRE_CONDITION_FAILED = 412;
    var Store = class _Store {
      constructor(options) {
        this.client = options.client;
        if ("deployID" in options) {
          _Store.validateDeployID(options.deployID);
          let name = DEPLOY_STORE_PREFIX + options.deployID;
          if (options.name) {
            name += `:${options.name}`;
          }
          this.name = name;
        } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
          const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
          _Store.validateStoreName(storeName);
          this.name = storeName;
        } else {
          _Store.validateStoreName(options.name);
          this.name = SITE_STORE_PREFIX + options.name;
        }
      }
      async delete(key) {
        const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
        await discardBody(res);
        if (![200, 204, 404].includes(res.status)) {
          throw new BlobsInternalError(res, {
            edgeAccess: this.client.edgeAccess,
            method: "delete",
            storeName: this.name
          });
        }
      }
      async deleteAll() {
        let totalDeletedBlobs = 0;
        let hasMore = true;
        while (hasMore) {
          const res = await this.client.makeRequest({ method: "delete", storeName: this.name });
          if (res.status !== 200) {
            await discardBody(res);
            throw new BlobsInternalError(res, {
              edgeAccess: this.client.edgeAccess,
              method: "delete",
              storeName: this.name
            });
          }
          const data = await res.json();
          if (typeof data.blobs_deleted !== "number") {
            throw new BlobsInternalError(res);
          }
          totalDeletedBlobs += data.blobs_deleted;
          hasMore = typeof data.has_more === "boolean" && data.has_more;
        }
        return {
          deletedBlobs: totalDeletedBlobs
        };
      }
      async get(key, options) {
        return withSpan(options?.span, "blobs.get", async (span) => {
          const { consistency, type } = options ?? {};
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.key": key,
            "blobs.type": type,
            "blobs.method": "GET",
            "blobs.consistency": consistency
          });
          const res = await this.client.makeRequest({
            consistency,
            key,
            method: "get",
            storeName: this.name
          });
          span?.setAttributes({
            "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
            "blobs.response.status": res.status
          });
          if (res.status === 404) {
            await discardBody(res);
            return null;
          }
          if (res.status !== 200) {
            await discardBody(res);
            throw new BlobsInternalError(res);
          }
          if (type === void 0 || type === "text") {
            return res.text();
          }
          if (type === "arrayBuffer") {
            return res.arrayBuffer();
          }
          if (type === "blob") {
            return res.blob();
          }
          if (type === "json") {
            return res.json();
          }
          if (type === "stream") {
            return res.body;
          }
          await discardBody(res);
          throw new BlobsInternalError(res);
        });
      }
      async getMetadata(key, options = {}) {
        return withSpan(options?.span, "blobs.getMetadata", async (span) => {
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.key": key,
            "blobs.method": "HEAD",
            "blobs.consistency": options.consistency
          });
          const res = await this.client.makeRequest({
            consistency: options.consistency,
            key,
            method: "head",
            storeName: this.name
          });
          span?.setAttributes({
            "blobs.response.status": res.status
          });
          if (res.status === 404) {
            return null;
          }
          if (res.status !== 200 && res.status !== 304) {
            throw new BlobsInternalError(res);
          }
          const etag = res?.headers.get("etag") ?? void 0;
          const metadata = getMetadataFromResponse(res);
          const result = {
            etag,
            metadata
          };
          return result;
        });
      }
      async getWithMetadata(key, options) {
        return withSpan(options?.span, "blobs.getWithMetadata", async (span) => {
          const { consistency, etag: requestETag, type } = options ?? {};
          const headers = requestETag ? { "if-none-match": requestETag } : void 0;
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.key": key,
            "blobs.method": "GET",
            "blobs.consistency": options?.consistency,
            "blobs.type": type,
            "blobs.request.etag": requestETag
          });
          const res = await this.client.makeRequest({
            consistency,
            headers,
            key,
            method: "get",
            storeName: this.name
          });
          const responseETag = res?.headers.get("etag") ?? void 0;
          span?.setAttributes({
            "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
            "blobs.response.etag": responseETag,
            "blobs.response.status": res.status
          });
          if (res.status === 404) {
            await discardBody(res);
            return null;
          }
          if (res.status !== 200 && res.status !== 304) {
            await discardBody(res);
            throw new BlobsInternalError(res);
          }
          const metadata = getMetadataFromResponse(res);
          const result = {
            etag: responseETag,
            metadata
          };
          if (res.status === 304 && requestETag) {
            return { data: null, ...result };
          }
          if (type === void 0 || type === "text") {
            return { data: await res.text(), ...result };
          }
          if (type === "arrayBuffer") {
            return { data: await res.arrayBuffer(), ...result };
          }
          if (type === "blob") {
            return { data: await res.blob(), ...result };
          }
          if (type === "json") {
            return { data: await res.json(), ...result };
          }
          if (type === "stream") {
            return { data: res.body, ...result };
          }
          await discardBody(res);
          throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
        });
      }
      list(options = {}) {
        return withSpan(options.span, "blobs.list", (span) => {
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.method": "GET",
            "blobs.list.paginate": options.paginate ?? false
          });
          const iterator = this.getListIterator(options);
          if (options.paginate) {
            return iterator;
          }
          return collectIterator(iterator).then(
            (items) => items.reduce(
              (acc, item) => ({
                blobs: [...acc.blobs, ...item.blobs],
                directories: [...acc.directories, ...item.directories]
              }),
              { blobs: [], directories: [] }
            )
          );
        });
      }
      async set(key, data, options = {}) {
        return withSpan(options.span, "blobs.set", async (span) => {
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.key": key,
            "blobs.method": "PUT",
            "blobs.data.size": typeof data == "string" ? data.length : data instanceof Blob ? data.size : data.byteLength,
            "blobs.data.type": typeof data == "string" ? "string" : data instanceof Blob ? "blob" : "arrayBuffer",
            "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
          });
          _Store.validateKey(key);
          const conditions = _Store.getConditions(options);
          const res = await this.client.makeRequest({
            conditions,
            body: data,
            key,
            metadata: options.metadata,
            method: "put",
            storeName: this.name
          });
          const etag = res.headers.get("etag") ?? "";
          span?.setAttributes({
            "blobs.response.etag": etag,
            "blobs.response.status": res.status
          });
          if (conditions) {
            await discardBody(res);
            return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
          }
          if (res.status === STATUS_OK) {
            await discardBody(res);
            return {
              etag,
              modified: true
            };
          }
          throw await createBlobsInternalError(res, {
            edgeAccess: this.client.edgeAccess,
            method: "put",
            storeName: this.name
          });
        });
      }
      async setJSON(key, data, options = {}) {
        return withSpan(options.span, "blobs.setJSON", async (span) => {
          span?.setAttributes({
            "blobs.store": this.name,
            "blobs.key": key,
            "blobs.method": "PUT",
            "blobs.data.type": "json",
            "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
          });
          _Store.validateKey(key);
          const conditions = _Store.getConditions(options);
          const payload = JSON.stringify(data);
          const headers = {
            "content-type": "application/json"
          };
          const res = await this.client.makeRequest({
            conditions,
            body: payload,
            headers,
            key,
            metadata: options.metadata,
            method: "put",
            storeName: this.name
          });
          await discardBody(res);
          const etag = res.headers.get("etag") ?? "";
          span?.setAttributes({
            "blobs.response.etag": etag,
            "blobs.response.status": res.status
          });
          if (conditions) {
            return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
          }
          if (res.status === STATUS_OK) {
            return {
              etag,
              modified: true
            };
          }
          throw new BlobsInternalError(res, {
            edgeAccess: this.client.edgeAccess,
            method: "put",
            storeName: this.name
          });
        });
      }
      static formatListResultBlob(result) {
        if (!result.key) {
          return null;
        }
        return {
          etag: result.etag,
          key: result.key
        };
      }
      static getConditions(options) {
        if ("onlyIfMatch" in options && "onlyIfNew" in options) {
          throw new Error(
            `The 'onlyIfMatch' and 'onlyIfNew' options are mutually exclusive. Using 'onlyIfMatch' will make the write succeed only if there is an entry for the key with the given content, while 'onlyIfNew' will make the write succeed only if there is no entry for the key.`
          );
        }
        if ("onlyIfMatch" in options && options.onlyIfMatch) {
          if (typeof options.onlyIfMatch !== "string") {
            throw new Error(`The 'onlyIfMatch' property expects a string representing an ETag.`);
          }
          return {
            onlyIfMatch: options.onlyIfMatch
          };
        }
        if ("onlyIfNew" in options && options.onlyIfNew) {
          if (typeof options.onlyIfNew !== "boolean") {
            throw new Error(
              `The 'onlyIfNew' property expects a boolean indicating whether the write should fail if an entry for the key already exists.`
            );
          }
          return {
            onlyIfNew: true
          };
        }
      }
      static validateKey(key) {
        if (key === "") {
          throw new Error("Blob key must not be empty.");
        }
        if (key.startsWith("/") || key.startsWith("%2F")) {
          throw new Error("Blob key must not start with forward slash (/).");
        }
        if (new TextEncoder().encode(key).length > 600) {
          throw new Error(
            "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
          );
        }
      }
      static validateDeployID(deployID) {
        if (!/^\w{1,24}$/.test(deployID)) {
          throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
        }
      }
      static validateStoreName(name) {
        if (name.includes("/") || name.includes("%2F")) {
          throw new Error("Store name must not contain forward slashes (/).");
        }
        if (new TextEncoder().encode(name).length > 64) {
          throw new Error(
            "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
          );
        }
      }
      getListIterator(options) {
        const { client, name: storeName } = this;
        const parameters = {};
        if (options?.prefix) {
          parameters.prefix = options.prefix;
        }
        if (options?.directories) {
          parameters.directories = "true";
        }
        return {
          [Symbol.asyncIterator]() {
            let currentCursor = null;
            let done = false;
            return {
              async next() {
                return withSpan(options?.span, "blobs.list.next", async (span) => {
                  span?.setAttributes({
                    "blobs.store": storeName,
                    "blobs.method": "GET",
                    "blobs.list.paginate": options?.paginate ?? false,
                    "blobs.list.done": done,
                    "blobs.list.cursor": currentCursor ?? void 0
                  });
                  if (done) {
                    return { done: true, value: void 0 };
                  }
                  const nextParameters = { ...parameters };
                  if (currentCursor !== null) {
                    nextParameters.cursor = currentCursor;
                  }
                  const res = await client.makeRequest({
                    method: "get",
                    parameters: nextParameters,
                    storeName
                  });
                  span?.setAttributes({
                    "blobs.response.status": res.status
                  });
                  let blobs = [];
                  let directories = [];
                  if (![200, 204, 404].includes(res.status)) {
                    await discardBody(res);
                    throw new BlobsInternalError(res);
                  }
                  if (res.status === 404) {
                    await discardBody(res);
                    done = true;
                  } else {
                    const page = await res.json();
                    if (page.next_cursor) {
                      currentCursor = page.next_cursor;
                    } else {
                      done = true;
                    }
                    blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                    directories = page.directories ?? [];
                  }
                  return {
                    done: false,
                    value: {
                      blobs,
                      directories
                    }
                  };
                });
              }
            };
          }
        };
      }
    };
    var getDeployStoreRegion = (clientOptions, context) => {
      if (clientOptions.region) {
        return clientOptions.region;
      }
      if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
        if (!context.primaryRegion) {
          throw new Error(
            "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the store options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
          );
        }
        return context.primaryRegion;
      }
      return REGION_AUTO;
    };
    var getDeployStore = (input = {}, options) => {
      const context = getEnvironmentContext();
      const mergedOptions = typeof input === "string" ? { ...options, name: input } : input;
      const deployID = mergedOptions.deployID ?? context.deployID;
      if (!deployID) {
        throw new MissingBlobsEnvironmentError(["deployID"]);
      }
      const clientOptions = getClientOptions(mergedOptions, context);
      clientOptions.region = getDeployStoreRegion(clientOptions, context);
      const client = new Client(clientOptions);
      return new Store({ client, deployID, name: mergedOptions.name });
    };
    var getStore2 = (input, options) => {
      if (typeof input === "string") {
        const contextOverride = options?.siteID && options?.token ? { siteID: options?.siteID, token: options?.token } : void 0;
        const clientOptions = getClientOptions(options ?? {}, contextOverride);
        const client = new Client(clientOptions);
        return new Store({ client, name: input });
      }
      if (typeof input?.name === "string") {
        const { name } = input;
        const contextOverride = input?.siteID && input?.token ? { siteID: input?.siteID, token: input?.token } : void 0;
        const clientOptions = getClientOptions(input, contextOverride);
        if (!name) {
          throw new MissingBlobsEnvironmentError(["name"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.deployID === "string") {
        const context = getEnvironmentContext();
        const clientOptions = getClientOptions(input, context);
        const { deployID } = input;
        if (!deployID) {
          throw new MissingBlobsEnvironmentError(["deployID"]);
        }
        clientOptions.region = getDeployStoreRegion(clientOptions, context);
        const client = new Client(clientOptions);
        return new Store({ client, deployID });
      }
      throw new Error(
        "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
      );
    };
    function listStores(options = {}) {
      const context = getEnvironmentContext();
      const clientOptions = getClientOptions(options, context);
      const client = new Client(clientOptions);
      const iterator = getListIterator(client, SITE_STORE_PREFIX);
      if (options.paginate) {
        return iterator;
      }
      return collectIterator(iterator).then((results) => ({ stores: results.flatMap((page) => page.stores) }));
    }
    var formatListStoreResponse = (stores) => stores.filter((store2) => !store2.startsWith(DEPLOY_STORE_PREFIX)).map((store2) => store2.startsWith(SITE_STORE_PREFIX) ? store2.slice(SITE_STORE_PREFIX.length) : store2);
    var getListIterator = (client, prefix) => {
      const parameters = {
        prefix
      };
      return {
        [Symbol.asyncIterator]() {
          let currentCursor = null;
          let done = false;
          return {
            async next() {
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters
              });
              if (res.status === 404) {
                await discardBody(res);
                return { done: true, value: void 0 };
              }
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              return {
                done: false,
                value: {
                  ...page,
                  stores: formatListStoreResponse(page.stores)
                }
              };
            }
          };
        }
      };
    };
  }
});

// ../assets/js/render.js
var require_render = __commonJS({
  "../assets/js/render.js"(exports2, module2) {
    (function(root, factory) {
      if (typeof module2 === "object" && module2.exports) module2.exports = factory();
      else root.Render = factory();
    })(typeof self !== "undefined" ? self : exports2, function() {
      "use strict";
      var ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
      function esc(v) {
        return String(v == null ? "" : v).replace(/[&<>"']/g, function(c) {
          return ESC[c];
        });
      }
      function url(u) {
        u = String(u == null ? "" : u).trim();
        if (!u) return "";
        var m = /^([a-z][a-z0-9+.-]*):/i.exec(u);
        if (m && !/^(https?|mailto|tel)$/i.test(m[1])) return "";
        if (/^\/\//.test(u)) return "";
        return u;
      }
      function img(u) {
        u = url(u);
        if (!u) return "";
        if (/^(https?:|\/)/i.test(u)) return u;
        return "/" + u;
      }
      function color(v, fallback) {
        v = String(v == null ? "" : v).trim();
        return /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(v) ? v : fallback;
      }
      function list(v) {
        return Array.isArray(v) ? v : [];
      }
      function digits(v) {
        return String(v == null ? "" : v).replace(/[^0-9+]/g, "");
      }
      function stable(v) {
        if (Array.isArray(v)) return "[" + v.map(stable).join(",") + "]";
        if (v && typeof v === "object") {
          return "{" + Object.keys(v).sort().map(function(k) {
            return JSON.stringify(k) + ":" + stable(v[k]);
          }).join(",") + "}";
        }
        return JSON.stringify(v === void 0 ? null : v);
      }
      var P = {
        megaphone: '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>',
        target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
        search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.2-4.2"/>',
        tag: '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><path d="M7 7h.01"/>',
        chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
        pixel: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
        api: '<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/>',
        bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
        users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14a6.5 6.5 0 0 1 3.5 6"/>',
        globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
        layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
        code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>',
        close: '<path d="M6 6l12 12M18 6L6 18"/>',
        send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
        bigcheck: '<circle cx="12" cy="12" r="10"/><path d="M7.5 12.5l3 3 6-6.5"/>',
        arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
        arrowUR: '<path d="M7 17L17 7M8 7h9v9"/>',
        check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
        left: '<path d="M15 5l-7 7 7 7"/>',
        right: '<path d="M9 5l7 7-7 7"/>',
        quote: '<path d="M9 7H5.5A1.5 1.5 0 0 0 4 8.5V13a1.5 1.5 0 0 0 1.5 1.5H8V16a3 3 0 0 1-3 3M20 7h-3.5A1.5 1.5 0 0 0 15 8.5V13a1.5 1.5 0 0 0 1.5 1.5H19V16a3 3 0 0 1-3 3"/>',
        mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 6L2 7"/>',
        phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
        lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
        facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
        linkedin: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
        instagram: '<rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.4A4 4 0 1 1 12.6 8 4 4 0 0 1 16 11.4z"/><path d="M17.5 6.5h.01"/>',
        x: '<path d="M4 4l16 16M20 4L4 20"/>',
        whatsapp: '<path d="M3 21l1.65-4.8A8.5 8.5 0 1 1 8 19.4z"/><path d="M9 10c.5 2 2 3.5 4 4"/>',
        youtube: '<rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/>',
        github: '<path d="M9 19c-4 1.2-4-2-6-2.5M15 21v-3.4a3 3 0 0 0-.8-2.3c2.7-.3 5.5-1.3 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.3 4.3 0 0 0-.1-3.2s-1-.3-3.4 1.3a11.7 11.7 0 0 0-6 0C6.5 2.8 5.5 3.1 5.5 3.1a4.3 4.3 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 9.5c0 4.6 2.8 5.7 5.5 6a3 3 0 0 0-.8 2.3V21"/>'
      };
      var ICON_CHOICES = ["megaphone", "target", "search", "tag", "chart", "pixel", "api", "mail", "phone", "bolt", "users", "globe", "layers", "code"];
      var SOCIAL_TYPES = ["facebook", "linkedin", "instagram", "x", "whatsapp", "youtube", "github"];
      var LABELS = { facebook: "Facebook", linkedin: "LinkedIn", instagram: "Instagram", x: "X", whatsapp: "WhatsApp", youtube: "YouTube", github: "GitHub" };
      function icon(name, cls) {
        var p = P[name] || P.arrow;
        return '<svg class="ic' + (cls ? " " + cls : "") + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + p + "</svg>";
      }
      var PAGES = {
        home: { file: "index.html", label: "Home" },
        services: { file: "services.html", label: "Services", anchor: "#services" },
        work: { file: "my-work.html", label: "My Work", anchor: "#work" },
        about: { file: "about.html", label: "About Me", anchor: "#about" },
        testimonials: { file: "testimonials.html", label: "Testimonials", anchor: "#testimonials" },
        contact: { file: "contact.html", label: "Contact" }
      };
      var NAV = ["home", "services", "work", "about", "testimonials", "contact"];
      function href(c, ctx, key) {
        var p = PAGES[key];
        if (ctx.built && ctx.built[key]) return p.file;
        if (key === "home") return ctx.page === "home" ? "#top" : "index.html";
        if (key === "contact") {
          var em = c.contact && c.contact.email ? "mailto:" + c.contact.email : "";
          return em || (ctx.page === "home" ? "#contact" : "index.html#contact");
        }
        return (ctx.page === "home" ? "" : "index.html") + p.anchor;
      }
      function grad(text) {
        return text ? ' <span class="grad-text">' + esc(text) + "</span>" : "";
      }
      function head(o, center) {
        o = o || {};
        return '<div class="sec-head' + (center ? " center" : "") + ' reveal">' + (o.eyebrow ? '<span class="eyebrow">' + esc(o.eyebrow) + "</span>" : "") + "<h2>" + esc(o.heading) + grad(o.headingAccent) + "</h2>" + (o.sub ? '<p class="sec-sub">' + esc(o.sub) + "</p>" : "") + "</div>";
      }
      function btn(cls, link, label, ic, extra) {
        return '<a class="btn ' + cls + ' magnetic" href="' + esc(link) + '"' + (extra || "") + "><span>" + esc(label) + "</span>" + (ic ? icon(ic) : "") + "</a>";
      }
      function socials(c, cls) {
        var items = list(c.contact && c.contact.socials).filter(function(s) {
          return url(s.url);
        });
        if (!items.length) return "";
        return '<ul class="socials ' + (cls || "") + '">' + items.map(function(s) {
          var label = LABELS[s.type] || "Profile";
          return '<li><a href="' + esc(url(s.url)) + '" target="_blank" rel="noopener noreferrer" aria-label="' + esc(label) + '" title="' + esc(label) + '">' + icon(s.type) + "</a></li>";
        }).join("") + "</ul>";
      }
      function delay(i, step) {
        return ' style="--d:' + (i % 6 * (step || 0.08)).toFixed(2) + 's"';
      }
      function header(c, ctx) {
        var s = c.settings || {};
        var logo = s.logoImage ? '<img class="brand-logo" src="' + esc(img(s.logoImage)) + '" alt="" width="40" height="40">' : '<span class="brand-mark">' + esc(s.logoInitials || "MH") + "</span>";
        var links = NAV.map(function(k) {
          var active = ctx.page === k;
          return '<li><a class="nav-link' + (active ? " is-active" : "") + '" href="' + esc(href(c, ctx, k)) + '"' + (active ? ' aria-current="page"' : "") + ">" + esc(PAGES[k].label) + "</a></li>";
        }).join("");
        var hire = c.home && c.home.hero && c.home.hero.btnSecondary || "Hire Me";
        return '<a class="skip" href="#main">Skip to content</a><header class="site-header"><div class="wrap nav-inner"><a class="brand" href="' + esc(href(c, ctx, "home")) + '" aria-label="' + esc(s.brand || "Home") + ' home">' + logo + '<span class="brand-name">' + esc(s.brand) + '</span></a><nav class="nav" aria-label="Main"><ul class="nav-menu" id="nav-menu">' + links + '<li class="nav-cta">' + btn("btn-primary btn-sm", href(c, ctx, "contact"), hire) + '</li></ul></nav><button class="nav-toggle" type="button" aria-label="Toggle menu" aria-expanded="false" aria-controls="nav-menu"><span></span><span></span></button></div></header>';
      }
      function footer(c, ctx) {
        var s = c.settings || {}, ct = c.contact || {};
        var year = ctx.year || (/* @__PURE__ */ new Date()).getFullYear();
        var quick = NAV.map(function(k) {
          return '<li><a href="' + esc(href(c, ctx, k)) + '">' + esc(PAGES[k].label) + "</a></li>";
        }).join("");
        var svc = list(c.services).map(function(v) {
          return '<li><a href="' + esc(href(c, ctx, "services")) + '">' + esc(v.title) + "</a></li>";
        }).join("");
        var contactItems = "";
        if (ct.email) contactItems += '<li><a class="ft-contact" href="mailto:' + esc(ct.email) + '">' + icon("mail") + "<span>" + esc(ct.email) + "</span></a></li>";
        if (ct.phone) contactItems += '<li><a class="ft-contact" href="tel:' + esc(digits(ct.phone)) + '">' + icon("phone") + "<span>" + esc(ct.phone) + "</span></a></li>";
        var logo = s.logoImage ? '<img class="brand-logo" src="' + esc(img(s.logoImage)) + '" alt="" width="40" height="40">' : '<span class="brand-mark">' + esc(s.logoInitials || "MH") + "</span>";
        return '<footer class="site-footer"><div class="wrap"><div class="ft-grid"><div class="ft-brand"><a class="brand" href="' + esc(href(c, ctx, "home")) + '">' + logo + '<span class="brand-name">' + esc(s.brand) + "</span></a>" + (s.footerDescription ? "<p>" + esc(s.footerDescription) + "</p>" : "") + socials(c, "socials-sm") + '</div><div class="ft-col"><h3>Quick Links</h3><ul>' + quick + "</ul></div>" + (svc ? '<div class="ft-col"><h3>Services</h3><ul>' + svc + "</ul></div>" : "") + '<div class="ft-col"><h3>Get in Touch</h3><ul>' + contactItems + '<li><a class="btn btn-ghost btn-sm magnetic" href="/admin/" rel="nofollow">' + icon("lock") + '<span>Admin Panel</span></a></li></ul></div></div><div class="ft-bottom"><p>&copy; ' + esc(year) + " " + esc(s.brand) + ". " + esc(s.footerText) + "</p></div></div></footer>";
      }
      function hero(c, ctx) {
        var h = c.home && c.home.hero || {};
        var roles = list(h.roles);
        var rotor = roles.length ? '<p class="roles"><span class="roles-label">' + esc(h.rolesLabel || "") + '</span><span class="rotor" aria-label="' + esc(roles.join(", ")) + '">' + roles.map(function(r, i) {
          return "<span" + (i === 0 ? ' class="is-active"' : ' aria-hidden="true"') + ">" + esc(r) + "</span>";
        }).join("") + "</span></p>" : "";
        var cards = list(h.floatCards).slice(0, 2).map(function(f, i) {
          return '<div class="float-card fc-' + (i + 1) + '"><strong>' + esc(f.value) + "</strong><span>" + esc(f.label) + "</span></div>";
        }).join("");
        var portrait = h.portrait ? '<div class="hero-visual reveal"><div class="portrait-wrap"><div class="portrait-glow"></div><div class="tilt"><div class="portrait-frame"><img src="' + esc(img(h.portrait)) + '" alt="' + esc((h.nameLine1 || "") + " " + (h.nameLine2 || "")) + '" width="800" height="1000" fetchpriority="high"></div>' + cards + "</div></div></div>" : "";
        var name = esc(((h.nameLine1 || "") + " " + (h.nameLine2 || "")).trim());
        return '<section class="hero" id="top"><div class="wrap hero-grid"><div class="hero-copy">' + (h.pill ? '<p class="pill reveal"><span class="pill-dot"></span>' + esc(h.pill) + "</p>" : "") + '<h1 class="hero-name" aria-label="' + name + '"><span class="line" style="--i:0"><span>' + esc(h.nameLine1) + '</span></span><span class="line" style="--i:1"><span>' + esc(h.nameLine2) + "</span></span></h1>" + (h.profession ? '<p class="profession reveal" style="--d:.15s">' + esc(h.profession) + "</p>" : "") + '<div class="reveal" style="--d:.22s">' + rotor + "</div>" + (h.taglineA ? '<p class="tagline reveal" style="--d:.3s">&ldquo;' + esc(h.taglineA) + grad(h.taglineB) + "&rdquo;</p>" : "") + (h.intro ? '<p class="intro reveal" style="--d:.36s">' + esc(h.intro) + "</p>" : "") + '<div class="hero-actions reveal" style="--d:.42s">' + (h.btnPrimary ? btn("btn-primary", href(c, ctx, "work"), h.btnPrimary, "arrow") : "") + (h.btnSecondary ? btn("btn-ghost", href(c, ctx, "contact"), h.btnSecondary) : "") + '</div><div class="reveal" style="--d:.5s">' + socials(c, "socials-hero") + "</div></div>" + portrait + '</div><a class="scroll-hint" href="#stats" aria-label="Scroll down"><span>Scroll</span><i></i></a></section>';
      }
      function stats(c) {
        var st = list(c.home && c.home.stats);
        if (!st.length) return "";
        return '<section class="stats" id="stats"><div class="wrap"><div class="glass stats-panel reveal">' + st.map(function(s) {
          var n = parseFloat(s.value);
          var dec = (String(s.value).split(".")[1] || "").length;
          return '<div class="stat"><div class="stat-num">' + (s.prefix ? '<span class="affix">' + esc(s.prefix) + "</span>" : "") + '<span class="count" data-to="' + esc(isNaN(n) ? 0 : n) + '" data-dec="' + dec + '">' + esc(s.value) + "</span>" + (s.suffix ? '<span class="affix">' + esc(s.suffix) + "</span>" : "") + "</div><p>" + esc(s.label) + "</p></div>";
        }).join("") + "</div></div></section>";
      }
      function services(c, ctx) {
        var items = list(c.services);
        if (!items.length) return "";
        var more = href(c, ctx, "services");
        return '<section class="section" id="services"><div class="wrap">' + head(c.home.services) + '<div class="grid-3">' + items.map(function(s, i) {
          return '<div class="reveal"' + delay(i) + '><article class="card service spot"><div class="ic-box">' + icon(s.icon) + "</div><h3>" + esc(s.title) + "</h3><p>" + esc(s.description) + '</p><ul class="ticks">' + list(s.included).slice(0, 3).map(function(b) {
            return "<li>" + icon("check") + "<span>" + esc(b) + "</span></li>";
          }).join("") + '</ul><a class="more" href="' + esc(more) + '"><span>Learn more</span>' + icon("arrow") + "</a></article></div>";
        }).join("") + "</div></div></section>";
      }
      function newest(projects, n) {
        return list(projects).map(function(p, i) {
          return { p, i };
        }).sort(function(a, b) {
          var da = a.p.date || "", db = b.p.date || "";
          if (da === db) return a.i - b.i;
          return da < db ? 1 : -1;
        }).slice(0, n).map(function(x) {
          return x.p;
        });
      }
      function work(c, ctx) {
        var items = newest(c.projects, 4);
        if (!items.length) return "";
        var w = c.home.work || {};
        var link = href(c, ctx, "work");
        return '<section class="section" id="work"><div class="wrap">' + head(w) + '<div class="work-grid">' + items.map(function(p, i) {
          return '<div class="reveal"' + delay(i) + '><a class="work-card spot" href="' + esc(link) + '"><img src="' + esc(img(p.image)) + '" alt="' + esc(p.title) + '" width="1280" height="800" loading="lazy"><div class="work-overlay"><div><h3>' + esc(p.title) + "</h3><p>" + esc(p.description) + '</p></div><span class="work-go">' + icon("arrowUR") + "</span></div></a></div>";
        }).join("") + "</div>" + (w.button ? '<div class="center-actions reveal">' + btn("btn-ghost", link, w.button, "arrow") + "</div>" : "") + "</div></section>";
      }
      function about(c, ctx) {
        var a = c.home && c.home.about || {};
        return '<section class="section" id="about"><div class="wrap about-grid"><div class="about-media reveal"><div class="portrait-frame about-frame"><img src="' + esc(img(a.photo)) + '" alt="' + esc((c.settings || {}).brand) + '" width="800" height="1000" loading="lazy"></div>' + (a.badgeNumber ? '<div class="badge glass"><strong>' + esc(a.badgeNumber) + "</strong><span>" + esc(a.badgeLabel) + "</span></div>" : "") + '</div><div class="about-copy"><div class="reveal">' + (a.eyebrow ? '<span class="eyebrow">' + esc(a.eyebrow) + "</span>" : "") + "<h2>" + esc(a.heading) + grad(a.headingAccent) + "</h2></div>" + (a.p1 ? '<p class="reveal" style="--d:.08s">' + esc(a.p1) + "</p>" : "") + (a.p2 ? '<p class="reveal" style="--d:.14s">' + esc(a.p2) + "</p>" : "") + (list(a.bullets).length ? '<ul class="ticks ticks-2 reveal" style="--d:.2s">' + list(a.bullets).slice(0, 4).map(function(b) {
          return "<li>" + icon("check") + "<span>" + esc(b) + "</span></li>";
        }).join("") + "</ul>" : "") + (a.button ? '<div class="reveal" style="--d:.26s">' + btn("btn-primary", href(c, ctx, "about"), a.button, "arrow") + "</div>" : "") + "</div></div></section>";
      }
      function tools(c) {
        var t = c.home && c.home.tools || {};
        var chips = list(t.chips), keys = list(t.marquee);
        if (!chips.length && !keys.length) return "";
        var group = function(hidden) {
          return '<div class="marquee-group"' + (hidden ? ' aria-hidden="true"' : "") + ">" + keys.map(function(k) {
            return '<span class="mq-item">' + esc(k) + '</span><span class="mq-sep" aria-hidden="true"></span>';
          }).join("") + "</div>";
        };
        return '<section class="section" id="tools"><div class="wrap">' + head(t, true) + (chips.length ? '<ul class="chips reveal">' + chips.map(function(x) {
          return '<li class="chip"><i></i>' + esc(x) + "</li>";
        }).join("") + "</ul>" : "") + "</div>" + (keys.length ? '<div class="marquee reveal" aria-label="' + esc(keys.join(", ")) + '"><div class="marquee-track">' + group(false) + group(true) + "</div></div>" : "") + "</section>";
      }
      function stars() {
        var s = "";
        for (var i = 0; i < 5; i++) s += '<svg class="ic star" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9z"/></svg>';
        return '<span class="stars" role="img" aria-label="5 out of 5 stars">' + s + "</span>";
      }
      function testimonials(c, ctx) {
        var items = list(c.testimonials);
        if (!items.length) return "";
        var t = c.home && c.home.testimonials || {};
        var multi = items.length > 1;
        return '<section class="section" id="testimonials"><div class="wrap">' + head(t, true) + '<div class="slider reveal" data-slider role="region" aria-roledescription="carousel" aria-label="Testimonials" tabindex="0"><div class="slides">' + items.map(function(r, i) {
          return '<figure class="slide glass' + (i === 0 ? " is-active" : "") + '"' + (i === 0 ? "" : ' aria-hidden="true"') + '><span class="q-mark">' + icon("quote") + "</span>" + (r.service ? '<span class="tag">' + esc(r.service) + "</span>" : "") + "<blockquote>" + esc(r.text) + '</blockquote><figcaption><span class="avatar" style="--c1:' + color(r.c1, "#8b5cf6") + ";--c2:" + color(r.c2, "#22d3ee") + '">' + esc(r.initials) + '</span><span class="who"><strong>' + esc(r.name) + "</strong><span>" + esc(r.role) + "</span></span></figcaption></figure>";
        }).join("") + "</div>" + (multi ? '<div class="slider-ctl"><button class="arrow-btn" type="button" data-slide-prev aria-label="Previous review">' + icon("left") + '</button><div class="dots">' + items.map(function(r, i) {
          return '<button class="slider-dot' + (i === 0 ? " is-active" : "") + '" type="button" data-slide-to="' + i + '" aria-label="Show review ' + (i + 1) + '"' + (i === 0 ? ' aria-current="true"' : "") + "></button>";
        }).join("") + '</div><button class="arrow-btn" type="button" data-slide-next aria-label="Next review">' + icon("right") + "</button></div>" : "") + "</div>" + (t.button ? '<div class="center-actions reveal">' + btn("btn-ghost", href(c, ctx, "testimonials"), t.button, "arrow") + "</div>" : "") + "</div></section>";
      }
      function cta(c, ctx) {
        var k = c.home && c.home.cta || {};
        var email = c.contact && c.contact.email;
        return '<section class="section cta" id="contact"><div class="wrap"><div class="cta-panel reveal"><div class="cta-glow" aria-hidden="true"></div><h2>' + esc(k.heading) + grad(k.headingAccent) + "</h2>" + (k.text ? "<p>" + esc(k.text) + "</p>" : "") + '<div class="cta-actions">' + (k.button ? btn("btn-primary", href(c, ctx, "contact"), k.button, "arrow") : "") + (email ? '<a class="btn btn-ghost magnetic" href="mailto:' + esc(email) + '">' + icon("mail") + "<span>" + esc(email) + "</span></a>" : "") + "</div></div></div></section>";
      }
      function pageHeader(c, ctx, key) {
        var p = c.pages && c.pages[key] || {};
        return '<section class="page-head"><div class="wrap"><nav class="crumbs reveal" aria-label="Breadcrumb"><a href="' + esc(href(c, ctx, "home")) + '">Home</a><span aria-hidden="true">/</span><span aria-current="page">' + esc(PAGES[key].label) + "</span></nav>" + (p.eyebrow ? '<span class="eyebrow reveal" style="--d:.05s">' + esc(p.eyebrow) + "</span>" : "") + '<h1 class="page-title"><span class="line" style="--i:0"><span>' + esc(p.heading) + "</span></span>" + (p.headingAccent ? '<span class="line" style="--i:1"><span class="grad-text">' + esc(p.headingAccent) + "</span></span>" : "") + "</h1>" + (p.intro ? '<p class="page-intro reveal" style="--d:.2s">' + esc(p.intro) + "</p>" : "") + "</div></section>";
      }
      function pageCta(c, ctx, key) {
        var k = c.pages && c.pages[key] && c.pages[key].cta || {};
        var email = c.contact && c.contact.email;
        var second = "";
        if (k.secondaryLabel && k.secondaryPage && PAGES[k.secondaryPage]) second = btn("btn-ghost", href(c, ctx, k.secondaryPage), k.secondaryLabel);
        else if (email) second = '<a class="btn btn-ghost magnetic" href="mailto:' + esc(email) + '">' + icon("mail") + "<span>" + esc(email) + "</span></a>";
        return '<section class="section cta"><div class="wrap"><div class="cta-panel reveal"><div class="cta-glow" aria-hidden="true"></div><h2>' + esc(k.heading) + grad(k.headingAccent) + "</h2>" + (k.text ? "<p>" + esc(k.text) + "</p>" : "") + '<div class="cta-actions">' + (k.button ? btn("btn-primary", href(c, ctx, "contact"), k.button, "arrow") : "") + second + "</div></div></div></section>";
      }
      function servicesPage(c, ctx) {
        var items = list(c.services), contact = href(c, ctx, "contact");
        var grid = items.length ? '<div class="grid-3">' + items.map(function(s, i) {
          var inc = list(s.included);
          return '<div class="reveal"' + delay(i) + '><article class="card svc-card spot"><div class="svc-top"><div class="ic-box">' + icon(s.icon) + "</div>" + (s.category ? '<span class="tag">' + esc(s.category) + "</span>" : "") + "</div><h3>" + esc(s.title) + "</h3><p>" + esc(s.description) + "</p>" + (inc.length ? '<p class="inc-label">What&rsquo;s Included</p><ul class="ticks">' + inc.slice(0, 6).map(function(b) {
            return "<li>" + icon("check") + "<span>" + esc(b) + "</span></li>";
          }).join("") + "</ul>" : "") + '<div class="svc-foot">' + (s.note ? '<span class="note">' + esc(s.note) + "</span>" : "<span></span>") + btn("btn-primary btn-sm", contact, "Get Started", "arrow") + "</div></article></div>";
        }).join("") + "</div>" : "";
        return pageHeader(c, ctx, "services") + '<section class="section tight"><div class="wrap">' + grid + "</div></section>" + pageCta(c, ctx, "services");
      }
      function workPage(c, ctx) {
        var items = newest(c.projects, 1e5);
        var grid = items.length ? '<div class="gal-grid">' + items.map(function(p, i) {
          return '<div class="reveal"' + delay(i) + '><article class="gal-card card spot" role="button" tabindex="0" aria-haspopup="dialog" aria-label="View larger: ' + esc(p.title) + '" data-open data-title="' + esc(p.title) + '" data-desc="' + esc(p.description) + '" data-src="' + esc(img(p.image)) + '"><div class="gal-shot"><img src="' + esc(img(p.image)) + '" alt="' + esc(p.title) + '" width="1280" height="800" loading="lazy"><span class="gal-zoom">' + icon("search") + '</span></div><div class="gal-body"><h3>' + esc(p.title) + "</h3>" + (p.description ? "<p>" + esc(p.description) + "</p>" : "") + "</div></article></div>";
        }).join("") + "</div>" : '<p class="empty-note">New projects will appear here soon.</p>';
        var viewer = '<div class="viewer" id="viewer" role="dialog" aria-modal="true" aria-labelledby="viewer-title" hidden><div class="viewer-backdrop" data-viewer-close></div><div class="viewer-panel"><button class="viewer-close" type="button" data-viewer-close aria-label="Close">' + icon("close") + '</button><div class="viewer-img"><img id="viewer-img" src="" alt=""></div><div class="viewer-text"><h3 id="viewer-title"></h3><p id="viewer-desc"></p></div></div></div>';
        return pageHeader(c, ctx, "work") + '<section class="section tight"><div class="wrap">' + grid + "</div></section>" + pageCta(c, ctx, "work") + viewer;
      }
      function aboutPage(c, ctx) {
        var a = c.pages && c.pages.about || {};
        var name = (c.settings || {}).brand;
        var paras = list(a.paragraphs);
        var media = a.photo ? '<div class="story-media reveal"><div class="portrait-wrap"><div class="portrait-glow"></div><div class="glow-ring" aria-hidden="true"></div><div class="tilt"><div class="portrait-frame"><img src="' + esc(img(a.photo)) + '" alt="' + esc(a.signatureName || name) + '" width="800" height="1000" loading="lazy"></div></div></div></div>' : "";
        return pageHeader(c, ctx, "about") + '<section class="section tight"><div class="wrap story-grid' + (media ? "" : " no-media") + '">' + media + '<div class="story-copy">' + (a.storyEyebrow ? '<span class="eyebrow reveal">' + esc(a.storyEyebrow) + "</span>" : "") + (a.openingLine ? '<p class="lead reveal" style="--d:.06s">' + esc(a.openingLine) + "</p>" : "") + paras.map(function(t, i) {
          return '<p class="reveal" style="--d:' + (0.1 + i * 0.06).toFixed(2) + 's">' + esc(t) + "</p>";
        }).join("") + (a.signatureName || a.signatureTitle ? '<div class="signature reveal"><span class="sig-name">' + esc(a.signatureName) + '</span><span class="sig-title">' + esc(a.signatureTitle) + "</span></div>" : "") + "</div></div></section>" + pageCta(c, ctx, "about");
      }
      function reviewData(r) {
        return ' data-service="' + esc(r.service) + '" data-text="' + esc(r.text) + '" data-name="' + esc(r.name) + '" data-role="' + esc(r.role) + '" data-initials="' + esc(r.initials) + '" data-c1="' + color(r.c1, "#8b5cf6") + '" data-c2="' + color(r.c2, "#22d3ee") + '"';
      }
      function avatar(r) {
        return '<span class="avatar" style="--c1:' + color(r.c1, "#8b5cf6") + ";--c2:" + color(r.c2, "#22d3ee") + '">' + esc(r.initials) + "</span>";
      }
      function testimonialsPage(c, ctx) {
        var items = list(c.testimonials);
        var feat = items[0], rest = items.slice(1);
        var featured = feat ? '<div class="feature glass reveal" data-feature' + reviewData(feat) + '><div class="feature-glow" aria-hidden="true"></div><div class="feature-inner"><span class="q-mark">' + icon("quote") + '</span><span class="tag" data-f="service"' + (feat.service ? "" : " hidden") + ">" + esc(feat.service) + '</span><blockquote data-f="text">' + esc(feat.text) + "</blockquote>" + stars() + '<div class="who-row">' + avatar(feat).replace('class="avatar"', 'class="avatar" data-f="avatar"') + '<span class="who"><strong data-f="name">' + esc(feat.name) + '</strong><span data-f="role">' + esc(feat.role) + "</span></span></div></div></div>" : "";
        var grid = rest.length ? '<div class="review-grid">' + rest.map(function(r, i) {
          return '<div class="reveal"' + delay(i) + '><article class="review card spot" role="button" tabindex="0" aria-label="Show this review from ' + esc(r.name) + ' at the top"' + reviewData(r) + ">" + (r.service ? '<span class="tag" data-f="service">' + esc(r.service) + "</span>" : '<span class="tag" data-f="service" hidden></span>') + stars() + '<p class="r-text" data-f="text">' + esc(r.text) + '</p><div class="who-row">' + avatar(r).replace('class="avatar"', 'class="avatar" data-f="avatar"') + '<span class="who"><strong data-f="name">' + esc(r.name) + '</strong><span data-f="role">' + esc(r.role) + "</span></span></div></article></div>";
        }).join("") + "</div>" : "";
        var none = !items.length ? '<p class="empty-note">Reviews will appear here soon.</p>' : "";
        return pageHeader(c, ctx, "testimonials") + '<section class="section tight" id="reviews"><div class="wrap">' + featured + grid + none + "</div></section>" + pageCta(c, ctx, "testimonials");
      }
      function waDigits(v) {
        return String(v == null ? "" : v).replace(/\D/g, "");
      }
      function contactPage(c, ctx) {
        var p = c.pages && c.pages.contact || {}, ct = c.contact || {};
        var opts = list(c.services).map(function(s) {
          return '<option value="' + esc(s.title) + '">' + esc(s.title) + "</option>";
        }).join("") + (p.serviceUnsure ? '<option value="' + esc(p.serviceUnsure) + '">' + esc(p.serviceUnsure) + "</option>" : "");
        var field = function(id, label, req, control, hint) {
          return '<div class="field" data-field="' + id + '"><label for="cf-' + id + '">' + esc(label) + (req ? ' <i aria-hidden="true">*</i>' : " <em>(optional)</em>") + "</label>" + control + '<p class="err" id="cf-' + id + '-err" role="alert"></p></div>';
        };
        var form = '<div data-form-view><h2 class="form-title">' + esc(p.formHeading) + "</h2>" + (p.formSub ? '<p class="form-sub">' + esc(p.formSub) + "</p>" : "") + '<form class="cform" data-contact-form novalidate><div class="hp" aria-hidden="true"><label>Leave this field empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div><div class="two-col">' + field("name", "Your Name", true, '<input id="cf-name" name="name" type="text" autocomplete="name" maxlength="120" required aria-describedby="cf-name-err">') + field("email", "Email Address", true, '<input id="cf-email" name="email" type="email" autocomplete="email" maxlength="200" required aria-describedby="cf-email-err">') + '</div><div class="two-col">' + field("phone", "Phone / WhatsApp", false, '<input id="cf-phone" name="phone" type="tel" autocomplete="tel" maxlength="40" aria-describedby="cf-phone-err">') + field("service", "Service Needed", true, '<select id="cf-service" name="service" required aria-describedby="cf-service-err"><option value="">Select a service</option>' + opts + "</select>") + "</div>" + field("message", "Your Message", true, '<textarea id="cf-message" name="message" rows="6" maxlength="5000" required aria-describedby="cf-message-err"></textarea>') + '<div class="form-foot"><button class="btn btn-primary magnetic" type="submit"><span>' + esc(p.submitLabel || "Send Message") + "</span>" + icon("send") + "</button>" + (p.privacyNote ? '<p class="privacy">' + icon("lock") + "<span>" + esc(p.privacyNote) + "</span></p>" : "") + '</div><p class="form-status" role="status" aria-live="polite" data-form-status></p></form></div>';
        var success = '<div class="form-success" data-form-success hidden tabindex="-1"><span class="ok-ic">' + icon("bigcheck") + "</span><h2>" + esc(p.successHeading) + "</h2><p>" + esc(p.successText) + '</p><button class="btn btn-ghost magnetic" type="button" data-form-reset><span>' + esc(p.successButton) + "</span></button></div>";
        var card = function(ic, label, value, link, hint) {
          return '<a class="ccard glass spot reveal" href="' + esc(link) + '"><span class="ic-box">' + icon(ic) + '</span><span class="ccard-text"><span class="ccard-label">' + esc(label) + "</span><strong>" + esc(value) + "</strong>" + (hint ? '<span class="ccard-hint">' + esc(hint) + "</span>" : "") + "</span></a>";
        };
        var cards = "";
        if (ct.email) cards += card("mail", "Email", ct.email, "mailto:" + ct.email, p.emailHint);
        if (ct.phone) cards += card("phone", "Phone", ct.phone, "tel:" + digits(ct.phone), p.phoneHint);
        if (ct.whatsapp) cards += card("whatsapp", "WhatsApp", ct.whatsapp, "https://wa.me/" + waDigits(ct.whatsapp), p.whatsappHint);
        var soc = socials(c, "");
        var online = soc ? '<div class="online glass reveal"><h3>' + esc(p.findMeTitle || "Find Me Online") + "</h3>" + soc + "</div>" : "";
        return pageHeader(c, ctx, "contact") + '<section class="section tight"><div class="wrap contact-grid' + (cards || online ? "" : " solo") + '"><div class="form-panel glass reveal" data-form-panel><div class="form-glow" aria-hidden="true"></div>' + form + success + "</div>" + (cards || online ? '<aside class="contact-side">' + cards + online + "</aside>" : "") + '</div></section><div class="cta-spacer"></div>';
      }
      function home(c, ctx) {
        return hero(c, ctx) + stats(c) + services(c, ctx) + work(c, ctx) + about(c, ctx) + tools(c) + testimonials(c, ctx) + cta(c, ctx);
      }
      function notFound(c, ctx) {
        return '<section class="hero nf"><div class="wrap"><p class="eyebrow">Error 404</p><h1 class="hero-name"><span class="line" style="--i:0"><span>Page not</span></span><span class="line" style="--i:1"><span class="grad-text">found</span></span></h1><p class="intro">The page you are looking for does not exist or has moved.</p><div class="hero-actions">' + btn("btn-primary", href(c, { page: "x", built: ctx.built }, "home"), "Back to Home", "arrow") + "</div></div></section>";
      }
      function renderApp(c, ctx) {
        ctx = ctx || {};
        ctx.page = ctx.page || "home";
        ctx.built = ctx.built || { home: true, services: true, work: true, about: true, testimonials: true, contact: true };
        var views = { home, services: servicesPage, work: workPage, about: aboutPage, testimonials: testimonialsPage, contact: contactPage };
        var body = (views[ctx.page] || notFound)(c, ctx);
        return header(c, ctx) + '<main id="main">' + body + "</main>" + footer(c, ctx);
      }
      function themeCss(c) {
        var t = c && c.theme || {};
        return ":root{--bg:" + color(t.bg, "#070812") + ";--accent:" + color(t.accent, "#8b5cf6") + ";--accent-2:" + color(t.accent2, "#22d3ee") + ";--text:" + color(t.text, "#eef0ff") + "}";
      }
      function pageMeta(c, page) {
        var s = c && c.settings || {};
        var p = c && c.pages && c.pages[page] || {};
        var title = page === "home" ? s.siteTitle || s.brand || "" : PAGES[page] ? PAGES[page].label + " | " + (s.brand || "") : "Page not found | " + (s.brand || "");
        return { title, description: page !== "home" && p.intro ? p.intro : s.metaDescription || "" };
      }
      return { esc, stable, renderApp, themeCss, pageMeta, PAGES, newest, icon, ICON_CHOICES, SOCIAL_TYPES, LABELS };
    });
  }
});

// ../content/site.json
var require_site = __commonJS({
  "../content/site.json"(exports2, module2) {
    module2.exports = {
      settings: {
        brand: "Mahdi Hasan Akand",
        logoInitials: "MH",
        logoImage: "",
        favicon: "/assets/img/favicon.svg",
        siteTitle: "MH Mahdi Hasan Akand | Digital Marketing & Performance Marketing Specialist",
        metaDescription: "MH Mahdi Hasan Akand is a digital marketing and performance marketing specialist focused on Meta Ads, Google Ads, SEO and accurate conversion tracking.",
        footerDescription: "Digital marketing and performance marketing focused on measurable growth, clean tracking and clear communication.",
        footerText: "All rights reserved."
      },
      theme: {
        bg: "#070812",
        accent: "#8b5cf6",
        accent2: "#22d3ee",
        text: "#eef0ff"
      },
      contact: {
        email: "",
        phone: "",
        whatsapp: "",
        socials: []
      },
      home: {
        hero: {
          pill: "Available for new projects",
          nameLine1: "MH Mahdi",
          nameLine2: "Hasan Akand",
          profession: "Digital Marketing & Performance Marketing Specialist",
          rolesLabel: "Specialising in",
          roles: [
            "Meta Ads",
            "Google Ads",
            "Search Engine Optimization",
            "Meta Pixel & Conversions API",
            "Google Tag Manager",
            "Google Analytics"
          ],
          taglineA: "Turning ad spend",
          taglineB: "into measurable growth.",
          intro: "I plan, launch and optimise paid and organic campaigns, and I set up the tracking behind them, so every decision you make is backed by data you can trust.",
          btnPrimary: "View My Work",
          btnSecondary: "Hire Me",
          portrait: "/assets/img/portrait.svg",
          floatCards: [
            {
              value: "6",
              label: "Core services"
            },
            {
              value: "2",
              label: "Ad platforms"
            }
          ]
        },
        stats: [
          {
            prefix: "",
            value: "6",
            suffix: "",
            label: "Core Services"
          },
          {
            prefix: "",
            value: "2",
            suffix: "",
            label: "Ad Platforms"
          },
          {
            prefix: "",
            value: "5",
            suffix: "",
            label: "Tracking Tools"
          },
          {
            prefix: "",
            value: "3",
            suffix: "",
            label: "Marketing Disciplines"
          }
        ],
        services: {
          eyebrow: "What I Do",
          heading: "Services built to",
          headingAccent: "drive measurable growth",
          sub: "Six focused services covering paid advertising, search visibility and the tracking that ties it all together."
        },
        work: {
          eyebrow: "Featured Work",
          heading: "A look at recent",
          headingAccent: "projects",
          sub: "A selection of the newest work from my portfolio.",
          button: "View Full Portfolio"
        },
        about: {
          eyebrow: "About Me",
          heading: "Marketing that is built on",
          headingAccent: "clean data and clear goals",
          photo: "/assets/img/about.svg",
          badgeNumber: "6",
          badgeLabel: "Core Services",
          p1: "I help businesses reach the right people through paid advertising and search, and I make sure every click is tracked properly so decisions are based on real data rather than guesswork.",
          p2: "From the first campaign structure to the final report, I keep the setup clean, explain what I am doing in plain language, and focus on steady, measurable improvement.",
          bullets: [
            "Campaigns planned around your goals",
            "Accurate tracking from the first click",
            "Clear, plain-language reporting",
            "Ongoing testing and optimisation"
          ],
          button: "Learn More About Me"
        },
        tools: {
          eyebrow: "Tools & Expertise",
          heading: "The tools I rely on",
          headingAccent: "every day",
          sub: "A focused toolkit for advertising, search and measurement.",
          chips: [
            "Meta Ads Manager",
            "Meta Events Manager",
            "Meta Pixel",
            "Conversions API",
            "Google Ads",
            "Google Tag Manager",
            "Google Analytics"
          ],
          marquee: [
            "Meta Ads",
            "Google Ads",
            "SEO",
            "Meta Pixel",
            "Conversions API",
            "Events Manager",
            "Google Tag Manager",
            "Google Analytics"
          ]
        },
        testimonials: {
          eyebrow: "Testimonials",
          heading: "What clients say about",
          headingAccent: "working together",
          button: "Read All Testimonials"
        },
        cta: {
          heading: "Ready to turn your",
          headingAccent: "marketing into measurable growth?",
          text: "Tell me about your business and your goals, and I will get back to you with a clear next step.",
          button: "Let's Work Together"
        }
      },
      pages: {
        services: {
          eyebrow: "Services",
          heading: "Focused services that",
          headingAccent: "move your business forward",
          intro: "Every engagement starts with a conversation about your goals. From there I plan the work, set it up carefully, test it, and keep you informed in plain language until the job is done and the results are easy to read.",
          cta: {
            heading: "Let's plan your next",
            headingAccent: "campaign together",
            text: "Tell me what you are working on and which service fits best, and I will reply with a clear next step.",
            button: "Get in Touch",
            secondaryLabel: "",
            secondaryPage: ""
          }
        },
        work: {
          eyebrow: "My Work",
          heading: "A closer look at",
          headingAccent: "the work behind the results",
          intro: "A gallery of screenshots from recent projects. Select any card to see it larger, along with a short description of what it shows.",
          cta: {
            heading: "Like what you see?",
            headingAccent: "Let's build yours next.",
            text: "Share a few details about your business and goals, and I will get back to you with a clear plan.",
            button: "Start a Project",
            secondaryLabel: "",
            secondaryPage: ""
          }
        },
        about: {
          eyebrow: "About Me",
          heading: "The person behind",
          headingAccent: "the campaigns",
          intro: "A short introduction to how I think about marketing and how I like to work with the people I work for.",
          storyEyebrow: "My Story",
          photo: "/assets/img/about.svg",
          openingLine: "I believe good marketing starts with good questions and finishes with numbers you can trust.",
          paragraphs: [
            "I work in digital and performance marketing, mostly with paid advertising on Meta and Google, search engine optimization, and the tracking that connects it all. I enjoy the mix of creative thinking and careful measurement that the work asks for.",
            "My approach is simple. I start by understanding what your business is trying to achieve, then I build the campaign and the tracking around that goal. I would rather set things up properly once than patch them later.",
            "I explain what I am doing and why in plain language, because I think you should always know where your budget is going. If something is not working, I will tell you, and we will decide together what to try next.",
            "Away from the dashboards, I like learning how new platforms and features change the way people find and choose businesses. That curiosity keeps my work fresh, and it is a big part of why I enjoy it."
          ],
          signatureName: "MH Mahdi Hasan Akand",
          signatureTitle: "Digital Marketing & Performance Marketing Specialist",
          cta: {
            heading: "Want to work",
            headingAccent: "together?",
            text: "I would be glad to hear about your business and what you are hoping to achieve.",
            button: "Get in Touch",
            secondaryLabel: "View My Work",
            secondaryPage: "work"
          }
        },
        testimonials: {
          eyebrow: "Testimonials",
          heading: "Kind words from",
          headingAccent: "people I have worked with",
          intro: "Feedback from the people I have worked with, in their own words.",
          cta: {
            heading: "Ready to start a",
            headingAccent: "project of your own?",
            text: "Tell me about your goals and I will get back to you with a clear next step.",
            button: "Get in Touch",
            secondaryLabel: "",
            secondaryPage: ""
          }
        },
        contact: {
          eyebrow: "Contact",
          heading: "Let's talk about",
          headingAccent: "your next project",
          intro: "Send me a message with a few details about your business and what you need. I read every message personally and will reply as soon as I can.",
          formHeading: "Send a message",
          formSub: "Fill in the form and I will get back to you by email.",
          serviceUnsure: "Not sure yet",
          privacyNote: "Your details stay private and are only used to reply to you.",
          submitLabel: "Send Message",
          successHeading: "Message Sent",
          successText: "Thank you for getting in touch. I have received your message and will reply soon.",
          successButton: "Write Another Message",
          emailHint: "Best for detailed enquiries",
          phoneHint: "Call to talk things through",
          whatsappHint: "Quick questions and updates",
          findMeTitle: "Find Me Online"
        }
      },
      services: [
        {
          id: "meta-ads",
          title: "Meta Ads",
          category: "Paid Social",
          icon: "megaphone",
          description: "Facebook and Instagram campaigns built around a clear objective, the right audience and creative that earns attention.",
          included: [
            "Campaign and audience structure",
            "Creative testing and iteration",
            "Budget and bid optimisation",
            "Retargeting setup",
            "Conversion tracking checks",
            "Regular performance reviews"
          ],
          note: "Pricing on request"
        },
        {
          id: "google-ads",
          title: "Google Ads",
          category: "Paid Search",
          icon: "target",
          description: "Search and display campaigns that put your offer in front of people who are already looking for it.",
          included: [
            "Keyword and intent research",
            "Ad copy and extension setup",
            "Ongoing bid and query management",
            "Negative keyword management",
            "Search query reviews"
          ],
          note: "Pricing on request"
        },
        {
          id: "seo",
          title: "Search Engine Optimization",
          category: "Organic Growth",
          icon: "search",
          description: "SEO that improves how your website is found, structured and understood by search engines.",
          included: [
            "Technical and on-page review",
            "Keyword and content planning",
            "Visibility and ranking tracking",
            "Page titles and descriptions",
            "Site structure and internal links",
            "Search Console monitoring"
          ],
          note: "Pricing on request"
        },
        {
          id: "gtm-analytics",
          title: "Google Tag Manager & Analytics",
          category: "Tracking",
          icon: "tag",
          description: "A clean tag setup and properly configured analytics, so you can see exactly what is happening on your site.",
          included: [
            "Container and tag configuration",
            "Event and conversion setup",
            "Google Analytics optimisation",
            "Clear trigger and variable naming",
            "Preview and debug testing",
            "Reporting views that are easy to read"
          ],
          note: "Pricing on request"
        },
        {
          id: "pixel-events-manager",
          title: "Meta Pixel & Events Manager",
          category: "Tracking",
          icon: "pixel",
          description: "Reliable browser-side tracking for Meta campaigns, set up, tested and monitored in Events Manager.",
          included: [
            "Pixel installation and checks",
            "Standard and custom events",
            "Events Manager diagnostics",
            "Event testing before launch",
            "Ongoing monitoring"
          ],
          note: "Pricing on request"
        },
        {
          id: "capi",
          title: "Conversions API (CAPI)",
          category: "Server-side Tracking",
          icon: "api",
          description: "Server-side event sharing that complements the Meta Pixel for more complete and dependable measurement.",
          included: [
            "Server-side event setup",
            "Event matching and deduplication",
            "Ongoing data quality checks",
            "Parameter and quality review",
            "Testing inside Events Manager"
          ],
          note: "Pricing on request"
        }
      ],
      projects: [
        {
          id: "p1",
          title: "Campaign Performance Dashboard",
          description: "A single view of spend, reach and conversions across campaigns.",
          image: "/assets/img/work-1.svg",
          date: "2026-09-01"
        },
        {
          id: "p2",
          title: "Tag Manager Container Setup",
          description: "A tidy container with clearly named tags, triggers and variables.",
          image: "/assets/img/work-2.svg",
          date: "2026-08-01"
        },
        {
          id: "p3",
          title: "Events Manager Diagnostics",
          description: "Event checks and match-quality review inside Meta Events Manager.",
          image: "/assets/img/work-3.svg",
          date: "2026-07-01"
        },
        {
          id: "p4",
          title: "Search Visibility Report",
          description: "An organic search overview showing how pages are found over time.",
          image: "/assets/img/work-4.svg",
          date: "2026-06-01"
        },
        {
          id: "p5",
          title: "Ad Account Structure",
          description: "Campaigns, ad sets and ads organised so results are easy to read.",
          image: "/assets/img/work-5.svg",
          date: "2026-05-01"
        },
        {
          id: "p6",
          title: "Analytics Conversion Setup",
          description: "Goals and conversion events configured and verified end to end.",
          image: "/assets/img/work-6.svg",
          date: "2026-04-01"
        },
        {
          id: "p7",
          title: "Ad Creative Testing Board",
          description: "A simple board for comparing creative variations side by side.",
          image: "/assets/img/work-7.svg",
          date: "2026-03-01"
        },
        {
          id: "p8",
          title: "Landing Page Tracking Audit",
          description: "A checklist-style review of the tags and events on a landing page.",
          image: "/assets/img/work-8.svg",
          date: "2026-02-01"
        },
        {
          id: "p9",
          title: "Monthly Reporting Template",
          description: "A clear report layout that explains results in plain language.",
          image: "/assets/img/work-9.svg",
          date: "2026-01-01"
        }
      ],
      testimonials: []
    };
  }
});

// ../src/sanitize.js
var require_sanitize = __commonJS({
  "../src/sanitize.js"(exports2, module2) {
    var Render2 = require_render();
    var HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
    var clean = (v, max) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").slice(0, max);
    var S = (max) => ({ k: "s", max });
    var ML = (max) => ({ k: "s", max, multiline: true });
    var COLOR = { k: "color" };
    var IMG = { k: "img" };
    var URLF = { k: "url" };
    var EMAIL = { k: "email" };
    var NUM = { k: "num" };
    var DATE = { k: "date" };
    var ID = { k: "id" };
    var ENUM = (list) => ({ k: "enum", list });
    var O = (fields) => ({ k: "o", fields });
    var A = (item, max) => ({ k: "a", item, max });
    var head = { eyebrow: S(60), heading: S(120), headingAccent: S(120), sub: S(300) };
    var cta = O({ heading: S(120), headingAccent: S(120), text: S(300), button: S(40), secondaryLabel: S(40), secondaryPage: ENUM(["", "home", "services", "work", "about", "testimonials", "contact"]) });
    var pageHead = { eyebrow: S(60), heading: S(120), headingAccent: S(120), intro: ML(600) };
    var SPEC = O({
      settings: O({ brand: S(80), logoInitials: S(4), logoImage: IMG, favicon: IMG, siteTitle: S(160), metaDescription: S(320), footerDescription: S(300), footerText: S(160) }),
      theme: O({ bg: COLOR, accent: COLOR, accent2: COLOR, text: COLOR }),
      contact: O({ email: EMAIL, phone: S(40), whatsapp: S(40), socials: A(O({ type: ENUM(Render2.SOCIAL_TYPES), url: URLF }), 12) }),
      home: O({
        hero: O({
          pill: S(80),
          nameLine1: S(60),
          nameLine2: S(60),
          profession: S(140),
          rolesLabel: S(40),
          roles: A(S(80), 12),
          taglineA: S(100),
          taglineB: S(100),
          intro: ML(500),
          btnPrimary: S(40),
          btnSecondary: S(40),
          portrait: IMG,
          floatCards: A(O({ value: S(16), label: S(40) }), 2)
        }),
        stats: A(O({ prefix: S(8), value: NUM, suffix: S(8), label: S(60) }), 6),
        services: O(head),
        work: O(Object.assign({ button: S(40) }, head)),
        about: O(Object.assign({ photo: IMG, badgeNumber: S(16), badgeLabel: S(40), p1: ML(600), p2: ML(600), bullets: A(S(100), 6), button: S(40) }, head)),
        tools: O(Object.assign({ chips: A(S(60), 24), marquee: A(S(60), 24) }, head)),
        testimonials: O(Object.assign({ button: S(40) }, head)),
        cta: O({ heading: S(120), headingAccent: S(120), text: S(300), button: S(40) })
      }),
      pages: O({
        services: O(Object.assign({ cta }, pageHead)),
        work: O(Object.assign({ cta }, pageHead)),
        about: O(Object.assign({ cta, storyEyebrow: S(40), photo: IMG, openingLine: ML(300), paragraphs: A(ML(900), 8), signatureName: S(80), signatureTitle: S(140) }, pageHead)),
        testimonials: O(Object.assign({ cta }, pageHead)),
        contact: O(Object.assign({
          formHeading: S(80),
          formSub: S(200),
          serviceUnsure: S(40),
          privacyNote: S(200),
          submitLabel: S(40),
          successHeading: S(60),
          successText: S(240),
          successButton: S(40),
          emailHint: S(80),
          phoneHint: S(80),
          whatsappHint: S(80),
          findMeTitle: S(60)
        }, pageHead))
      }),
      services: A(O({ id: ID, title: S(80), category: S(40), icon: ENUM(Render2.ICON_CHOICES), description: ML(400), included: A(S(120), 8), note: S(80) }), 24),
      projects: A(O({ id: ID, title: S(100), description: ML(300), image: IMG, date: DATE }), 200),
      testimonials: A(O({ name: S(80), role: S(80), service: S(60), text: ML(700), initials: S(3), c1: COLOR, c2: COLOR }), 60)
    });
    function walk(spec, v, key) {
      switch (spec.k) {
        case "s": {
          const t = clean(typeof v === "string" || typeof v === "number" ? v : "", spec.max);
          return spec.multiline ? t : t.replace(/[\r\n]+/g, " ");
        }
        case "color":
          return HEX.test(String(v)) ? String(v).toLowerCase() : void 0;
        case "img": {
          const u = clean(v, 400).trim();
          if (!u) return "";
          if (/^\/(?!\/)[A-Za-z0-9._~\/%-]+$/.test(u) || /^https:\/\/[^\s"'<>]+$/i.test(u)) return u;
          return void 0;
        }
        case "url": {
          const u = clean(v, 400).trim();
          if (!u) return "";
          return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : void 0;
        }
        case "email": {
          const e = clean(v, 120).trim();
          return e === "" || /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/.test(e) ? e : void 0;
        }
        case "num": {
          const n = clean(v, 14).trim();
          return /^\d{1,9}(\.\d{1,2})?$/.test(n) ? n : "0";
        }
        case "date": {
          const d = clean(v, 10);
          return /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : "";
        }
        case "id": {
          const t = clean(v, 40).toLowerCase().replace(/[^a-z0-9-]/g, "");
          return t || "x" + Math.random().toString(36).slice(2, 9);
        }
        case "enum":
          return spec.list.indexOf(v) >= 0 ? v : void 0;
        case "a": {
          if (!Array.isArray(v)) return void 0;
          return v.slice(0, spec.max).map((x) => walk(spec.item, x)).filter((x) => x !== void 0 && !(spec.item.k === "s" && x === ""));
        }
        case "o": {
          if (!v || typeof v !== "object" || Array.isArray(v)) return void 0;
          const out = {};
          Object.keys(spec.fields).forEach((k) => {
            if (!Object.prototype.hasOwnProperty.call(v, k)) return;
            const r = walk(spec.fields[k], v[k], k);
            if (r !== void 0) out[k] = r;
          });
          return out;
        }
      }
      return void 0;
    }
    function clone2(x) {
      return JSON.parse(JSON.stringify(x));
    }
    function fill2(def, val) {
      if (Array.isArray(def)) return Array.isArray(val) ? val : clone2(def);
      if (def && typeof def === "object") {
        const out = {};
        const v = val && typeof val === "object" && !Array.isArray(val) ? val : {};
        Object.keys(def).forEach((k) => {
          out[k] = Object.prototype.hasOwnProperty.call(v, k) ? fill2(def[k], v[k]) : clone2(def[k]);
        });
        return out;
      }
      return val === void 0 || val === null ? def : val;
    }
    function sanitizeContent2(input, defaults) {
      const s = walk(SPEC, input);
      if (!s) return null;
      return fill2(defaults, s);
    }
    module2.exports = { sanitizeContent: sanitizeContent2, fill: fill2, clone: clone2 };
  }
});

// ../src/api.src.js
var crypto = require("crypto");
var { getStore, connectLambda } = require_main3();
var Render = require_render();
var DEFAULTS = require_site();
var { sanitizeContent, fill, clone } = require_sanitize();
var SESSION_SECONDS = 7 * 24 * 3600;
var MAX_FAILS = 5;
var LOCK_MS = 5 * 60 * 1e3;
var MAX_UPLOAD = 35e5;
var MAX_CONTENT_JSON = 6e5;
var MSG_LIMIT = { count: 5, windowMs: 10 * 60 * 1e3 };
var COOKIE = "admin_session";
function respond(status, body, headers) {
  return {
    statusCode: status,
    headers: Object.assign({ "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }, headers || {}),
    body: JSON.stringify(body)
  };
}
var sha = (s) => crypto.createHash("sha256").update(String(s)).digest();
var b64u = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
var fromB64u = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");
var safeEq = (a, b) => {
  const x = sha(a), y = sha(b);
  return crypto.timingSafeEqual(x, y);
};
var hashOf = (content) => crypto.createHash("sha256").update(Render.stable(content)).digest("hex").slice(0, 24);
function lowerHeaders(h) {
  const o = {};
  Object.keys(h || {}).forEach((k) => {
    o[k.toLowerCase()] = h[k];
  });
  return o;
}
function clientId(headers) {
  const ip = headers["x-nf-client-connection-ip"] || headers["client-ip"] || (headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  return crypto.createHash("sha256").update(ip).digest("hex").slice(0, 20);
}
function parseBody(event) {
  if (!event.body) return {};
  const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
  return JSON.parse(raw);
}
var STRONG = false;
function detectConsistency(event) {
  STRONG = false;
  try {
    if (event && event.blobs) {
      const ctx = JSON.parse(Buffer.from(event.blobs, "base64").toString("utf8"));
      STRONG = !!(ctx && ctx.uncachedEdgeURL);
    }
  } catch (e) {
  }
}
function store(name) {
  return STRONG ? getStore({ name, consistency: "strong" }) : getStore(name);
}
async function loadSaved() {
  const saved = await store("content").get("site", { type: "json" });
  return saved ? fill(DEFAULTS, saved) : null;
}
async function loadEffective() {
  return await loadSaved() || clone(DEFAULTS);
}
var SC = { N: 16384, r: 8, p: 1, len: 64 };
function scrypt(pw, salt, o) {
  return new Promise((res, rej) => crypto.scrypt(String(pw), salt, o.len, { N: o.N, r: o.r, p: o.p, maxmem: 64 * 1024 * 1024 }, (e, k) => e ? rej(e) : res(k)));
}
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const dk = await scrypt(pw, salt, SC);
  return ["scrypt", SC.N, SC.r, SC.p, salt.toString("base64"), dk.toString("base64")].join("$");
}
async function verifyPassword(pw, stored) {
  const parts = String(stored || "").split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const o = { N: +parts[1], r: +parts[2], p: +parts[3], len: 64 };
  const want = Buffer.from(parts[5], "base64");
  const got = await scrypt(pw, Buffer.from(parts[4], "base64"), o);
  return want.length === got.length && crypto.timingSafeEqual(want, got);
}
var DUMMY = null;
async function dummyVerify(pw) {
  DUMMY = DUMMY || await hashPassword("dummy-password-for-timing");
  await verifyPassword(pw, DUMMY);
}
async function loadCreds() {
  return await store("auth").get("creds", { type: "json" });
}
async function ensureCreds() {
  let c = await loadCreds();
  if (c) return { creds: c };
  const u = process.env.ADMIN_USERNAME, p = process.env.ADMIN_PASSWORD;
  if (!u || !p) return { error: "The admin account has not been set up yet. In Netlify, add ADMIN_USERNAME and ADMIN_PASSWORD under Site configuration > Environment variables, then redeploy." };
  if (!/^[A-Za-z0-9._@-]{3,40}$/.test(u)) return { error: "ADMIN_USERNAME must be 3 to 40 characters: letters, numbers and . _ @ - only." };
  if (String(p).length < 10) return { error: "ADMIN_PASSWORD must be at least 10 characters." };
  c = { username: u, passwordHash: await hashPassword(p), sv: crypto.randomBytes(12).toString("hex"), updated: Date.now() };
  await store("auth").setJSON("creds", c);
  return { creds: c };
}
async function getSecret() {
  const a = store("auth");
  let s = await a.get("secret");
  if (!s) {
    s = crypto.randomBytes(32).toString("base64");
    await a.set("secret", s);
  }
  return s;
}
async function signSession(creds) {
  const payload = b64u(JSON.stringify({ u: creds.username, sv: creds.sv, exp: Date.now() + SESSION_SECONDS * 1e3 }));
  const sig = b64u(crypto.createHmac("sha256", await getSecret()).update(payload).digest());
  return payload + "." + sig;
}
function cookieHeader(value, maxAge) {
  return COOKIE + "=" + value + "; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=" + maxAge;
}
async function readSession(headers) {
  const m = new RegExp("(?:^|;\\s*)" + COOKIE + "=([^;]+)").exec(headers.cookie || "");
  if (!m) return null;
  const [payload, sig] = m[1].split(".");
  if (!payload || !sig) return null;
  const want = b64u(crypto.createHmac("sha256", await getSecret()).update(payload).digest());
  if (!safeEq(sig, want)) return null;
  let data;
  try {
    data = JSON.parse(fromB64u(payload).toString("utf8"));
  } catch (e) {
    return null;
  }
  if (!data || typeof data.exp !== "number" || data.exp < Date.now()) return null;
  const creds = await loadCreds();
  if (!creds || data.sv !== creds.sv || data.u !== creds.username) return null;
  return { user: creds.username, creds };
}
async function getLock(id) {
  return await store("auth").get("lock-" + id, { type: "json" }) || { count: 0, until: 0 };
}
async function failAttempt(id) {
  const l = await getLock(id);
  if (l.until && l.until < Date.now()) {
    l.count = 0;
    l.until = 0;
  }
  l.count += 1;
  if (l.count >= MAX_FAILS) {
    l.until = Date.now() + LOCK_MS;
    l.count = 0;
  }
  await store("auth").setJSON("lock-" + id, l);
  return l;
}
var clearAttempts = (id) => store("auth").delete("lock-" + id).catch(() => {
});
var TYPES = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", svg: "image/svg+xml", ico: "image/x-icon" };
function detectType(buf) {
  if (buf.length >= 8 && buf.slice(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "png";
  if (buf.length >= 3 && buf[0] === 255 && buf[1] === 216 && buf[2] === 255) return "jpg";
  if (buf.length >= 6 && /^GIF8[79]a$/.test(buf.slice(0, 6).toString("latin1"))) return "gif";
  if (buf.length >= 12 && buf.slice(0, 4).toString("latin1") === "RIFF" && buf.slice(8, 12).toString("latin1") === "WEBP") return "webp";
  if (buf.length >= 4 && buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return "ico";
  const head = buf.slice(0, 2048).toString("utf8").replace(/^﻿/, "");
  if (/^\s*(<\?xml[^>]*\?>\s*)?(<!--[\s\S]*?-->\s*)*(<!DOCTYPE svg[^>]*>\s*)?<svg[\s>]/i.test(head)) return "svg";
  return null;
}
function svgProblem(text) {
  const bad = [
    [/<\s*script/i, "scripts"],
    [/\son[a-z]+\s*=/i, "event handlers"],
    [/javascript\s*:/i, "javascript: links"],
    [/<\s*foreignObject/i, "foreignObject"],
    [/<\s*(iframe|object|embed|link|meta|audio|video|animate|set)\b/i, "embedded content"],
    [/<!ENTITY/i, "entities"],
    [/<\?xml-stylesheet/i, "stylesheets"],
    [/@import/i, "CSS imports"],
    [/(?:xlink:)?href\s*=\s*["'](?!#)/i, "external references"],
    [/url\(\s*["']?\s*(?!#)/i, "external CSS urls"],
    [/["'(]\s*data\s*:/i, "data URLs"]
  ];
  for (const [re, name] of bad) if (re.test(text)) return name;
  return "";
}
function checkImage(filename, buf) {
  const m = /\.([A-Za-z0-9]{2,5})$/.exec(String(filename || ""));
  const ext = m ? m[1].toLowerCase() : "";
  if (!TYPES[ext]) return { error: "Only PNG, JPG, GIF, WEBP, SVG and ICO images are allowed." };
  if (!buf.length) return { error: "The file is empty." };
  if (buf.length > MAX_UPLOAD) return { error: "The file is too large (limit " + Math.round(MAX_UPLOAD / 1048576 * 10) / 10 + " MB)." };
  const real = detectType(buf);
  const norm = ext === "jpeg" ? "jpg" : ext;
  if (real !== norm) return { error: "The file contents do not match its " + ext.toUpperCase() + " extension." };
  if (real === "svg") {
    const p = svgProblem(buf.toString("utf8"));
    if (p) return { error: "This SVG contains " + p + ", which is not allowed." };
  }
  return { ext: norm, type: TYPES[norm] };
}
function imageKey(filename, ext) {
  const base = String(filename || "image").replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "image";
  return crypto.randomBytes(5).toString("hex") + "-" + base + "." + ext;
}
var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validateMessage(b, services, unsure) {
  const e = {};
  const name = String(b.name || "").trim(), email = String(b.email || "").trim(), phone = String(b.phone || "").trim();
  const service = String(b.service || "").trim(), message = String(b.message || "").trim();
  if (name.length < 2 || name.length > 120) e.name = "Please enter your name.";
  if (!EMAIL_RE.test(email) || email.length > 200) e.email = "Please enter a valid email address.";
  if (phone && !/^[0-9+()\-\s.]{6,25}$/.test(phone)) e.phone = "Please enter a valid phone number.";
  if (!service || services.indexOf(service) < 0 && service !== unsure) e.service = "Please choose a service.";
  if (message.length < 10) e.message = "Your message needs at least 10 characters.";
  else if (message.length > 5e3) e.message = "Your message is too long.";
  return { errors: e, value: { name, email, phone, service, message } };
}
exports.handler = async function(event) {
  try {
    connectLambda(event);
  } catch (e) {
  }
  detectConsistency(event);
  const headers = lowerHeaders(event.headers);
  const route = String(event.path || "").replace(/^\/\.netlify\/functions\/api/, "").replace(/^\/api/, "").replace(/\/+$/, "") || "/";
  const method = (event.httpMethod || "GET").toUpperCase();
  if (method === "OPTIONS") return { statusCode: 204, headers: { Allow: "GET, POST, PUT, DELETE" }, body: "" };
  if (method !== "GET" && method !== "HEAD") {
    const origin = headers.origin;
    if (origin) {
      try {
        if (new URL(origin).host !== headers.host) return respond(403, { error: "Cross-site requests are not allowed." });
      } catch (e) {
        return respond(403, { error: "Bad origin." });
      }
    }
  }
  try {
    if ((route === "/content-hash" || route === "/content") && method === "GET") {
      const saved = await loadSaved();
      if (route === "/content-hash") return respond(200, { hash: saved ? hashOf(saved) : null });
      if (!saved) return respond(404, { error: "No saved content" });
      return respond(200, saved);
    }
    let m = /^\/img\/([A-Za-z0-9._-]{1,120})$/.exec(route);
    if (m && (method === "GET" || method === "HEAD")) {
      const got = await store("images").getWithMetadata(m[1], { type: "arrayBuffer" });
      if (!got) return respond(404, { error: "Not found" });
      const type = got.metadata && got.metadata.contentType || "application/octet-stream";
      const h = { "Content-Type": type, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" };
      if (type === "image/svg+xml") h["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
      return { statusCode: 200, headers: h, body: Buffer.from(got.data).toString("base64"), isBase64Encoded: true };
    }
    if (route === "/contact" && method === "POST") {
      let b;
      try {
        b = parseBody(event);
      } catch (e) {
        return respond(400, { error: "Invalid request." });
      }
      if (b && b.website) return respond(200, { ok: true });
      const content = await loadEffective();
      const unsure = content.pages && content.pages.contact && content.pages.contact.serviceUnsure || "Not sure yet";
      const v = validateMessage(b || {}, (content.services || []).map((s) => s.title), unsure);
      if (Object.keys(v.errors).length) return respond(400, { error: "Please check the form.", errors: v.errors });
      const id = clientId(headers), auth = store("auth");
      const rl = await auth.get("rl-" + id, { type: "json" }) || { t: [] };
      rl.t = rl.t.filter((t) => t > Date.now() - MSG_LIMIT.windowMs);
      if (rl.t.length >= MSG_LIMIT.count) return respond(429, { error: "Too many messages. Please wait a little and try again." });
      const key = String(Date.now()).padStart(15, "0") + "-" + crypto.randomBytes(3).toString("hex");
      await store("messages").setJSON(key, Object.assign({ id: key, createdAt: (/* @__PURE__ */ new Date()).toISOString(), read: false }, v.value));
      rl.t.push(Date.now());
      await auth.setJSON("rl-" + id, rl).catch(() => {
      });
      return respond(200, { ok: true });
    }
    if (route === "/login" && method === "POST") {
      let b;
      try {
        b = parseBody(event);
      } catch (e) {
        return respond(400, { error: "Invalid request." });
      }
      const id = clientId(headers);
      const lock = await getLock(id);
      if (lock.until && lock.until > Date.now()) {
        const wait = Math.ceil((lock.until - Date.now()) / 1e3);
        return respond(429, { error: "Too many wrong attempts. Try again in " + Math.ceil(wait / 60) + " minute(s).", retryAfter: wait }, { "Retry-After": String(wait) });
      }
      const ens = await ensureCreds();
      if (ens.error) return respond(503, { error: ens.error, setup: true });
      const username = String(b.username || ""), password = String(b.password || "");
      let ok = false;
      if (safeEq(username, ens.creds.username)) ok = await verifyPassword(password, ens.creds.passwordHash);
      else await dummyVerify(password);
      if (!ok) {
        const l = await failAttempt(id);
        if (l.until > Date.now()) return respond(429, { error: "Too many wrong attempts. Login is locked for 5 minutes.", retryAfter: 300 }, { "Retry-After": "300" });
        return respond(401, { error: "Incorrect username or password.", attemptsLeft: MAX_FAILS - l.count });
      }
      await clearAttempts(id);
      const token = await signSession(ens.creds);
      return respond(200, { ok: true, username: ens.creds.username }, { "Set-Cookie": cookieHeader(token, SESSION_SECONDS) });
    }
    if (route === "/logout" && method === "POST") return respond(200, { ok: true }, { "Set-Cookie": cookieHeader("", 0) });
    if (route === "/me" && method === "GET") {
      const s = await readSession(headers);
      return s ? respond(200, { authenticated: true, username: s.user }) : respond(401, { authenticated: false });
    }
    if (route.indexOf("/admin/") === 0) {
      const session = await readSession(headers);
      if (!session) return respond(401, { error: "Not signed in." });
      if (route === "/admin/content" && method === "GET") return respond(200, await loadEffective());
      if (route === "/admin/content" && method === "PUT") {
        if (String(event.body || "").length > MAX_CONTENT_JSON * 1.4) return respond(413, { error: "Content is too large." });
        let b;
        try {
          b = parseBody(event);
        } catch (e) {
          return respond(400, { error: "Invalid JSON." });
        }
        const clean = sanitizeContent(b, DEFAULTS);
        if (!clean) return respond(400, { error: "Invalid content." });
        if (JSON.stringify(clean).length > MAX_CONTENT_JSON) return respond(413, { error: "Content is too large." });
        await store("content").setJSON("site", clean);
        return respond(200, { ok: true, hash: hashOf(clean), content: clean });
      }
      if (route === "/admin/reset" && method === "POST") {
        const cur = await loadEffective();
        const fresh = clone(DEFAULTS);
        fresh.theme = cur.theme;
        fresh.settings.logoImage = cur.settings.logoImage;
        fresh.settings.favicon = cur.settings.favicon;
        await store("content").setJSON("site", fresh);
        return respond(200, { ok: true, hash: hashOf(fresh), content: fresh });
      }
      if (route === "/admin/images" && method === "GET") {
        const st = store("images");
        const { blobs } = await st.list();
        const items = (await Promise.all(blobs.map(async (b) => {
          const md = await st.getMetadata(b.key).catch(() => null);
          const meta = md && md.metadata || {};
          return { key: b.key, url: "/api/img/" + b.key, name: meta.name || b.key, size: meta.size || 0, type: meta.contentType || "", createdAt: meta.createdAt || "" };
        }))).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
        return respond(200, { images: items });
      }
      if (route === "/admin/images" && method === "POST") {
        let b;
        try {
          b = parseBody(event);
        } catch (e) {
          return respond(400, { error: "Invalid request." });
        }
        if (!b || typeof b.data !== "string") return respond(400, { error: "No file received." });
        const buf = Buffer.from(b.data, "base64");
        const chk = checkImage(b.filename, buf);
        if (chk.error) return respond(400, { error: chk.error });
        const key = imageKey(b.filename, chk.ext);
        const meta = { contentType: chk.type, name: String(b.filename || key).replace(/[^\w .()-]/g, "").slice(0, 80), size: buf.length, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
        await store("images").set(key, buf, { metadata: meta });
        return respond(200, { ok: true, image: { key, url: "/api/img/" + key, name: meta.name, size: meta.size, type: meta.contentType, createdAt: meta.createdAt } });
      }
      m = /^\/admin\/images\/([A-Za-z0-9._-]{1,120})$/.exec(route);
      if (m && method === "DELETE") {
        await store("images").delete(m[1]);
        return respond(200, { ok: true });
      }
      if (route === "/admin/messages" && method === "GET") {
        const st = store("messages");
        const { blobs } = await st.list();
        const keys = blobs.map((x) => x.key).sort().reverse().slice(0, 300);
        const items = (await Promise.all(keys.map((k) => st.get(k, { type: "json" }).catch(() => null)))).filter(Boolean);
        return respond(200, { messages: items, total: blobs.length });
      }
      m = /^\/admin\/messages\/([A-Za-z0-9-]{1,60})(\/read)?$/.exec(route);
      if (m && m[2] && method === "POST") {
        const st = store("messages");
        const msg = await st.get(m[1], { type: "json" });
        if (!msg) return respond(404, { error: "Message not found." });
        msg.read = true;
        await st.setJSON(m[1], msg);
        return respond(200, { ok: true });
      }
      if (m && !m[2] && method === "DELETE") {
        await store("messages").delete(m[1]);
        return respond(200, { ok: true });
      }
      if (route === "/admin/stats" && method === "GET") {
        const ms = store("messages");
        const { blobs } = await ms.list();
        const recent = (await Promise.all(blobs.map((x) => x.key).sort().reverse().slice(0, 300).map((k) => ms.get(k, { type: "json" }).catch(() => null)))).filter(Boolean);
        const imgs = await store("images").list();
        return respond(200, { messages: blobs.length, unread: recent.filter((x) => !x.read).length, images: imgs.blobs.length });
      }
      if (route === "/admin/account" && method === "POST") {
        let b;
        try {
          b = parseBody(event);
        } catch (e) {
          return respond(400, { error: "Invalid request." });
        }
        const id = clientId(headers);
        const lock = await getLock(id);
        if (lock.until && lock.until > Date.now()) return respond(429, { error: "Too many wrong attempts. Try again in a few minutes." });
        const creds = session.creds;
        if (!await verifyPassword(String(b.currentPassword || ""), creds.passwordHash)) {
          const l = await failAttempt(id);
          return respond(l.until > Date.now() ? 429 : 403, { error: "Your current password is not correct." });
        }
        await clearAttempts(id);
        const next = Object.assign({}, creds);
        const nu = b.newUsername == null ? "" : String(b.newUsername).trim(), np = b.newPassword == null ? "" : String(b.newPassword);
        if (!nu && !np) return respond(400, { error: "Enter a new username, a new password, or both." });
        if (nu) {
          if (!/^[A-Za-z0-9._@-]{3,40}$/.test(nu)) return respond(400, { error: "Username must be 3 to 40 characters: letters, numbers and . _ @ - only." });
          next.username = nu;
        }
        if (np) {
          if (np.length < 10) return respond(400, { error: "The new password must be at least 10 characters." });
          if (np.toLowerCase() === next.username.toLowerCase()) return respond(400, { error: "The password must be different from the username." });
          next.passwordHash = await hashPassword(np);
        }
        next.sv = crypto.randomBytes(12).toString("hex");
        next.updated = Date.now();
        await store("auth").setJSON("creds", next);
        const token = await signSession(next);
        return respond(200, { ok: true, username: next.username }, { "Set-Cookie": cookieHeader(token, SESSION_SECONDS) });
      }
      return respond(404, { error: "Not found" });
    }
    return respond(404, { error: "Not found" });
  } catch (err) {
    if (route === "/content-hash") return respond(200, { hash: null });
    console.error("api error", route, err && err.message);
    return respond(503, { error: "Storage is not available. Make sure the site was imported from GitHub, not dragged onto Netlify." });
  }
};
exports._internals = { checkImage, svgProblem, detectType, validateMessage };
