// Netlify Function source. Bundled with esbuild into netlify/functions/api.js
// (a single file with no dependencies to install):  npm run bundle
//
// Public:   GET  /api/content-hash   GET /api/content   GET /api/img/<key>
//           POST /api/contact        POST /api/login    POST /api/logout   GET /api/me
// Admin (every one of these returns 401 without a valid session):
//           GET/PUT /api/admin/content      POST /api/admin/reset
//           GET/POST /api/admin/images      DELETE /api/admin/images/<key>
//           GET /api/admin/messages         POST /api/admin/messages/<key>/read   DELETE /api/admin/messages/<key>
//           GET /api/admin/stats            POST /api/admin/account

const crypto = require('crypto');
const { getStore, connectLambda } = require('@netlify/blobs');
const Render = require('../assets/js/render.js');
const DEFAULTS = require('../content/site.json');
const { sanitizeContent, fill, clone } = require('./sanitize.js');

/* ---------- limits ---------- */
const SESSION_SECONDS = 7 * 24 * 3600;
const MAX_FAILS = 5;
const LOCK_MS = 5 * 60 * 1000;
const MAX_UPLOAD = 3500000;          // raw bytes (base64 in a JSON body must stay under the 6 MB function limit)
const MAX_CONTENT_JSON = 600000;
const MSG_LIMIT = { count: 5, windowMs: 10 * 60 * 1000 };
const COOKIE = 'admin_session';

/* ---------- small helpers ---------- */
function respond(status, body, headers) {
  return {
    statusCode: status,
    headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }, headers || {}),
    body: JSON.stringify(body)
  };
}
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const b64u = (buf) => Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const fromB64u = (s) => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const safeEq = (a, b) => { const x = sha(a), y = sha(b); return crypto.timingSafeEqual(x, y); };
const hashOf = (content) => crypto.createHash('sha256').update(Render.stable(content)).digest('hex').slice(0, 24);

function lowerHeaders(h) { const o = {}; Object.keys(h || {}).forEach((k) => { o[k.toLowerCase()] = h[k]; }); return o; }

function clientId(headers) {
  const ip = headers['x-nf-client-connection-ip'] || headers['client-ip'] || (headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  return crypto.createHash('sha256').update(ip).digest('hex').slice(0, 20);
}

function parseBody(event) {
  if (!event.body) return {};
  const raw = event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body;
  return JSON.parse(raw);
}

/* ---------- storage ---------- */
let STRONG = false;   // 'strong' consistency only when the environment supplies an uncachedEdgeURL
function detectConsistency(event) {
  STRONG = false;
  try {
    if (event && event.blobs) {
      const ctx = JSON.parse(Buffer.from(event.blobs, 'base64').toString('utf8'));
      STRONG = !!(ctx && ctx.uncachedEdgeURL);
    }
  } catch (e) { /* leave eventual */ }
}
function store(name) {
  return STRONG ? getStore({ name, consistency: 'strong' }) : getStore(name);
}

async function loadSaved() {
  const saved = await store('content').get('site', { type: 'json' });
  return saved ? fill(DEFAULTS, saved) : null;
}
async function loadEffective() { return (await loadSaved()) || clone(DEFAULTS); }

/* ---------- passwords: scrypt + random salt, compared in constant time ---------- */
const SC = { N: 16384, r: 8, p: 1, len: 64 };
function scrypt(pw, salt, o) {
  return new Promise((res, rej) => crypto.scrypt(String(pw), salt, o.len, { N: o.N, r: o.r, p: o.p, maxmem: 64 * 1024 * 1024 }, (e, k) => (e ? rej(e) : res(k))));
}
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const dk = await scrypt(pw, salt, SC);
  return ['scrypt', SC.N, SC.r, SC.p, salt.toString('base64'), dk.toString('base64')].join('$');
}
async function verifyPassword(pw, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const o = { N: +parts[1], r: +parts[2], p: +parts[3], len: 64 };
  const want = Buffer.from(parts[5], 'base64');
  const got = await scrypt(pw, Buffer.from(parts[4], 'base64'), o);
  return want.length === got.length && crypto.timingSafeEqual(want, got);
}
let DUMMY = null;   // used so an unknown username costs the same time as a wrong password
async function dummyVerify(pw) { DUMMY = DUMMY || (await hashPassword('dummy-password-for-timing')); await verifyPassword(pw, DUMMY); }

/* ---------- credentials ---------- */
async function loadCreds() { return await store('auth').get('creds', { type: 'json' }); }

// First use: credentials come from the ADMIN_USERNAME / ADMIN_PASSWORD environment variables.
// They are hashed and stored; after that the environment variables are no longer consulted.
async function ensureCreds() {
  let c = await loadCreds();
  if (c) return { creds: c };
  const u = process.env.ADMIN_USERNAME, p = process.env.ADMIN_PASSWORD;
  if (!u || !p) return { error: 'The admin account has not been set up yet. In Netlify, add ADMIN_USERNAME and ADMIN_PASSWORD under Site configuration > Environment variables, then redeploy.' };
  if (!/^[A-Za-z0-9._@-]{3,40}$/.test(u)) return { error: 'ADMIN_USERNAME must be 3 to 40 characters: letters, numbers and . _ @ - only.' };
  if (String(p).length < 10) return { error: 'ADMIN_PASSWORD must be at least 10 characters.' };
  c = { username: u, passwordHash: await hashPassword(p), sv: crypto.randomBytes(12).toString('hex'), updated: Date.now() };
  await store('auth').setJSON('creds', c);
  return { creds: c };
}

/* ---------- sessions: HMAC-signed, HttpOnly, SameSite=Lax, Secure, with expiry ---------- */
async function getSecret() {
  const a = store('auth');
  let s = await a.get('secret');
  if (!s) { s = crypto.randomBytes(32).toString('base64'); await a.set('secret', s); }
  return s;
}
async function signSession(creds) {
  const payload = b64u(JSON.stringify({ u: creds.username, sv: creds.sv, exp: Date.now() + SESSION_SECONDS * 1000 }));
  const sig = b64u(crypto.createHmac('sha256', await getSecret()).update(payload).digest());
  return payload + '.' + sig;
}
function cookieHeader(value, maxAge) {
  return COOKIE + '=' + value + '; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=' + maxAge;
}
async function readSession(headers) {
  const m = new RegExp('(?:^|;\\s*)' + COOKIE + '=([^;]+)').exec(headers.cookie || '');
  if (!m) return null;
  const [payload, sig] = m[1].split('.');
  if (!payload || !sig) return null;
  const want = b64u(crypto.createHmac('sha256', await getSecret()).update(payload).digest());
  if (!safeEq(sig, want)) return null;
  let data;
  try { data = JSON.parse(fromB64u(payload).toString('utf8')); } catch (e) { return null; }
  if (!data || typeof data.exp !== 'number' || data.exp < Date.now()) return null;
  const creds = await loadCreds();
  // Changing the username or password rotates `sv`, which invalidates every older session.
  if (!creds || data.sv !== creds.sv || data.u !== creds.username) return null;
  return { user: creds.username, creds };
}

/* ---------- login throttling: 5 wrong attempts locks that connection for 5 minutes ---------- */
async function getLock(id) { return (await store('auth').get('lock-' + id, { type: 'json' })) || { count: 0, until: 0 }; }
async function failAttempt(id) {
  const l = await getLock(id);
  if (l.until && l.until < Date.now()) { l.count = 0; l.until = 0; }
  l.count += 1;
  if (l.count >= MAX_FAILS) { l.until = Date.now() + LOCK_MS; l.count = 0; }
  await store('auth').setJSON('lock-' + id, l);
  return l;
}
const clearAttempts = (id) => store('auth').delete('lock-' + id).catch(() => {});

/* ---------- images: extension AND signature, SVG scripts rejected ---------- */
const TYPES = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon' };
function detectType(buf) {
  if (buf.length >= 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length >= 6 && /^GIF8[79]a$/.test(buf.slice(0, 6).toString('latin1'))) return 'gif';
  if (buf.length >= 12 && buf.slice(0, 4).toString('latin1') === 'RIFF' && buf.slice(8, 12).toString('latin1') === 'WEBP') return 'webp';
  if (buf.length >= 4 && buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return 'ico';
  const head = buf.slice(0, 2048).toString('utf8').replace(/^﻿/, '');
  if (/^\s*(<\?xml[^>]*\?>\s*)?(<!--[\s\S]*?-->\s*)*(<!DOCTYPE svg[^>]*>\s*)?<svg[\s>]/i.test(head)) return 'svg';
  return null;
}
function svgProblem(text) {
  const bad = [
    [/<\s*script/i, 'scripts'], [/\son[a-z]+\s*=/i, 'event handlers'], [/javascript\s*:/i, 'javascript: links'],
    [/<\s*foreignObject/i, 'foreignObject'], [/<\s*(iframe|object|embed|link|meta|audio|video|animate|set)\b/i, 'embedded content'],
    [/<!ENTITY/i, 'entities'], [/<\?xml-stylesheet/i, 'stylesheets'], [/@import/i, 'CSS imports'],
    [/(?:xlink:)?href\s*=\s*["'](?!#)/i, 'external references'], [/url\(\s*["']?\s*(?!#)/i, 'external CSS urls'], [/["'(]\s*data\s*:/i, 'data URLs']
  ];
  for (const [re, name] of bad) if (re.test(text)) return name;
  return '';
}
function checkImage(filename, buf) {
  const m = /\.([A-Za-z0-9]{2,5})$/.exec(String(filename || ''));
  const ext = m ? m[1].toLowerCase() : '';
  if (!TYPES[ext]) return { error: 'Only PNG, JPG, GIF, WEBP, SVG and ICO images are allowed.' };
  if (!buf.length) return { error: 'The file is empty.' };
  if (buf.length > MAX_UPLOAD) return { error: 'The file is too large (limit ' + Math.round(MAX_UPLOAD / 1048576 * 10) / 10 + ' MB).' };
  const real = detectType(buf);
  const norm = ext === 'jpeg' ? 'jpg' : ext;
  if (real !== norm) return { error: 'The file contents do not match its ' + ext.toUpperCase() + ' extension.' };
  if (real === 'svg') {
    const p = svgProblem(buf.toString('utf8'));
    if (p) return { error: 'This SVG contains ' + p + ', which is not allowed.' };
  }
  return { ext: norm, type: TYPES[norm] };
}
function imageKey(filename, ext) {
  const base = String(filename || 'image').replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'image';
  return crypto.randomBytes(5).toString('hex') + '-' + base + '.' + ext;
}

/* ---------- contact messages ---------- */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validateMessage(b, services, unsure) {
  const e = {};
  const name = String(b.name || '').trim(), email = String(b.email || '').trim(), phone = String(b.phone || '').trim();
  const service = String(b.service || '').trim(), message = String(b.message || '').trim();
  if (name.length < 2 || name.length > 120) e.name = 'Please enter your name.';
  if (!EMAIL_RE.test(email) || email.length > 200) e.email = 'Please enter a valid email address.';
  if (phone && !/^[0-9+()\-\s.]{6,25}$/.test(phone)) e.phone = 'Please enter a valid phone number.';
  if (!service || services.indexOf(service) < 0 && service !== unsure) e.service = 'Please choose a service.';
  if (message.length < 10) e.message = 'Your message needs at least 10 characters.';
  else if (message.length > 5000) e.message = 'Your message is too long.';
  return { errors: e, value: { name, email, phone, service, message } };
}

/* ---------- handler ---------- */
exports.handler = async function (event) {
  // Lambda-style functions do not get Blobs configured automatically.
  try { connectLambda(event); } catch (e) { /* surfaced below when storage is touched */ }
  detectConsistency(event);

  const headers = lowerHeaders(event.headers);
  const route = String(event.path || '').replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '').replace(/\/+$/, '') || '/';
  const method = (event.httpMethod || 'GET').toUpperCase();
  if (method === 'OPTIONS') return { statusCode: 204, headers: { Allow: 'GET, POST, PUT, DELETE' }, body: '' };

  // Writes must come from this site (SameSite=Lax already blocks cross-site cookies; this is a second lock).
  if (method !== 'GET' && method !== 'HEAD') {
    const origin = headers.origin;
    if (origin) { try { if (new URL(origin).host !== headers.host) return respond(403, { error: 'Cross-site requests are not allowed.' }); } catch (e) { return respond(403, { error: 'Bad origin.' }); } }
  }

  try {
    /* ----- public reads ----- */
    if ((route === '/content-hash' || route === '/content') && method === 'GET') {
      const saved = await loadSaved();
      if (route === '/content-hash') return respond(200, { hash: saved ? hashOf(saved) : null });
      if (!saved) return respond(404, { error: 'No saved content' });
      return respond(200, saved);
    }

    let m = /^\/img\/([A-Za-z0-9._-]{1,120})$/.exec(route);
    if (m && (method === 'GET' || method === 'HEAD')) {
      const got = await store('images').getWithMetadata(m[1], { type: 'arrayBuffer' });
      if (!got) return respond(404, { error: 'Not found' });
      const type = (got.metadata && got.metadata.contentType) || 'application/octet-stream';
      const h = { 'Content-Type': type, 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' };
      if (type === 'image/svg+xml') h['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
      return { statusCode: 200, headers: h, body: Buffer.from(got.data).toString('base64'), isBase64Encoded: true };
    }

    /* ----- public: contact form ----- */
    if (route === '/contact' && method === 'POST') {
      let b;
      try { b = parseBody(event); } catch (e) { return respond(400, { error: 'Invalid request.' }); }
      if (b && b.website) return respond(200, { ok: true });          // honeypot: bots get a quiet success, nothing is stored
      const content = await loadEffective();
      const unsure = (content.pages && content.pages.contact && content.pages.contact.serviceUnsure) || 'Not sure yet';
      const v = validateMessage(b || {}, (content.services || []).map((s) => s.title), unsure);
      if (Object.keys(v.errors).length) return respond(400, { error: 'Please check the form.', errors: v.errors });
      const id = clientId(headers), auth = store('auth');
      const rl = (await auth.get('rl-' + id, { type: 'json' })) || { t: [] };
      rl.t = rl.t.filter((t) => t > Date.now() - MSG_LIMIT.windowMs);
      if (rl.t.length >= MSG_LIMIT.count) return respond(429, { error: 'Too many messages. Please wait a little and try again.' });
      const key = String(Date.now()).padStart(15, '0') + '-' + crypto.randomBytes(3).toString('hex');
      await store('messages').setJSON(key, Object.assign({ id: key, createdAt: new Date().toISOString(), read: false }, v.value));
      rl.t.push(Date.now());
      await auth.setJSON('rl-' + id, rl).catch(() => {});
      return respond(200, { ok: true });                               // only after the message is stored
    }

    /* ----- public: auth ----- */
    if (route === '/login' && method === 'POST') {
      let b;
      try { b = parseBody(event); } catch (e) { return respond(400, { error: 'Invalid request.' }); }
      const id = clientId(headers);
      const lock = await getLock(id);
      if (lock.until && lock.until > Date.now()) {
        const wait = Math.ceil((lock.until - Date.now()) / 1000);
        return respond(429, { error: 'Too many wrong attempts. Try again in ' + Math.ceil(wait / 60) + ' minute(s).', retryAfter: wait }, { 'Retry-After': String(wait) });
      }
      const ens = await ensureCreds();
      if (ens.error) return respond(503, { error: ens.error, setup: true });
      const username = String(b.username || ''), password = String(b.password || '');
      let ok = false;
      if (safeEq(username, ens.creds.username)) ok = await verifyPassword(password, ens.creds.passwordHash);
      else await dummyVerify(password);
      if (!ok) {
        const l = await failAttempt(id);
        if (l.until > Date.now()) return respond(429, { error: 'Too many wrong attempts. Login is locked for 5 minutes.', retryAfter: 300 }, { 'Retry-After': '300' });
        return respond(401, { error: 'Incorrect username or password.', attemptsLeft: MAX_FAILS - l.count });
      }
      await clearAttempts(id);
      const token = await signSession(ens.creds);
      return respond(200, { ok: true, username: ens.creds.username }, { 'Set-Cookie': cookieHeader(token, SESSION_SECONDS) });
    }
    if (route === '/logout' && method === 'POST') return respond(200, { ok: true }, { 'Set-Cookie': cookieHeader('', 0) });
    if (route === '/me' && method === 'GET') {
      const s = await readSession(headers);
      return s ? respond(200, { authenticated: true, username: s.user }) : respond(401, { authenticated: false });
    }

    /* ----- everything under /admin needs a valid session ----- */
    if (route.indexOf('/admin/') === 0) {
      const session = await readSession(headers);
      if (!session) return respond(401, { error: 'Not signed in.' });

      if (route === '/admin/content' && method === 'GET') return respond(200, await loadEffective());

      if (route === '/admin/content' && method === 'PUT') {
        if (String(event.body || '').length > MAX_CONTENT_JSON * 1.4) return respond(413, { error: 'Content is too large.' });
        let b;
        try { b = parseBody(event); } catch (e) { return respond(400, { error: 'Invalid JSON.' }); }
        const clean = sanitizeContent(b, DEFAULTS);
        if (!clean) return respond(400, { error: 'Invalid content.' });
        if (JSON.stringify(clean).length > MAX_CONTENT_JSON) return respond(413, { error: 'Content is too large.' });
        await store('content').setJSON('site', clean);
        return respond(200, { ok: true, hash: hashOf(clean), content: clean });
      }

      if (route === '/admin/reset' && method === 'POST') {
        // Restores the original text and lists. Images, theme, logo, tab icon, inbox and login are kept.
        const cur = await loadEffective();
        const fresh = clone(DEFAULTS);
        fresh.theme = cur.theme;
        fresh.settings.logoImage = cur.settings.logoImage;
        fresh.settings.favicon = cur.settings.favicon;
        await store('content').setJSON('site', fresh);
        return respond(200, { ok: true, hash: hashOf(fresh), content: fresh });
      }

      if (route === '/admin/images' && method === 'GET') {
        const st = store('images');
        const { blobs } = await st.list();
        const items = (await Promise.all(blobs.map(async (b) => {
          const md = await st.getMetadata(b.key).catch(() => null);
          const meta = (md && md.metadata) || {};
          return { key: b.key, url: '/api/img/' + b.key, name: meta.name || b.key, size: meta.size || 0, type: meta.contentType || '', createdAt: meta.createdAt || '' };
        }))).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
        return respond(200, { images: items });
      }

      if (route === '/admin/images' && method === 'POST') {
        let b;
        try { b = parseBody(event); } catch (e) { return respond(400, { error: 'Invalid request.' }); }
        if (!b || typeof b.data !== 'string') return respond(400, { error: 'No file received.' });
        const buf = Buffer.from(b.data, 'base64');
        const chk = checkImage(b.filename, buf);
        if (chk.error) return respond(400, { error: chk.error });
        const key = imageKey(b.filename, chk.ext);
        const meta = { contentType: chk.type, name: String(b.filename || key).replace(/[^\w .()-]/g, '').slice(0, 80), size: buf.length, createdAt: new Date().toISOString() };
        await store('images').set(key, buf, { metadata: meta });
        return respond(200, { ok: true, image: { key, url: '/api/img/' + key, name: meta.name, size: meta.size, type: meta.contentType, createdAt: meta.createdAt } });
      }

      m = /^\/admin\/images\/([A-Za-z0-9._-]{1,120})$/.exec(route);
      if (m && method === 'DELETE') { await store('images').delete(m[1]); return respond(200, { ok: true }); }

      if (route === '/admin/messages' && method === 'GET') {
        const st = store('messages');
        const { blobs } = await st.list();
        const keys = blobs.map((x) => x.key).sort().reverse().slice(0, 300);
        const items = (await Promise.all(keys.map((k) => st.get(k, { type: 'json' }).catch(() => null)))).filter(Boolean);
        return respond(200, { messages: items, total: blobs.length });
      }
      m = /^\/admin\/messages\/([A-Za-z0-9-]{1,60})(\/read)?$/.exec(route);
      if (m && m[2] && method === 'POST') {
        const st = store('messages');
        const msg = await st.get(m[1], { type: 'json' });
        if (!msg) return respond(404, { error: 'Message not found.' });
        msg.read = true;
        await st.setJSON(m[1], msg);
        return respond(200, { ok: true });
      }
      if (m && !m[2] && method === 'DELETE') { await store('messages').delete(m[1]); return respond(200, { ok: true }); }

      if (route === '/admin/stats' && method === 'GET') {
        const ms = store('messages');
        const { blobs } = await ms.list();
        const recent = (await Promise.all(blobs.map((x) => x.key).sort().reverse().slice(0, 300).map((k) => ms.get(k, { type: 'json' }).catch(() => null)))).filter(Boolean);
        const imgs = await store('images').list();
        return respond(200, { messages: blobs.length, unread: recent.filter((x) => !x.read).length, images: imgs.blobs.length });
      }

      if (route === '/admin/account' && method === 'POST') {
        let b;
        try { b = parseBody(event); } catch (e) { return respond(400, { error: 'Invalid request.' }); }
        const id = clientId(headers);
        const lock = await getLock(id);
        if (lock.until && lock.until > Date.now()) return respond(429, { error: 'Too many wrong attempts. Try again in a few minutes.' });
        const creds = session.creds;
        if (!(await verifyPassword(String(b.currentPassword || ''), creds.passwordHash))) {
          const l = await failAttempt(id);
          // 403, not 401: the admin IS signed in. A 401 would make the panel think the session ended.
          return respond(l.until > Date.now() ? 429 : 403, { error: 'Your current password is not correct.' });
        }
        await clearAttempts(id);
        const next = Object.assign({}, creds);
        const nu = b.newUsername == null ? '' : String(b.newUsername).trim(), np = b.newPassword == null ? '' : String(b.newPassword);
        if (!nu && !np) return respond(400, { error: 'Enter a new username, a new password, or both.' });
        if (nu) {
          if (!/^[A-Za-z0-9._@-]{3,40}$/.test(nu)) return respond(400, { error: 'Username must be 3 to 40 characters: letters, numbers and . _ @ - only.' });
          next.username = nu;
        }
        if (np) {
          if (np.length < 10) return respond(400, { error: 'The new password must be at least 10 characters.' });
          if (np.toLowerCase() === next.username.toLowerCase()) return respond(400, { error: 'The password must be different from the username.' });
          next.passwordHash = await hashPassword(np);
        }
        next.sv = crypto.randomBytes(12).toString('hex');   // invalidates every existing session
        next.updated = Date.now();
        await store('auth').setJSON('creds', next);
        const token = await signSession(next);               // keeps this browser signed in
        return respond(200, { ok: true, username: next.username }, { 'Set-Cookie': cookieHeader(token, SESSION_SECONDS) });
      }

      return respond(404, { error: 'Not found' });
    }

    return respond(404, { error: 'Not found' });
  } catch (err) {
    // Storage not reachable (for example before the site is connected to GitHub): the pre-built
    // pages keep working and the boot script simply sees "nothing saved".
    if (route === '/content-hash') return respond(200, { hash: null });
    console.error('api error', route, err && err.message);
    return respond(503, { error: 'Storage is not available. Make sure the site was imported from GitHub, not dragged onto Netlify.' });
  }
};

exports._internals = { checkImage, svgProblem, detectType, validateMessage };
