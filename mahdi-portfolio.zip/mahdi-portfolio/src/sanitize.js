// Saved content is filtered through this schema: only known keys survive, every value is
// coerced to the expected type and length, and anything unexpected is dropped.
// Missing keys are filled from the built-in defaults, but arrays are never refilled:
// if a list was saved empty, it stays empty.
const Render = require('../assets/js/render.js');

const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
const clean = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').slice(0, max);

const S = (max) => ({ k: 's', max });
const ML = (max) => ({ k: 's', max, multiline: true });
const COLOR = { k: 'color' };
const IMG = { k: 'img' };
const URLF = { k: 'url' };
const EMAIL = { k: 'email' };
const NUM = { k: 'num' };
const DATE = { k: 'date' };
const ID = { k: 'id' };
const ENUM = (list) => ({ k: 'enum', list });
const O = (fields) => ({ k: 'o', fields });
const A = (item, max) => ({ k: 'a', item, max });

const head = { eyebrow: S(60), heading: S(120), headingAccent: S(120), sub: S(300) };
const cta = O({ heading: S(120), headingAccent: S(120), text: S(300), button: S(40), secondaryLabel: S(40), secondaryPage: ENUM(['', 'home', 'services', 'work', 'about', 'testimonials', 'contact']) });
const pageHead = { eyebrow: S(60), heading: S(120), headingAccent: S(120), intro: ML(600) };

const SPEC = O({
  settings: O({ brand: S(80), logoInitials: S(4), logoImage: IMG, favicon: IMG, siteTitle: S(160), metaDescription: S(320), footerDescription: S(300), footerText: S(160) }),
  theme: O({ bg: COLOR, accent: COLOR, accent2: COLOR, text: COLOR }),
  contact: O({ email: EMAIL, phone: S(40), whatsapp: S(40), socials: A(O({ type: ENUM(Render.SOCIAL_TYPES), url: URLF }), 12) }),
  home: O({
    hero: O({
      pill: S(80), nameLine1: S(60), nameLine2: S(60), profession: S(140), rolesLabel: S(40), roles: A(S(80), 12),
      taglineA: S(100), taglineB: S(100), intro: ML(500), btnPrimary: S(40), btnSecondary: S(40), portrait: IMG,
      floatCards: A(O({ value: S(16), label: S(40) }), 2)
    }),
    stats: A(O({ prefix: S(8), value: NUM, suffix: S(8), label: S(60) }), 6),
    services: O(head),
    work: O(Object.assign({ button: S(40) }, head)),
    about: O(Object.assign({ photo: IMG, badgeNumber: S(16), badgeLabel: S(40), p1: ML(600), p2: ML(600), bullets: A(S(100), 6), button: S(40) }, head)),
    tools: O(Object.assign({ chips: A(S(60), 24), marquee: A(S(60), 24) }, head)),
    testimonials: O(Object.assign({ button: S(40) }, head)),
    cta: O({ heading: S(120), headingAccent: S(120), text: S(300), button: S(40) })
  }),
  pages: O({
    services: O(Object.assign({ cta }, pageHead)),
    work: O(Object.assign({ cta }, pageHead)),
    about: O(Object.assign({ cta, storyEyebrow: S(40), photo: IMG, openingLine: ML(300), paragraphs: A(ML(900), 8), signatureName: S(80), signatureTitle: S(140) }, pageHead)),
    testimonials: O(Object.assign({ cta }, pageHead)),
    contact: O(Object.assign({
      formHeading: S(80), formSub: S(200), serviceUnsure: S(40), privacyNote: S(200), submitLabel: S(40),
      successHeading: S(60), successText: S(240), successButton: S(40), emailHint: S(80), phoneHint: S(80), whatsappHint: S(80), findMeTitle: S(60)
    }, pageHead))
  }),
  services: A(O({ id: ID, title: S(80), category: S(40), icon: ENUM(Render.ICON_CHOICES), description: ML(400), included: A(S(120), 8), note: S(80) }), 24),
  projects: A(O({ id: ID, title: S(100), description: ML(300), image: IMG, date: DATE }), 200),
  testimonials: A(O({ name: S(80), role: S(80), service: S(60), text: ML(700), initials: S(3), c1: COLOR, c2: COLOR }), 60)
});

function walk(spec, v, key) {
  switch (spec.k) {
    case 's': { const t = clean(typeof v === 'string' || typeof v === 'number' ? v : '', spec.max); return spec.multiline ? t : t.replace(/[\r\n]+/g, ' '); }
    case 'color': return HEX.test(String(v)) ? String(v).toLowerCase() : undefined;
    case 'img': {
      const u = clean(v, 400).trim();
      if (!u) return '';
      if (/^\/(?!\/)[A-Za-z0-9._~\/%-]+$/.test(u) || /^https:\/\/[^\s"'<>]+$/i.test(u)) return u;
      return undefined;
    }
    case 'url': {
      const u = clean(v, 400).trim();
      if (!u) return '';
      return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : undefined;
    }
    case 'email': {
      const e = clean(v, 120).trim();
      return e === '' || /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/.test(e) ? e : undefined;
    }
    case 'num': { const n = clean(v, 14).trim(); return /^\d{1,9}(\.\d{1,2})?$/.test(n) ? n : '0'; }
    case 'date': { const d = clean(v, 10); return /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : ''; }
    case 'id': { const t = clean(v, 40).toLowerCase().replace(/[^a-z0-9-]/g, ''); return t || 'x' + Math.random().toString(36).slice(2, 9); }
    case 'enum': return spec.list.indexOf(v) >= 0 ? v : undefined;
    case 'a': {
      if (!Array.isArray(v)) return undefined;
      return v.slice(0, spec.max).map((x) => walk(spec.item, x)).filter((x) => x !== undefined && !(spec.item.k === 's' && x === ''));
    }
    case 'o': {
      if (!v || typeof v !== 'object' || Array.isArray(v)) return undefined;
      const out = {};
      Object.keys(spec.fields).forEach((k) => {
        if (!Object.prototype.hasOwnProperty.call(v, k)) return;
        const r = walk(spec.fields[k], v[k], k);
        if (r !== undefined) out[k] = r;
      });
      return out;
    }
  }
  return undefined;
}

function clone(x) { return JSON.parse(JSON.stringify(x)); }

// Fill keys that are missing from `val` using `def`. Arrays that are present are kept as they are.
function fill(def, val) {
  if (Array.isArray(def)) return Array.isArray(val) ? val : clone(def);
  if (def && typeof def === 'object') {
    const out = {};
    const v = val && typeof val === 'object' && !Array.isArray(val) ? val : {};
    Object.keys(def).forEach((k) => { out[k] = Object.prototype.hasOwnProperty.call(v, k) ? fill(def[k], v[k]) : clone(def[k]); });
    return out;
  }
  return val === undefined || val === null ? def : val;
}

function sanitizeContent(input, defaults) {
  const s = walk(SPEC, input);
  if (!s) return null;
  return fill(defaults, s);
}

module.exports = { sanitizeContent, fill, clone };
