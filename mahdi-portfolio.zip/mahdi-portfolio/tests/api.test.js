// End-to-end API tests. Starts tools/dev-server.js (function bundled against the file-backed Blobs
// stand-in) and drives it over HTTP. Run: cd tools && npm run test
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const root = path.join(__dirname, '..');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'blobs-'));
const PORT = 8911;
const BASE = 'http://127.0.0.1:' + PORT;
let pass = 0, fail = 0;
const results = [];
function ok(name, cond, extra) {
  if (cond) { pass++; results.push('PASS  ' + name); } else { fail++; results.push('FAIL  ' + name + (extra ? '  -> ' + extra : '')); }
}
function start(env) {
  const p = spawn('node', [path.join(root, 'tools', 'dev-server.js'), String(PORT)], { env: Object.assign({}, process.env, { FAKE_BLOBS_DIR: dataDir }, env), stdio: 'ignore' });
  return new Promise((r) => setTimeout(() => r(p), 700));
}
const stop = (p) => new Promise((r) => { p.on('exit', r); p.kill(); });

let ipN = 0;
const newIp = () => '10.9.' + (++ipN >> 8) + '.' + (ipN & 255);
async function call(method, url, body, o) {
  o = o || {};
  const headers = { 'x-nf-client-connection-ip': o.ip || '10.0.0.1' };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (o.cookie) headers.cookie = o.cookie;
  if (o.origin) headers.origin = o.origin;
  const r = await fetch(BASE + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch (e) {}
  const sc = (r.headers.getSetCookie && r.headers.getSetCookie()) || [];
  return { status: r.status, json, text, headers: r.headers, setCookie: sc[0] || '', raw: r };
}
const cookieOf = (sc) => (sc.split(';')[0] || '');

(async () => {
  // ---------- phase 1: no admin credentials configured ----------
  let srv = await start({});
  let r = await call('POST', '/api/login', { username: 'a', password: 'b' });
  ok('login before setup explains what to do (503)', r.status === 503 && /ADMIN_USERNAME/.test(r.json.error), r.text);
  await stop(srv);

  // ---------- phase 2: configured ----------
  const USER = 'owner', PASS = 'correct-horse-battery';
  srv = await start({ ADMIN_USERNAME: USER, ADMIN_PASSWORD: PASS });

  // every admin endpoint is 401 without a session
  const adminCalls = [
    ['GET', '/api/admin/content'], ['PUT', '/api/admin/content', {}], ['POST', '/api/admin/reset', {}],
    ['GET', '/api/admin/images'], ['POST', '/api/admin/images', { filename: 'a.png', data: '' }], ['DELETE', '/api/admin/images/abc.png'],
    ['GET', '/api/admin/messages'], ['POST', '/api/admin/messages/x/read', {}], ['DELETE', '/api/admin/messages/x'],
    ['GET', '/api/admin/stats'], ['POST', '/api/admin/account', { currentPassword: 'x', newPassword: 'longenoughpass' }]
  ];
  let all401 = true, bad = '';
  for (const [m, u, b] of adminCalls) { const x = await call(m, u, b); if (x.status !== 401) { all401 = false; bad += m + ' ' + u + '=' + x.status + ' '; } }
  ok('all ' + adminCalls.length + ' admin endpoints return 401 without a session', all401, bad);
  ok('/api/me is 401 without a session', (await call('GET', '/api/me')).status === 401);

  // wrong password, then lockout after 5
  const lockIp = newIp();
  const codes = [];
  for (let i = 0; i < 5; i++) { const x = await call('POST', '/api/login', { username: USER, password: 'wrong-' + i }, { ip: lockIp }); codes.push(x.status); if (i === 0) ok('wrong password -> 401 with attempts left', x.status === 401 && x.json.attemptsLeft === 4, x.text); }
  ok('5th wrong attempt locks login (429)', codes.slice(0, 4).every((c) => c === 401) && codes[4] === 429, codes.join(','));
  const locked = await call('POST', '/api/login', { username: USER, password: PASS }, { ip: lockIp });
  ok('correct password is refused while locked', locked.status === 429 && /minute/.test(locked.json.error), locked.text);
  const wrongUser = await call('POST', '/api/login', { username: 'nobody', password: PASS }, { ip: newIp() });
  ok('unknown username -> 401, same message', wrongUser.status === 401 && wrongUser.json.error === 'Incorrect username or password.');

  // right login
  const okIp = newIp();
  r = await call('POST', '/api/login', { username: USER, password: PASS }, { ip: okIp });
  ok('correct login -> 200', r.status === 200 && r.json.ok === true, r.text);
  const sc = r.setCookie;
  ok('cookie is HttpOnly + Secure + SameSite=Lax with Max-Age', /HttpOnly/.test(sc) && /Secure/.test(sc) && /SameSite=Lax/.test(sc) && /Max-Age=\d+/.test(sc), sc);
  const cookie = cookieOf(sc);
  ok('/api/me recognises the session', (await call('GET', '/api/me', undefined, { cookie })).json.authenticated === true);
  const stored = JSON.parse(fs.readFileSync(path.join(dataDir, 'auth', Buffer.from('creds').toString('hex')), 'utf8'));
  ok('password stored as scrypt hash with salt, never plain text', /^scrypt\$16384\$8\$1\$/.test(stored.passwordHash) && !JSON.stringify(stored).includes(PASS));

  // tampered / forged / expired cookies
  const [payload, sig] = cookie.split('=')[1].split('.');
  ok('tampered signature rejected', (await call('GET', '/api/admin/stats', undefined, { cookie: 'admin_session=' + payload + '.' + sig.slice(0, -2) + 'AA' })).status === 401);
  const secret = fs.readFileSync(path.join(dataDir, 'auth', Buffer.from('secret').toString('hex')), 'utf8');
  const forge = (obj, key) => { const p = Buffer.from(JSON.stringify(obj)).toString('base64url'); return 'admin_session=' + p + '.' + crypto.createHmac('sha256', key).update(p).digest('base64url'); };
  const good = JSON.parse(Buffer.from(payload, 'base64url').toString());
  ok('expired session rejected even with a valid signature', (await call('GET', '/api/admin/stats', undefined, { cookie: forge({ u: good.u, sv: good.sv, exp: Date.now() - 1000 }, secret) })).status === 401);
  ok('session signed with the wrong secret rejected', (await call('GET', '/api/admin/stats', undefined, { cookie: forge({ u: good.u, sv: good.sv, exp: Date.now() + 99999 }, 'not-the-secret') })).status === 401);
  ok('cross-site origin on a write is refused (403)', (await call('PUT', '/api/admin/content', {}, { cookie, origin: 'https://evil.example' })).status === 403);

  // content
  r = await call('GET', '/api/admin/content', undefined, { cookie });
  const base = r.json;
  ok('admin content loads (defaults on first run)', r.status === 200 && base.services.length === 6 && base.projects.length === 9 && base.testimonials.length === 0 && base.contact.email === '' && base.contact.socials.length === 0);
  ok('public /api/content-hash is null before anything is saved', (await call('GET', '/api/content-hash')).json.hash === null);
  const edit = JSON.parse(JSON.stringify(base));
  edit.home.hero.nameLine1 = 'Saved <b>Name</b>';
  edit.testimonials = [{ name: 'Test Reviewer', role: 'Tester', service: '', text: 'Saved review text.', initials: 'TR', c1: '#8b5cf6', c2: '#22d3ee' }];
  edit.contact.socials = [{ type: 'x', url: 'https://x.com/example' }];
  edit.theme.accent = '#ff0066';
  edit.hack = { x: 1 };
  edit.theme.bg = 'red;}</style><script>alert(1)</script>';
  edit.settings.logoImage = 'javascript:alert(1)';
  r = await call('PUT', '/api/admin/content', edit, { cookie });
  ok('save content -> 200 with hash', r.status === 200 && /^[0-9a-f]{24}$/.test(r.json.hash), r.text.slice(0, 200));
  const pub = (await call('GET', '/api/content')).json;
  ok('saved text is served publicly (survives a "refresh" / other browser)', pub.home.hero.nameLine1 === 'Saved <b>Name</b>' && pub.theme.accent === '#ff0066');
  ok('unknown keys dropped', pub.hack === undefined);
  ok('invalid colour / unsafe URL rejected', pub.theme.bg === '#070812' && pub.settings.logoImage === '');
  ok('public hash matches the save hash', (await call('GET', '/api/content-hash')).json.hash === r.json.hash);
  // deleting the last item stays deleted
  const empty = JSON.parse(JSON.stringify(pub));
  empty.services = []; empty.projects = []; empty.testimonials = []; empty.home.hero.roles = []; empty.contact.socials = [];
  await call('PUT', '/api/admin/content', empty, { cookie });
  const after = (await call('GET', '/api/content')).json;
  ok('emptied lists stay empty (defaults do not refill them)', after.services.length === 0 && after.projects.length === 0 && after.testimonials.length === 0 && after.home.hero.roles.length === 0 && after.contact.socials.length === 0);
  ok('without a session a write is refused and changes nothing', (await call('PUT', '/api/admin/content', base)).status === 401 && (await call('GET', '/api/content')).json.services.length === 0);

  // images
  const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
  const up = (name, buf) => call('POST', '/api/admin/images', { filename: name, data: buf.toString('base64') }, { cookie });
  r = await up('My Photo.png', PNG);
  ok('valid PNG upload accepted', r.status === 200 && /^\/api\/img\/[0-9a-f]{10}-my-photo\.png$/.test(r.json.image.url), r.text);
  const imgUrl = r.json.image.url;
  const got = await fetch(BASE + imgUrl);
  ok('uploaded image is served with the right type and nosniff', got.status === 200 && got.headers.get('content-type') === 'image/png' && got.headers.get('x-content-type-options') === 'nosniff' && Buffer.from(await got.arrayBuffer()).equals(PNG));
  ok('png renamed to .jpg rejected (signature mismatch)', (await up('x.jpg', PNG)).status === 400);
  ok('text file renamed to .png rejected', (await up('x.png', Buffer.from('hello world'))).status === 400);
  ok('.exe rejected by extension', (await up('x.exe', PNG)).status === 400);
  ok('SVG with <script> rejected', (await up('a.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'))).status === 400);
  ok('SVG with onload handler rejected', (await up('a.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"></svg>'))).status === 400);
  ok('SVG with javascript: link rejected', (await up('a.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><a href="javascript:alert(1)"><rect/></a></svg>'))).status === 400);
  ok('SVG with foreignObject rejected', (await up('a.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><foreignObject><div/></foreignObject></svg>'))).status === 400);
  r = await up('shape.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><defs><linearGradient id="g"><stop offset="0" stop-color="#f00"/></linearGradient></defs><rect width="10" height="10" fill="url(#g)"/></svg>'));
  ok('clean SVG accepted', r.status === 200, r.text);
  const svgRes = await fetch(BASE + r.json.image.url);
  ok('SVG is served with a sandbox CSP', /sandbox/.test(svgRes.headers.get('content-security-policy') || ''));
  ok('oversized file rejected', (await up('big.png', Buffer.concat([PNG, Buffer.alloc(3600000)]))).status === 400);
  r = await call('GET', '/api/admin/images', undefined, { cookie });
  ok('image list shows uploads', r.json.images.length === 2 && r.json.images[0].name);
  ok('delete image -> gone', (await call('DELETE', '/api' + '/admin/images/' + imgUrl.split('/').pop(), undefined, { cookie })).status === 200 && (await fetch(BASE + imgUrl)).status === 404);

  // contact form
  const good2 = { name: 'Alex Reader', email: 'alex@example.com', phone: '+1 555 0100', service: 'Meta Ads', message: 'Hello, I would like to talk about a project.' };
  await call('PUT', '/api/admin/content', base, { cookie });   // restore services for the dropdown check
  r = await call('POST', '/api/contact', { name: '', email: 'nope', service: '', message: 'short' });
  ok('invalid message -> 400 with per-field errors', r.status === 400 && r.json.errors.name && r.json.errors.email && r.json.errors.service && r.json.errors.message, r.text);
  ok('service not in the list rejected', (await call('POST', '/api/contact', Object.assign({}, good2, { service: 'Hacking' }))).status === 400);
  const ipA = newIp();
  r = await call('POST', '/api/contact', good2, { ip: ipA });
  ok('valid message -> 200 only after it is stored', r.status === 200 && r.json.ok === true);
  r = await call('POST', '/api/contact', Object.assign({}, good2, { website: 'http://spam.example' }), { ip: newIp() });
  ok('honeypot hit is not stored', r.status === 200);
  r = await call('GET', '/api/admin/messages', undefined, { cookie });
  ok('inbox holds exactly the one real message', r.json.messages.length === 1 && r.json.messages[0].name === 'Alex Reader' && r.json.messages[0].read === false, r.text.slice(0, 300));
  const mid = r.json.messages[0].id;
  ok('stats count unread', (await call('GET', '/api/admin/stats', undefined, { cookie })).json.unread === 1);
  await call('POST', '/api/admin/messages/' + mid + '/read', {}, { cookie });
  ok('mark read', (await call('GET', '/api/admin/stats', undefined, { cookie })).json.unread === 0);
  let last;
  for (let i = 0; i < 6; i++) last = await call('POST', '/api/contact', good2, { ip: ipA });
  ok('message flood from one connection gets 429', last.status === 429);
  ok('delete message', (await call('DELETE', '/api/admin/messages/' + mid, undefined, { cookie })).status === 200 && (await call('GET', '/api/admin/messages', undefined, { cookie })).json.messages.every((m) => m.id !== mid));

  // reset keeps theme + images
  const keepImg = await up('keep.png', PNG);
  const t = JSON.parse(JSON.stringify(base)); t.theme.accent = '#00ff88'; t.home.hero.nameLine1 = 'Changed'; t.services = [];
  await call('PUT', '/api/admin/content', t, { cookie });
  r = await call('POST', '/api/admin/reset', {}, { cookie });
  ok('reset restores original text and lists', r.json.content.home.hero.nameLine1 === 'MH Mahdi' && r.json.content.services.length === 6);
  ok('reset keeps the theme', r.json.content.theme.accent === '#00ff88');
  ok('reset keeps uploaded images', (await fetch(BASE + keepImg.json.image.url)).status === 200);

  // account changes
  r = await call('POST', '/api/admin/account', { currentPassword: 'wrong', newPassword: 'another-long-password' }, { cookie, ip: newIp() });
  ok('password change needs the current password (403, the session stays valid)', r.status === 403 && (await call('GET', '/api/admin/stats', undefined, { cookie })).status === 200);
  r = await call('POST', '/api/admin/account', { currentPassword: PASS, newPassword: 'short' }, { cookie });
  ok('weak new password rejected', r.status === 400);
  const oldCookie = cookie;
  const NEWPASS = 'a-brand-new-passphrase', NEWUSER = 'new.owner';
  r = await call('POST', '/api/admin/account', { currentPassword: PASS, newUsername: NEWUSER, newPassword: NEWPASS }, { cookie });
  ok('change username + password -> 200', r.status === 200 && r.json.username === NEWUSER, r.text);
  const newCookie = cookieOf(r.setCookie);
  ok('old session is invalidated', (await call('GET', '/api/admin/stats', undefined, { cookie: oldCookie })).status === 401);
  ok('the browser that changed it stays signed in', (await call('GET', '/api/admin/stats', undefined, { cookie: newCookie })).status === 200);
  ok('old password no longer works', (await call('POST', '/api/login', { username: NEWUSER, password: PASS }, { ip: newIp() })).status === 401);
  ok('old username no longer works', (await call('POST', '/api/login', { username: USER, password: NEWPASS }, { ip: newIp() })).status === 401);
  r = await call('POST', '/api/login', { username: NEWUSER, password: NEWPASS }, { ip: newIp() });
  ok('new credentials work', r.status === 200);
  const c2 = cookieOf(r.setCookie);
  // password-only change also rotates sessions
  r = await call('POST', '/api/admin/account', { currentPassword: NEWPASS, newPassword: 'yet-another-passphrase' }, { cookie: c2 });
  ok('password-only change invalidates the other session', r.status === 200 && (await call('GET', '/api/admin/stats', undefined, { cookie: newCookie })).status === 401);

  // logout
  const c3 = cookieOf(r.setCookie);
  r = await call('POST', '/api/logout', {}, { cookie: c3 });
  ok('logout clears the cookie (Max-Age=0)', /Max-Age=0/.test(r.setCookie));
  ok('after sign-out nothing can be saved without a session', (await call('PUT', '/api/admin/content', base)).status === 401);

  await stop(srv);
  fs.rmSync(dataDir, { recursive: true, force: true });
  console.log(results.join('\n'));
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
