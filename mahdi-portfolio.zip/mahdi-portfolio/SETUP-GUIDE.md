# Putting your website online (no experience needed)

You will do two things: put the files on **GitHub** (a free online folder), then connect that folder to **Netlify** (the free service that shows it as a website). It takes about 15 minutes and costs nothing.

> **Important — read this first.**
> Do **not** drag this folder onto Netlify's "Deploy manually / drag and drop" box. That method publishes the pages but **switches off the part that saves your Admin Panel changes, stores messages and uploads images**. The site must be **imported from GitHub**, as described below. If you already did the drag-and-drop, just follow this guide and create a new Netlify site from GitHub.

---

## Before you start: choose your admin login

Pick the username and password you want to use for the Admin Panel. Write them down somewhere safe.

- Username: 3–40 characters, letters, numbers and `. _ @ -`
- Password: at least **10 characters**. A few words joined together is a good password.

You can change both later inside the Admin Panel.

---

## Part 1 — Put the files on GitHub

1. Go to **github.com** and click **Sign up**. Create a free account and confirm your email.
2. Once signed in, click the **+** at the top right, then **New repository**.
3. In **Repository name** type `my-website`. Leave it on **Public** or choose **Private** (both work). Do **not** tick any of the "Add a README / .gitignore / license" boxes.
4. Click **Create repository**.
5. On the next page, click the link **uploading an existing file** (in the sentence "Get started by creating a new file or uploading an existing file").
6. On your computer, open the folder you unzipped (`mahdi-portfolio`). Open it so you can see the files **inside** it (`index.html`, `admin`, `assets`, `netlify`, `netlify.toml` and so on).
7. Select **everything inside the folder** (press Ctrl+A, or Cmd+A on a Mac) and **drag it into the GitHub page**. Use a desktop browser (Chrome, Edge or Firefox) so folders upload too.
8. Wait until every file has finished uploading. You should see about 41 files, including the folders `admin`, `assets`, `content`, `netlify`, `src`, `tests` and `tools`.
9. Scroll down and click the green **Commit changes** button.

Check: on your repository page you should see `index.html`, `netlify.toml` and a `netlify` folder directly in the list (not inside another folder). If everything is inside a single `mahdi-portfolio` folder, delete the repository (Settings, scroll to the bottom, Delete) and upload again, this time dragging the **contents** of the folder.

---

## Part 2 — Connect it to Netlify

1. Go to **netlify.com** and click **Sign up**. Choose **Sign up with GitHub** and allow it.
2. On your Netlify dashboard click **Add new project**, then **Import an existing project**.
3. Click **Deploy with GitHub**. If asked, allow Netlify to see your repositories.
4. Click your repository, `my-website`.
5. On the settings screen leave everything as it is. **Build command** stays empty and **Publish directory** stays as `.` (a single dot). The file `netlify.toml` already sets what is needed.
6. **Before** you click Deploy, open **Add environment variables** (or "Environment variables") and add two:

   | Key | Value |
   |---|---|
   | `ADMIN_USERNAME` | the username you chose |
   | `ADMIN_PASSWORD` | the password you chose |

7. Click **Deploy**. Wait a minute or two until the status says **Published**.

If you forgot step 6: open your site in Netlify, go to **Site configuration, Environment variables, Add a variable**, add both, then go to **Deploys, Trigger deploy, Deploy site**.

---

## Part 3 — Open your website and Admin Panel

- Your website address is shown at the top of the Netlify project page (it ends in `.netlify.app`). Click it.
- To sign in, add `/admin` to the end of the address, for example `https://your-site.netlify.app/admin`. You can also use the **Admin Panel** button in the website footer.
- Sign in with the username and password from step 6.

The first sign-in stores your login on the server (the password is kept only as a scrambled, salted hash). After that the two environment variables are no longer used, so changing them later does nothing. Change your login from **Admin Account** inside the panel.

---

## First things to do in the Admin Panel

1. **Contact Information**: add your email, phone, WhatsApp and social links. Anything left empty simply does not appear on the website.
2. **Home Page** and **About Me**: choose your own photos with the **Choose** button, and write your own text.
3. **My Work**: replace the sample screenshots with your real ones (or delete them).
4. **Testimonials**: add reviews only from real clients. The page shows a neutral message while the list is empty.
5. **Theme / Colors**: pick a preset or four colours of your own.
6. **Website Settings**: add your logo and browser tab icon.
7. Press **Save changes** at the top of each section. You will see "Saved. Your website now shows these changes."

Changes are stored on the server, so they show on every device and every browser straight away.

---

## Using your own domain name (optional)

In Netlify: **Domain management, Add a domain**, then follow the steps. Your admin address becomes `yourdomain.com/admin`.

---

## If something does not work

| What you see | What to do |
|---|---|
| "The admin account has not been set up yet" | Add `ADMIN_USERNAME` and `ADMIN_PASSWORD` (Part 2, step 6), then **Deploy site** again. |
| "Storage is not available" | The site was dragged onto Netlify instead of imported from GitHub. Follow Part 2 to import it from GitHub. |
| "Too many wrong attempts" | Sign-in locks for 5 minutes after 5 wrong passwords. Wait, then try again. |
| You forgot your password | Your login is stored in Netlify Blobs. In Netlify open your site, find **Blobs** (under Site configuration or the Storage section), open the store named `auth` and delete the entry called `creds`. The next sign-in then uses `ADMIN_USERNAME` and `ADMIN_PASSWORD` from Environment variables again (change them there first if needed). Your content, images and messages are not affected. |
| A saved change does not show | Refresh the page once. Saved content is checked every time a page loads. |

---

## What is inside the folder (for the curious)

- `index.html`, `services.html`, `my-work.html`, `about.html`, `testimonials.html`, `contact.html`: the six pages, already built.
- `admin/`: the Admin Panel.
- `assets/`: styles, scripts and the sample artwork. `assets/js/render.js` builds every page, both in the build step and in the browser.
- `netlify/functions/api.js`: the single server file that saves content, images and messages. It needs nothing installed.
- `content/site.json`: the starting content. Once you save in the Admin Panel, your saved version is used instead.
- `src/`, `tools/`, `tests/`: developer files. You never need to touch them.
