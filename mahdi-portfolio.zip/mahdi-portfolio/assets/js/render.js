/*
 * Shared renderer.
 * Runs in Node (tools/build.js pre-builds the static .html files) and in the
 * browser (re-renders after the Admin Panel saves). One renderer, so the built
 * pages and the live pages can never drift apart.
 *
 * Everything that comes from content is escaped on output.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Render = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- helpers ---------- */
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ESC[c]; });
  }
  // Only http(s), mailto, tel and relative URLs are ever emitted.
  function url(u) {
    u = String(u == null ? '' : u).trim();
    if (!u) return '';
    var m = /^([a-z][a-z0-9+.-]*):/i.exec(u);
    if (m && !/^(https?|mailto|tel)$/i.test(m[1])) return '';
    if (/^\/\//.test(u)) return '';
    return u;
  }
  function img(u) {
    u = url(u);
    if (!u) return '';
    if (/^(https?:|\/)/i.test(u)) return u;
    return '/' + u;
  }
  function color(v, fallback) {
    v = String(v == null ? '' : v).trim();
    return /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(v) ? v : fallback;
  }
  function list(v) { return Array.isArray(v) ? v : []; }
  function digits(v) { return String(v == null ? '' : v).replace(/[^0-9+]/g, ''); }

  function stable(v) {
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    if (v && typeof v === 'object') {
      return '{' + Object.keys(v).sort().map(function (k) { return JSON.stringify(k) + ':' + stable(v[k]); }).join(',') + '}';
    }
    return JSON.stringify(v === undefined ? null : v);
  }

  /* ---------- icons ---------- */
  var P = {
    megaphone: '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.2-4.2"/>',
    tag: '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><path d="M7 7h.01"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    pixel: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    api: '<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14a6.5 6.5 0 0 1 3.5 6"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    bigcheck: '<circle cx="12" cy="12" r="10"/><path d="M7.5 12.5l3 3 6-6.5"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    arrowUR: '<path d="M7 17L17 7M8 7h9v9"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    left: '<path d="M15 5l-7 7 7 7"/>',
    right: '<path d="M9 5l7 7-7 7"/>',
    quote: '<path d="M9 7H5.5A1.5 1.5 0 0 0 4 8.5V13a1.5 1.5 0 0 0 1.5 1.5H8V16a3 3 0 0 1-3 3M20 7h-3.5A1.5 1.5 0 0 0 15 8.5V13a1.5 1.5 0 0 0 1.5 1.5H19V16a3 3 0 0 1-3 3"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 6L2 7"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
    linkedin: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
    instagram: '<rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.4A4 4 0 1 1 12.6 8 4 4 0 0 1 16 11.4z"/><path d="M17.5 6.5h.01"/>',
    x: '<path d="M4 4l16 16M20 4L4 20"/>',
    whatsapp: '<path d="M3 21l1.65-4.8A8.5 8.5 0 1 1 8 19.4z"/><path d="M9 10c.5 2 2 3.5 4 4"/>',
    youtube: '<rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/>',
    github: '<path d="M9 19c-4 1.2-4-2-6-2.5M15 21v-3.4a3 3 0 0 0-.8-2.3c2.7-.3 5.5-1.3 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.3 4.3 0 0 0-.1-3.2s-1-.3-3.4 1.3a11.7 11.7 0 0 0-6 0C6.5 2.8 5.5 3.1 5.5 3.1a4.3 4.3 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 9.5c0 4.6 2.8 5.7 5.5 6a3 3 0 0 0-.8 2.3V21"/>'
  };
  var ICON_CHOICES = ['megaphone', 'target', 'search', 'tag', 'chart', 'pixel', 'api', 'mail', 'phone', 'bolt', 'users', 'globe', 'layers', 'code'];
  var SOCIAL_TYPES = ['facebook', 'linkedin', 'instagram', 'x', 'whatsapp', 'youtube', 'github'];
  var LABELS = { facebook: 'Facebook', linkedin: 'LinkedIn', instagram: 'Instagram', x: 'X', whatsapp: 'WhatsApp', youtube: 'YouTube', github: 'GitHub' };

  function icon(name, cls) {
    var p = P[name] || P.arrow;
    return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + p + '</svg>';
  }

  /* ---------- pages & links ---------- */
  var PAGES = {
    home: { file: 'index.html', label: 'Home' },
    services: { file: 'services.html', label: 'Services', anchor: '#services' },
    work: { file: 'my-work.html', label: 'My Work', anchor: '#work' },
    about: { file: 'about.html', label: 'About Me', anchor: '#about' },
    testimonials: { file: 'testimonials.html', label: 'Testimonials', anchor: '#testimonials' },
    contact: { file: 'contact.html', label: 'Contact' }
  };
  var NAV = ['home', 'services', 'work', 'about', 'testimonials', 'contact'];

  // A page that has not been built yet falls back to its section on the home page
  // (or, for Contact, to the email link), so every link always works.
  function href(c, ctx, key) {
    var p = PAGES[key];
    if (ctx.built && ctx.built[key]) return p.file;
    if (key === 'home') return ctx.page === 'home' ? '#top' : 'index.html';
    if (key === 'contact') {
      var em = c.contact && c.contact.email ? 'mailto:' + c.contact.email : '';
      return em || (ctx.page === 'home' ? '#contact' : 'index.html#contact');
    }
    return (ctx.page === 'home' ? '' : 'index.html') + p.anchor;
  }

  /* ---------- small builders ---------- */
  function grad(text) { return text ? ' <span class="grad-text">' + esc(text) + '</span>' : ''; }

  function head(o, center) {
    o = o || {};
    return '<div class="sec-head' + (center ? ' center' : '') + ' reveal">' +
      (o.eyebrow ? '<span class="eyebrow">' + esc(o.eyebrow) + '</span>' : '') +
      '<h2>' + esc(o.heading) + grad(o.headingAccent) + '</h2>' +
      (o.sub ? '<p class="sec-sub">' + esc(o.sub) + '</p>' : '') +
      '</div>';
  }

  function btn(cls, link, label, ic, extra) {
    return '<a class="btn ' + cls + ' magnetic" href="' + esc(link) + '"' + (extra || '') + '><span>' + esc(label) + '</span>' + (ic ? icon(ic) : '') + '</a>';
  }

  function socials(c, cls) {
    var items = list(c.contact && c.contact.socials).filter(function (s) { return url(s.url); });
    if (!items.length) return '';
    return '<ul class="socials ' + (cls || '') + '">' + items.map(function (s) {
      var label = LABELS[s.type] || 'Profile';
      return '<li><a href="' + esc(url(s.url)) + '" target="_blank" rel="noopener noreferrer" aria-label="' + esc(label) + '" title="' + esc(label) + '">' + icon(s.type) + '</a></li>';
    }).join('') + '</ul>';
  }

  function delay(i, step) { return ' style="--d:' + ((i % 6) * (step || 0.08)).toFixed(2) + 's"'; }

  /* ---------- header / footer ---------- */
  function header(c, ctx) {
    var s = c.settings || {};
    var logo = s.logoImage
      ? '<img class="brand-logo" src="' + esc(img(s.logoImage)) + '" alt="" width="40" height="40">'
      : '<span class="brand-mark">' + esc(s.logoInitials || 'MH') + '</span>';
    var links = NAV.map(function (k) {
      var active = ctx.page === k;
      return '<li><a class="nav-link' + (active ? ' is-active' : '') + '" href="' + esc(href(c, ctx, k)) + '"' + (active ? ' aria-current="page"' : '') + '>' + esc(PAGES[k].label) + '</a></li>';
    }).join('');
    var hire = (c.home && c.home.hero && c.home.hero.btnSecondary) || 'Hire Me';
    return '<a class="skip" href="#main">Skip to content</a>' +
      '<header class="site-header"><div class="wrap nav-inner">' +
      '<a class="brand" href="' + esc(href(c, ctx, 'home')) + '" aria-label="' + esc(s.brand || 'Home') + ' home">' + logo + '<span class="brand-name">' + esc(s.brand) + '</span></a>' +
      '<nav class="nav" aria-label="Main"><ul class="nav-menu" id="nav-menu">' + links +
      '<li class="nav-cta">' + btn('btn-primary btn-sm', href(c, ctx, 'contact'), hire) + '</li></ul></nav>' +
      '<button class="nav-toggle" type="button" aria-label="Toggle menu" aria-expanded="false" aria-controls="nav-menu"><span></span><span></span></button>' +
      '</div></header>';
  }

  function footer(c, ctx) {
    var s = c.settings || {}, ct = c.contact || {};
    var year = ctx.year || new Date().getFullYear();
    var quick = NAV.map(function (k) {
      return '<li><a href="' + esc(href(c, ctx, k)) + '">' + esc(PAGES[k].label) + '</a></li>';
    }).join('');
    var svc = list(c.services).map(function (v) {
      return '<li><a href="' + esc(href(c, ctx, 'services')) + '">' + esc(v.title) + '</a></li>';
    }).join('');
    var contactItems = '';
    if (ct.email) contactItems += '<li><a class="ft-contact" href="mailto:' + esc(ct.email) + '">' + icon('mail') + '<span>' + esc(ct.email) + '</span></a></li>';
    if (ct.phone) contactItems += '<li><a class="ft-contact" href="tel:' + esc(digits(ct.phone)) + '">' + icon('phone') + '<span>' + esc(ct.phone) + '</span></a></li>';
    var logo = s.logoImage
      ? '<img class="brand-logo" src="' + esc(img(s.logoImage)) + '" alt="" width="40" height="40">'
      : '<span class="brand-mark">' + esc(s.logoInitials || 'MH') + '</span>';
    return '<footer class="site-footer"><div class="wrap">' +
      '<div class="ft-grid">' +
      '<div class="ft-brand"><a class="brand" href="' + esc(href(c, ctx, 'home')) + '">' + logo + '<span class="brand-name">' + esc(s.brand) + '</span></a>' +
      (s.footerDescription ? '<p>' + esc(s.footerDescription) + '</p>' : '') + socials(c, 'socials-sm') + '</div>' +
      '<div class="ft-col"><h3>Quick Links</h3><ul>' + quick + '</ul></div>' +
      (svc ? '<div class="ft-col"><h3>Services</h3><ul>' + svc + '</ul></div>' : '') +
      '<div class="ft-col"><h3>Get in Touch</h3><ul>' + contactItems +
      '<li><a class="btn btn-ghost btn-sm magnetic" href="/admin/" rel="nofollow">' + icon('lock') + '<span>Admin Panel</span></a></li></ul></div>' +
      '</div>' +
      '<div class="ft-bottom"><p>&copy; ' + esc(year) + ' ' + esc(s.brand) + '. ' + esc(s.footerText) + '</p></div>' +
      '</div></footer>';
  }

  /* ---------- home sections ---------- */
  function hero(c, ctx) {
    var h = (c.home && c.home.hero) || {};
    var roles = list(h.roles);
    var rotor = roles.length
      ? '<p class="roles"><span class="roles-label">' + esc(h.rolesLabel || '') + '</span><span class="rotor" aria-label="' + esc(roles.join(', ')) + '">' +
        roles.map(function (r, i) {
          return '<span' + (i === 0 ? ' class="is-active"' : ' aria-hidden="true"') + '>' + esc(r) + '</span>';
        }).join('') + '</span></p>'
      : '';
    var cards = list(h.floatCards).slice(0, 2).map(function (f, i) {
      return '<div class="float-card fc-' + (i + 1) + '"><strong>' + esc(f.value) + '</strong><span>' + esc(f.label) + '</span></div>';
    }).join('');
    var portrait = h.portrait
      ? '<div class="hero-visual reveal"><div class="portrait-wrap"><div class="portrait-glow"></div><div class="tilt">' +
        '<div class="portrait-frame"><img src="' + esc(img(h.portrait)) + '" alt="' + esc((h.nameLine1 || '') + ' ' + (h.nameLine2 || '')) + '" width="800" height="1000" fetchpriority="high"></div>' + cards +
        '</div></div></div>'
      : '';
    var name = esc(((h.nameLine1 || '') + ' ' + (h.nameLine2 || '')).trim());
    return '<section class="hero" id="top"><div class="wrap hero-grid">' +
      '<div class="hero-copy">' +
      (h.pill ? '<p class="pill reveal"><span class="pill-dot"></span>' + esc(h.pill) + '</p>' : '') +
      '<h1 class="hero-name" aria-label="' + name + '"><span class="line" style="--i:0"><span>' + esc(h.nameLine1) + '</span></span><span class="line" style="--i:1"><span>' + esc(h.nameLine2) + '</span></span></h1>' +
      (h.profession ? '<p class="profession reveal" style="--d:.15s">' + esc(h.profession) + '</p>' : '') +
      '<div class="reveal" style="--d:.22s">' + rotor + '</div>' +
      (h.taglineA ? '<p class="tagline reveal" style="--d:.3s">&ldquo;' + esc(h.taglineA) + grad(h.taglineB) + '&rdquo;</p>' : '') +
      (h.intro ? '<p class="intro reveal" style="--d:.36s">' + esc(h.intro) + '</p>' : '') +
      '<div class="hero-actions reveal" style="--d:.42s">' +
      (h.btnPrimary ? btn('btn-primary', href(c, ctx, 'work'), h.btnPrimary, 'arrow') : '') +
      (h.btnSecondary ? btn('btn-ghost', href(c, ctx, 'contact'), h.btnSecondary) : '') +
      '</div>' +
      '<div class="reveal" style="--d:.5s">' + socials(c, 'socials-hero') + '</div>' +
      '</div>' + portrait +
      '</div><a class="scroll-hint" href="#stats" aria-label="Scroll down"><span>Scroll</span><i></i></a></section>';
  }

  function stats(c) {
    var st = list(c.home && c.home.stats);
    if (!st.length) return '';
    return '<section class="stats" id="stats"><div class="wrap"><div class="glass stats-panel reveal">' + st.map(function (s) {
      var n = parseFloat(s.value);
      var dec = (String(s.value).split('.')[1] || '').length;
      return '<div class="stat"><div class="stat-num">' +
        (s.prefix ? '<span class="affix">' + esc(s.prefix) + '</span>' : '') +
        '<span class="count" data-to="' + esc(isNaN(n) ? 0 : n) + '" data-dec="' + dec + '">' + esc(s.value) + '</span>' +
        (s.suffix ? '<span class="affix">' + esc(s.suffix) + '</span>' : '') +
        '</div><p>' + esc(s.label) + '</p></div>';
    }).join('') + '</div></div></section>';
  }

  function services(c, ctx) {
    var items = list(c.services);
    if (!items.length) return '';
    var more = href(c, ctx, 'services');
    return '<section class="section" id="services"><div class="wrap">' + head(c.home.services) +
      '<div class="grid-3">' + items.map(function (s, i) {
        return '<div class="reveal"' + delay(i) + '><article class="card service spot">' +
          '<div class="ic-box">' + icon(s.icon) + '</div>' +
          '<h3>' + esc(s.title) + '</h3><p>' + esc(s.description) + '</p>' +
          '<ul class="ticks">' + list(s.included).slice(0, 3).map(function (b) { return '<li>' + icon('check') + '<span>' + esc(b) + '</span></li>'; }).join('') + '</ul>' +
          '<a class="more" href="' + esc(more) + '"><span>Learn more</span>' + icon('arrow') + '</a>' +
          '</article></div>';
      }).join('') + '</div></div></section>';
  }

  function newest(projects, n) {
    return list(projects).map(function (p, i) { return { p: p, i: i }; }).sort(function (a, b) {
      var da = a.p.date || '', db = b.p.date || '';
      if (da === db) return a.i - b.i;
      return da < db ? 1 : -1;
    }).slice(0, n).map(function (x) { return x.p; });
  }

  function work(c, ctx) {
    var items = newest(c.projects, 4);
    if (!items.length) return '';
    var w = c.home.work || {};
    var link = href(c, ctx, 'work');
    return '<section class="section" id="work"><div class="wrap">' + head(w) +
      '<div class="work-grid">' + items.map(function (p, i) {
        return '<div class="reveal"' + delay(i) + '><a class="work-card spot" href="' + esc(link) + '">' +
          '<img src="' + esc(img(p.image)) + '" alt="' + esc(p.title) + '" width="1280" height="800" loading="lazy">' +
          '<div class="work-overlay"><div><h3>' + esc(p.title) + '</h3><p>' + esc(p.description) + '</p></div><span class="work-go">' + icon('arrowUR') + '</span></div>' +
          '</a></div>';
      }).join('') + '</div>' +
      (w.button ? '<div class="center-actions reveal">' + btn('btn-ghost', link, w.button, 'arrow') + '</div>' : '') +
      '</div></section>';
  }

  function about(c, ctx) {
    var a = (c.home && c.home.about) || {};
    return '<section class="section" id="about"><div class="wrap about-grid">' +
      '<div class="about-media reveal"><div class="portrait-frame about-frame"><img src="' + esc(img(a.photo)) + '" alt="' + esc((c.settings || {}).brand) + '" width="800" height="1000" loading="lazy"></div>' +
      (a.badgeNumber ? '<div class="badge glass"><strong>' + esc(a.badgeNumber) + '</strong><span>' + esc(a.badgeLabel) + '</span></div>' : '') + '</div>' +
      '<div class="about-copy">' +
      '<div class="reveal">' + (a.eyebrow ? '<span class="eyebrow">' + esc(a.eyebrow) + '</span>' : '') +
      '<h2>' + esc(a.heading) + grad(a.headingAccent) + '</h2></div>' +
      (a.p1 ? '<p class="reveal" style="--d:.08s">' + esc(a.p1) + '</p>' : '') +
      (a.p2 ? '<p class="reveal" style="--d:.14s">' + esc(a.p2) + '</p>' : '') +
      (list(a.bullets).length ? '<ul class="ticks ticks-2 reveal" style="--d:.2s">' + list(a.bullets).slice(0, 4).map(function (b) { return '<li>' + icon('check') + '<span>' + esc(b) + '</span></li>'; }).join('') + '</ul>' : '') +
      (a.button ? '<div class="reveal" style="--d:.26s">' + btn('btn-primary', href(c, ctx, 'about'), a.button, 'arrow') + '</div>' : '') +
      '</div></div></section>';
  }

  function tools(c) {
    var t = (c.home && c.home.tools) || {};
    var chips = list(t.chips), keys = list(t.marquee);
    if (!chips.length && !keys.length) return '';
    var group = function (hidden) {
      return '<div class="marquee-group"' + (hidden ? ' aria-hidden="true"' : '') + '>' + keys.map(function (k) {
        return '<span class="mq-item">' + esc(k) + '</span><span class="mq-sep" aria-hidden="true"></span>';
      }).join('') + '</div>';
    };
    return '<section class="section" id="tools"><div class="wrap">' + head(t, true) +
      (chips.length ? '<ul class="chips reveal">' + chips.map(function (x) { return '<li class="chip"><i></i>' + esc(x) + '</li>'; }).join('') + '</ul>' : '') +
      '</div>' +
      (keys.length ? '<div class="marquee reveal" aria-label="' + esc(keys.join(', ')) + '"><div class="marquee-track">' + group(false) + group(true) + '</div></div>' : '') +
      '</section>';
  }

  function stars() {
    var s = '';
    for (var i = 0; i < 5; i++) s += '<svg class="ic star" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9z"/></svg>';
    return '<span class="stars" role="img" aria-label="5 out of 5 stars">' + s + '</span>';
  }

  function testimonials(c, ctx) {
    var items = list(c.testimonials);
    if (!items.length) return '';
    var t = (c.home && c.home.testimonials) || {};
    var multi = items.length > 1;
    return '<section class="section" id="testimonials"><div class="wrap">' + head(t, true) +
      '<div class="slider reveal" data-slider role="region" aria-roledescription="carousel" aria-label="Testimonials" tabindex="0">' +
      '<div class="slides">' + items.map(function (r, i) {
        return '<figure class="slide glass' + (i === 0 ? ' is-active' : '') + '"' + (i === 0 ? '' : ' aria-hidden="true"') + '>' +
          '<span class="q-mark">' + icon('quote') + '</span>' +
          (r.service ? '<span class="tag">' + esc(r.service) + '</span>' : '') +
          '<blockquote>' + esc(r.text) + '</blockquote>' +
          '<figcaption><span class="avatar" style="--c1:' + color(r.c1, '#8b5cf6') + ';--c2:' + color(r.c2, '#22d3ee') + '">' + esc(r.initials) + '</span>' +
          '<span class="who"><strong>' + esc(r.name) + '</strong><span>' + esc(r.role) + '</span></span></figcaption></figure>';
      }).join('') + '</div>' +
      (multi ? '<div class="slider-ctl"><button class="arrow-btn" type="button" data-slide-prev aria-label="Previous review">' + icon('left') + '</button>' +
        '<div class="dots">' + items.map(function (r, i) {
          return '<button class="slider-dot' + (i === 0 ? ' is-active' : '') + '" type="button" data-slide-to="' + i + '" aria-label="Show review ' + (i + 1) + '"' + (i === 0 ? ' aria-current="true"' : '') + '></button>';
        }).join('') + '</div>' +
        '<button class="arrow-btn" type="button" data-slide-next aria-label="Next review">' + icon('right') + '</button></div>' : '') +
      '</div>' +
      (t.button ? '<div class="center-actions reveal">' + btn('btn-ghost', href(c, ctx, 'testimonials'), t.button, 'arrow') + '</div>' : '') +
      '</div></section>';
  }

  function cta(c, ctx) {
    var k = (c.home && c.home.cta) || {};
    var email = c.contact && c.contact.email;
    return '<section class="section cta" id="contact"><div class="wrap"><div class="cta-panel reveal"><div class="cta-glow" aria-hidden="true"></div>' +
      '<h2>' + esc(k.heading) + grad(k.headingAccent) + '</h2>' +
      (k.text ? '<p>' + esc(k.text) + '</p>' : '') +
      '<div class="cta-actions">' +
      (k.button ? btn('btn-primary', href(c, ctx, 'contact'), k.button, 'arrow') : '') +
      (email ? '<a class="btn btn-ghost magnetic" href="mailto:' + esc(email) + '">' + icon('mail') + '<span>' + esc(email) + '</span></a>' : '') +
      '</div></div></div></section>';
  }

  /* ---------- inner pages ---------- */
  function pageHeader(c, ctx, key) {
    var p = (c.pages && c.pages[key]) || {};
    return '<section class="page-head"><div class="wrap">' +
      '<nav class="crumbs reveal" aria-label="Breadcrumb"><a href="' + esc(href(c, ctx, 'home')) + '">Home</a><span aria-hidden="true">/</span><span aria-current="page">' + esc(PAGES[key].label) + '</span></nav>' +
      (p.eyebrow ? '<span class="eyebrow reveal" style="--d:.05s">' + esc(p.eyebrow) + '</span>' : '') +
      '<h1 class="page-title"><span class="line" style="--i:0"><span>' + esc(p.heading) + '</span></span>' +
      (p.headingAccent ? '<span class="line" style="--i:1"><span class="grad-text">' + esc(p.headingAccent) + '</span></span>' : '') + '</h1>' +
      (p.intro ? '<p class="page-intro reveal" style="--d:.2s">' + esc(p.intro) + '</p>' : '') +
      '</div></section>';
  }

  function pageCta(c, ctx, key) {
    var k = (c.pages && c.pages[key] && c.pages[key].cta) || {};
    var email = c.contact && c.contact.email;
    var second = '';
    if (k.secondaryLabel && k.secondaryPage && PAGES[k.secondaryPage]) second = btn('btn-ghost', href(c, ctx, k.secondaryPage), k.secondaryLabel);
    else if (email) second = '<a class="btn btn-ghost magnetic" href="mailto:' + esc(email) + '">' + icon('mail') + '<span>' + esc(email) + '</span></a>';
    return '<section class="section cta"><div class="wrap"><div class="cta-panel reveal"><div class="cta-glow" aria-hidden="true"></div>' +
      '<h2>' + esc(k.heading) + grad(k.headingAccent) + '</h2>' +
      (k.text ? '<p>' + esc(k.text) + '</p>' : '') +
      '<div class="cta-actions">' + (k.button ? btn('btn-primary', href(c, ctx, 'contact'), k.button, 'arrow') : '') + second + '</div>' +
      '</div></div></section>';
  }

  function servicesPage(c, ctx) {
    var items = list(c.services), contact = href(c, ctx, 'contact');
    var grid = items.length ? '<div class="grid-3">' + items.map(function (s, i) {
      var inc = list(s.included);
      return '<div class="reveal"' + delay(i) + '><article class="card svc-card spot">' +
        '<div class="svc-top"><div class="ic-box">' + icon(s.icon) + '</div>' + (s.category ? '<span class="tag">' + esc(s.category) + '</span>' : '') + '</div>' +
        '<h3>' + esc(s.title) + '</h3><p>' + esc(s.description) + '</p>' +
        (inc.length ? '<p class="inc-label">What&rsquo;s Included</p><ul class="ticks">' + inc.slice(0, 6).map(function (b) { return '<li>' + icon('check') + '<span>' + esc(b) + '</span></li>'; }).join('') + '</ul>' : '') +
        '<div class="svc-foot">' + (s.note ? '<span class="note">' + esc(s.note) + '</span>' : '<span></span>') + btn('btn-primary btn-sm', contact, 'Get Started', 'arrow') + '</div>' +
        '</article></div>';
    }).join('') + '</div>' : '';
    return pageHeader(c, ctx, 'services') + '<section class="section tight"><div class="wrap">' + grid + '</div></section>' + pageCta(c, ctx, 'services');
  }

  function workPage(c, ctx) {
    var items = newest(c.projects, 100000);
    var grid = items.length ? '<div class="gal-grid">' + items.map(function (p, i) {
      return '<div class="reveal"' + delay(i) + '><article class="gal-card card spot" role="button" tabindex="0" aria-haspopup="dialog" aria-label="View larger: ' + esc(p.title) + '" data-open data-title="' + esc(p.title) + '" data-desc="' + esc(p.description) + '" data-src="' + esc(img(p.image)) + '">' +
        '<div class="gal-shot"><img src="' + esc(img(p.image)) + '" alt="' + esc(p.title) + '" width="1280" height="800" loading="lazy"><span class="gal-zoom">' + icon('search') + '</span></div>' +
        '<div class="gal-body"><h3>' + esc(p.title) + '</h3>' + (p.description ? '<p>' + esc(p.description) + '</p>' : '') + '</div></article></div>';
    }).join('') + '</div>' : '<p class="empty-note">New projects will appear here soon.</p>';
    var viewer = '<div class="viewer" id="viewer" role="dialog" aria-modal="true" aria-labelledby="viewer-title" hidden>' +
      '<div class="viewer-backdrop" data-viewer-close></div>' +
      '<div class="viewer-panel"><button class="viewer-close" type="button" data-viewer-close aria-label="Close">' + icon('close') + '</button>' +
      '<div class="viewer-img"><img id="viewer-img" src="" alt=""></div>' +
      '<div class="viewer-text"><h3 id="viewer-title"></h3><p id="viewer-desc"></p></div></div></div>';
    return pageHeader(c, ctx, 'work') + '<section class="section tight"><div class="wrap">' + grid + '</div></section>' + pageCta(c, ctx, 'work') + viewer;
  }

  function aboutPage(c, ctx) {
    var a = (c.pages && c.pages.about) || {};
    var name = (c.settings || {}).brand;
    var paras = list(a.paragraphs);
    var media = a.photo
      ? '<div class="story-media reveal"><div class="portrait-wrap"><div class="portrait-glow"></div><div class="glow-ring" aria-hidden="true"></div><div class="tilt"><div class="portrait-frame"><img src="' + esc(img(a.photo)) + '" alt="' + esc(a.signatureName || name) + '" width="800" height="1000" loading="lazy"></div></div></div></div>'
      : '';
    return pageHeader(c, ctx, 'about') +
      '<section class="section tight"><div class="wrap story-grid' + (media ? '' : ' no-media') + '">' + media +
      '<div class="story-copy">' +
      (a.storyEyebrow ? '<span class="eyebrow reveal">' + esc(a.storyEyebrow) + '</span>' : '') +
      (a.openingLine ? '<p class="lead reveal" style="--d:.06s">' + esc(a.openingLine) + '</p>' : '') +
      paras.map(function (t, i) { return '<p class="reveal" style="--d:' + (0.1 + i * 0.06).toFixed(2) + 's">' + esc(t) + '</p>'; }).join('') +
      ((a.signatureName || a.signatureTitle) ? '<div class="signature reveal"><span class="sig-name">' + esc(a.signatureName) + '</span><span class="sig-title">' + esc(a.signatureTitle) + '</span></div>' : '') +
      '</div></div></section>' + pageCta(c, ctx, 'about');
  }

  function reviewData(r) {
    return ' data-service="' + esc(r.service) + '" data-text="' + esc(r.text) + '" data-name="' + esc(r.name) + '" data-role="' + esc(r.role) + '" data-initials="' + esc(r.initials) + '" data-c1="' + color(r.c1, '#8b5cf6') + '" data-c2="' + color(r.c2, '#22d3ee') + '"';
  }
  function avatar(r) {
    return '<span class="avatar" style="--c1:' + color(r.c1, '#8b5cf6') + ';--c2:' + color(r.c2, '#22d3ee') + '">' + esc(r.initials) + '</span>';
  }

  function testimonialsPage(c, ctx) {
    var items = list(c.testimonials);
    var feat = items[0], rest = items.slice(1);
    var featured = feat
      ? '<div class="feature glass reveal" data-feature' + reviewData(feat) + '><div class="feature-glow" aria-hidden="true"></div><div class="feature-inner">' +
        '<span class="q-mark">' + icon('quote') + '</span>' +
        '<span class="tag" data-f="service"' + (feat.service ? '' : ' hidden') + '>' + esc(feat.service) + '</span>' +
        '<blockquote data-f="text">' + esc(feat.text) + '</blockquote>' + stars() +
        '<div class="who-row">' + avatar(feat).replace('class="avatar"', 'class="avatar" data-f="avatar"') +
        '<span class="who"><strong data-f="name">' + esc(feat.name) + '</strong><span data-f="role">' + esc(feat.role) + '</span></span></div></div></div>'
      : '';
    var grid = rest.length ? '<div class="review-grid">' + rest.map(function (r, i) {
      return '<div class="reveal"' + delay(i) + '><article class="review card spot" role="button" tabindex="0" aria-label="Show this review from ' + esc(r.name) + ' at the top"' + reviewData(r) + '>' +
        (r.service ? '<span class="tag" data-f="service">' + esc(r.service) + '</span>' : '<span class="tag" data-f="service" hidden></span>') + stars() +
        '<p class="r-text" data-f="text">' + esc(r.text) + '</p>' +
        '<div class="who-row">' + avatar(r).replace('class="avatar"', 'class="avatar" data-f="avatar"') + '<span class="who"><strong data-f="name">' + esc(r.name) + '</strong><span data-f="role">' + esc(r.role) + '</span></span></div></article></div>';
    }).join('') + '</div>' : '';
    var none = !items.length ? '<p class="empty-note">Reviews will appear here soon.</p>' : '';
    return pageHeader(c, ctx, 'testimonials') + '<section class="section tight" id="reviews"><div class="wrap">' + featured + grid + none + '</div></section>' + pageCta(c, ctx, 'testimonials');
  }

  function waDigits(v) { return String(v == null ? '' : v).replace(/\D/g, ''); }

  function contactPage(c, ctx) {
    var p = (c.pages && c.pages.contact) || {}, ct = c.contact || {};
    var opts = list(c.services).map(function (s) { return '<option value="' + esc(s.title) + '">' + esc(s.title) + '</option>'; }).join('') +
      (p.serviceUnsure ? '<option value="' + esc(p.serviceUnsure) + '">' + esc(p.serviceUnsure) + '</option>' : '');
    var field = function (id, label, req, control, hint) {
      return '<div class="field" data-field="' + id + '"><label for="cf-' + id + '">' + esc(label) + (req ? ' <i aria-hidden="true">*</i>' : ' <em>(optional)</em>') + '</label>' + control +
        '<p class="err" id="cf-' + id + '-err" role="alert"></p></div>';
    };
    var form = '<div data-form-view><h2 class="form-title">' + esc(p.formHeading) + '</h2>' + (p.formSub ? '<p class="form-sub">' + esc(p.formSub) + '</p>' : '') +
      '<form class="cform" data-contact-form novalidate>' +
      '<div class="hp" aria-hidden="true"><label>Leave this field empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>' +
      '<div class="two-col">' +
      field('name', 'Your Name', true, '<input id="cf-name" name="name" type="text" autocomplete="name" maxlength="120" required aria-describedby="cf-name-err">') +
      field('email', 'Email Address', true, '<input id="cf-email" name="email" type="email" autocomplete="email" maxlength="200" required aria-describedby="cf-email-err">') +
      '</div><div class="two-col">' +
      field('phone', 'Phone / WhatsApp', false, '<input id="cf-phone" name="phone" type="tel" autocomplete="tel" maxlength="40" aria-describedby="cf-phone-err">') +
      field('service', 'Service Needed', true, '<select id="cf-service" name="service" required aria-describedby="cf-service-err"><option value="">Select a service</option>' + opts + '</select>') +
      '</div>' +
      field('message', 'Your Message', true, '<textarea id="cf-message" name="message" rows="6" maxlength="5000" required aria-describedby="cf-message-err"></textarea>') +
      '<div class="form-foot"><button class="btn btn-primary magnetic" type="submit"><span>' + esc(p.submitLabel || 'Send Message') + '</span>' + icon('send') + '</button>' +
      (p.privacyNote ? '<p class="privacy">' + icon('lock') + '<span>' + esc(p.privacyNote) + '</span></p>' : '') + '</div>' +
      '<p class="form-status" role="status" aria-live="polite" data-form-status></p></form></div>';
    var success = '<div class="form-success" data-form-success hidden tabindex="-1"><span class="ok-ic">' + icon('bigcheck') + '</span><h2>' + esc(p.successHeading) + '</h2>' +
      '<p>' + esc(p.successText) + '</p><button class="btn btn-ghost magnetic" type="button" data-form-reset><span>' + esc(p.successButton) + '</span></button></div>';
    var card = function (ic, label, value, link, hint) {
      return '<a class="ccard glass spot reveal" href="' + esc(link) + '"><span class="ic-box">' + icon(ic) + '</span><span class="ccard-text"><span class="ccard-label">' + esc(label) + '</span><strong>' + esc(value) + '</strong>' + (hint ? '<span class="ccard-hint">' + esc(hint) + '</span>' : '') + '</span></a>';
    };
    var cards = '';
    if (ct.email) cards += card('mail', 'Email', ct.email, 'mailto:' + ct.email, p.emailHint);
    if (ct.phone) cards += card('phone', 'Phone', ct.phone, 'tel:' + digits(ct.phone), p.phoneHint);
    if (ct.whatsapp) cards += card('whatsapp', 'WhatsApp', ct.whatsapp, 'https://wa.me/' + waDigits(ct.whatsapp), p.whatsappHint);
    var soc = socials(c, '');
    var online = soc ? '<div class="online glass reveal"><h3>' + esc(p.findMeTitle || 'Find Me Online') + '</h3>' + soc + '</div>' : '';
    return pageHeader(c, ctx, 'contact') +
      '<section class="section tight"><div class="wrap contact-grid' + ((cards || online) ? '' : ' solo') + '">' +
      '<div class="form-panel glass reveal" data-form-panel><div class="form-glow" aria-hidden="true"></div>' + form + success + '</div>' +
      ((cards || online) ? '<aside class="contact-side">' + cards + online + '</aside>' : '') +
      '</div></section><div class="cta-spacer"></div>';
  }

  function home(c, ctx) {
    return hero(c, ctx) + stats(c) + services(c, ctx) + work(c, ctx) + about(c, ctx) + tools(c) + testimonials(c, ctx) + cta(c, ctx);
  }

  function notFound(c, ctx) {
    return '<section class="hero nf"><div class="wrap"><p class="eyebrow">Error 404</p><h1 class="hero-name"><span class="line" style="--i:0"><span>Page not</span></span><span class="line" style="--i:1"><span class="grad-text">found</span></span></h1>' +
      '<p class="intro">The page you are looking for does not exist or has moved.</p>' +
      '<div class="hero-actions">' + btn('btn-primary', href(c, { page: 'x', built: ctx.built }, 'home'), 'Back to Home', 'arrow') + '</div></div></section>';
  }

  /* ---------- public API ---------- */
  function renderApp(c, ctx) {
    ctx = ctx || {};
    ctx.page = ctx.page || 'home';
    ctx.built = ctx.built || { home: true, services: true, work: true, about: true, testimonials: true, contact: true };
    var views = { home: home, services: servicesPage, work: workPage, about: aboutPage, testimonials: testimonialsPage, contact: contactPage };
    var body = (views[ctx.page] || notFound)(c, ctx);
    return header(c, ctx) + '<main id="main">' + body + '</main>' + footer(c, ctx);
  }

  function themeCss(c) {
    var t = (c && c.theme) || {};
    return ':root{--bg:' + color(t.bg, '#070812') + ';--accent:' + color(t.accent, '#8b5cf6') + ';--accent-2:' + color(t.accent2, '#22d3ee') + ';--text:' + color(t.text, '#eef0ff') + '}';
  }

  function pageMeta(c, page) {
    var s = (c && c.settings) || {};
    var p = (c && c.pages && c.pages[page]) || {};
    var title = page === 'home' ? (s.siteTitle || s.brand || '')
      : PAGES[page] ? PAGES[page].label + ' | ' + (s.brand || '')
      : 'Page not found | ' + (s.brand || '');
    return { title: title, description: (page !== 'home' && p.intro) ? p.intro : (s.metaDescription || '') };
  }

  return { esc: esc, stable: stable, renderApp: renderApp, themeCss: themeCss, pageMeta: pageMeta, PAGES: PAGES, newest: newest, icon: icon, ICON_CHOICES: ICON_CHOICES, SOCIAL_TYPES: SOCIAL_TYPES, LABELS: LABELS };
});
