/*
 * Site behaviour: preloader, cursor, magnetic buttons, spotlight cards, 3D tilt,
 * rotating specialities, scroll reveals, count-up numbers, testimonial slider,
 * and the boot check that re-renders when newer content has been saved.
 *
 * The header and footer live inside the re-rendered area, so anything that touches
 * them looks the elements up again each time. Document-level listeners are
 * registered once and use delegation, so they keep working after a re-render.
 */
(function () {
  'use strict';

  var doc = document, root = doc.documentElement;
  var mm = window.matchMedia ? function (q) { return window.matchMedia(q).matches; } : function () { return false; };
  var reduce = mm('(prefers-reduced-motion: reduce)');
  var fine = mm('(hover: hover) and (pointer: fine)');
  var S = { timers: {}, mag: null, tilt: null, slider: null };

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function hasGSAP() { return !!(window.gsap && window.ScrollTrigger); }
  function closest(el, sel) { return el && el.closest ? el.closest(sel) : null; }

  try { if (hasGSAP()) window.gsap.registerPlugin(window.ScrollTrigger); } catch (e) { /* fallback paths below */ }

  /* ---------- preloader ---------- */
  var t0 = Date.now();
  function hidePreloader() {
    doc.body.classList.add('ready');
    var p = $('#preloader');
    if (p) { p.classList.add('done'); setTimeout(function () { if (p.parentNode) p.parentNode.removeChild(p); }, 900); }
  }
  function afterLoad() { setTimeout(hidePreloader, Math.max(0, (reduce ? 200 : 1100) - (Date.now() - t0))); }
  if (doc.readyState === 'complete') afterLoad(); else window.addEventListener('load', afterLoad);
  setTimeout(hidePreloader, 3200);

  /* ---------- header, menu, scroll hint (looked up fresh every time) ---------- */
  function onScroll() {
    var h = $('.site-header');
    if (h) h.classList.toggle('scrolled', window.scrollY > 24);
    var sh = $('.scroll-hint');
    if (sh) sh.classList.toggle('hide', window.scrollY > 120);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', function () {
    onScroll();
    if (window.innerWidth > 920) closeMenu();
    if (hasGSAP()) { try { window.ScrollTrigger.refresh(); } catch (e) {} }
  });

  function closeMenu() {
    root.classList.remove('nav-open');
    var t = $('.nav-toggle');
    if (t) t.setAttribute('aria-expanded', 'false');
  }
  doc.addEventListener('click', function (e) {
    var tog = closest(e.target, '.nav-toggle');
    if (tog) {
      var open = root.classList.toggle('nav-open');
      tog.setAttribute('aria-expanded', open ? 'true' : 'false');
      return;
    }
    if (closest(e.target, '.nav-menu a')) closeMenu();

    if (closest(e.target, '[data-viewer-close]')) { closeViewer(); return; }
    var card = closest(e.target, '[data-open],.review[data-text]');
    if (card) { activateCard(card); return; }
    if (closest(e.target, '[data-form-reset]')) { resetForm(); return; }

    // slider controls
    var ctl = closest(e.target, '[data-slide-prev],[data-slide-next],[data-slide-to]');
    if (ctl && S.slider) {
      if (ctl.hasAttribute('data-slide-prev')) S.slider.go(S.slider.i - 1);
      else if (ctl.hasAttribute('data-slide-next')) S.slider.go(S.slider.i + 1);
      else S.slider.go(parseInt(ctl.getAttribute('data-slide-to'), 10) || 0);
      S.slider.restart();
    }
  });
  doc.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (viewerOpen()) closeViewer(); closeMenu(); return; }
    if (e.key === 'Tab' && viewerOpen()) { trapTab(e); return; }
    if ((e.key === 'Enter' || e.key === ' ') && !e.target.matches('input,textarea,select,button')) {
      var card = closest(e.target, '[data-open],.review[data-text]');
      if (card && card === e.target) { e.preventDefault(); activateCard(card); }
    }
  });

  /* ---------- custom cursor ---------- */
  function setupCursor() {
    if (!fine || reduce) return;
    var dot = $('#cursor-dot'), ring = $('#cursor-ring');
    if (!dot || !ring) return;
    root.classList.add('has-cursor');
    var x = -100, y = -100, rx = -100, ry = -100, shown = false;
    doc.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') return;
      x = e.clientX; y = e.clientY;
      if (!shown) { shown = true; rx = x; ry = y; root.classList.add('cursor-on'); }
      dot.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)';
      var h = !!closest(e.target, 'a,button,[role="button"],[data-cursor]');
      ring.classList.toggle('is-hover', h);
      dot.classList.toggle('is-hover', h);
    }, { passive: true });
    root.addEventListener('mouseleave', function () { root.classList.remove('cursor-on'); shown = false; });
    (function loop() {
      rx += (x - rx) * 0.16; ry += (y - ry) * 0.16;
      ring.style.transform = 'translate3d(' + rx.toFixed(1) + 'px,' + ry.toFixed(1) + 'px,0)';
      window.requestAnimationFrame(loop);
    })();
  }

  /* ---------- magnetic buttons, spotlight cards, 3D tilt (delegated) ---------- */
  function resetMag(el) { if (el) el.style.transform = ''; }
  function resetTilt(el) { if (el) { el.style.removeProperty('--rx'); el.style.removeProperty('--ry'); } }
  doc.addEventListener('pointermove', function (e) {
    if (e.pointerType === 'touch') return;

    var m = fine && !reduce ? closest(e.target, '.magnetic') : null;
    if (S.mag && S.mag !== m) resetMag(S.mag);
    if (m) {
      var r = m.getBoundingClientRect();
      var dx = (e.clientX - (r.left + r.width / 2)) / r.width;
      var dy = (e.clientY - (r.top + r.height / 2)) / r.height;
      m.style.transform = 'translate(' + (dx * 14).toFixed(1) + 'px,' + (dy * 10).toFixed(1) + 'px)';
    }
    S.mag = m;

    var c = closest(e.target, '.spot');
    if (c) {
      var cr = c.getBoundingClientRect();
      c.style.setProperty('--mx', (e.clientX - cr.left) + 'px');
      c.style.setProperty('--my', (e.clientY - cr.top) + 'px');
    }

    var w = fine && !reduce ? closest(e.target, '.portrait-wrap') : null;
    if (S.tilt && S.tilt !== w) resetTilt(S.tilt);
    if (w) {
      var wr = w.getBoundingClientRect();
      var px = (e.clientX - wr.left) / wr.width - 0.5;
      var py = (e.clientY - wr.top) / wr.height - 0.5;
      w.style.setProperty('--ry', (px * 14).toFixed(2) + 'deg');
      w.style.setProperty('--rx', (-py * 12).toFixed(2) + 'deg');
    }
    S.tilt = w;
  }, { passive: true });
  doc.addEventListener('mouseleave', function () { resetMag(S.mag); resetTilt(S.tilt); S.mag = S.tilt = null; });

  /* ---------- rotating specialities ---------- */
  function setupRotor() {
    clearInterval(S.timers.rotor);
    var r = $('.rotor');
    if (!r || reduce) return;
    var n = $$('span', r).length;
    if (n < 2) return;
    var i = 0;
    S.timers.rotor = setInterval(function () {
      var rr = $('.rotor');
      if (!rr) return;
      var items = $$('span', rr);
      var cur = items[i], nx = (i + 1) % items.length, next = items[nx];
      cur.classList.remove('is-active'); cur.classList.add('is-out'); cur.setAttribute('aria-hidden', 'true');
      next.classList.remove('is-out'); next.classList.add('is-active'); next.removeAttribute('aria-hidden');
      setTimeout(function () { cur.classList.remove('is-out'); }, 800);
      i = nx;
    }, 2600);
  }

  /* ---------- scroll reveals (GSAP ScrollTrigger, IntersectionObserver fallback) ---------- */
  function observe(els, cb, margin) {
    if (!('IntersectionObserver' in window)) { els.forEach(cb); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { io.unobserve(en.target); cb(en.target); } });
    }, { rootMargin: margin || '0px 0px -8% 0px', threshold: 0.01 });
    els.forEach(function (el) { io.observe(el); });
  }
  function setupReveals() {
    var els = $$('.reveal:not(.in)');
    if (!els.length) return;
    var add = function (el) { el.classList.add('in'); };
    if (hasGSAP()) {
      try {
        window.ScrollTrigger.batch(els, { start: 'top 92%', once: true, onEnter: function (b) { b.forEach(add); } });
        return;
      } catch (e) { /* fall through */ }
    }
    observe(els, add);
  }

  /* ---------- count-up numbers ---------- */
  function fmt(v, dec) { return dec ? v.toFixed(dec) : String(Math.round(v)); }
  function setupCounters() {
    $$('.count').forEach(function (el) {
      var to = parseFloat(el.getAttribute('data-to'));
      if (isNaN(to)) return;
      var dec = parseInt(el.getAttribute('data-dec'), 10) || 0;
      var started = false;
      if (!reduce) el.textContent = fmt(0, dec);
      function run() {
        if (started) return;
        started = true;
        if (reduce) { el.textContent = fmt(to, dec); return; }
        if (window.gsap) {
          var o = { v: 0 };
          window.gsap.to(o, { v: to, duration: 1.8, ease: 'power2.out', onUpdate: function () { el.textContent = fmt(o.v, dec); }, onComplete: function () { el.textContent = fmt(to, dec); } });
        } else {
          var t = Date.now();
          (function tick() {
            var p = Math.min(1, (Date.now() - t) / 1800), e = 1 - Math.pow(1 - p, 3);
            el.textContent = fmt(to * e, dec);
            if (p < 1) window.requestAnimationFrame(tick); else el.textContent = fmt(to, dec);
          })();
        }
      }
      if (hasGSAP()) {
        try { window.ScrollTrigger.create({ trigger: el, start: 'top 90%', once: true, onEnter: run }); return; } catch (e) { /* fall through */ }
      }
      observe([el], run, '0px 0px -5% 0px');
    });
  }

  /* ---------- testimonial slider ---------- */
  function setupSlider() {
    if (S.slider) S.slider.stop();
    S.slider = null;
    var el = $('[data-slider]');
    if (!el) return;
    var slides = $$('.slide', el), dots = $$('.slider-dot', el), n = slides.length;
    if (!n) return;
    var paused = false, timer = null;
    var api = {
      i: 0,
      go: function (k) {
        api.i = ((k % n) + n) % n;
        slides.forEach(function (s, j) {
          var on = j === api.i;
          s.classList.toggle('is-active', on);
          if (on) s.removeAttribute('aria-hidden'); else s.setAttribute('aria-hidden', 'true');
        });
        dots.forEach(function (d, j) {
          d.classList.toggle('is-active', j === api.i);
          if (j === api.i) d.setAttribute('aria-current', 'true'); else d.removeAttribute('aria-current');
        });
      },
      stop: function () { clearInterval(timer); timer = null; },
      restart: function () {
        api.stop();
        if (n > 1 && !reduce) timer = setInterval(function () { if (!paused && !doc.hidden) api.go(api.i + 1); }, 6500);
      }
    };
    S.slider = api;
    el.addEventListener('mouseenter', function () { paused = true; });
    el.addEventListener('mouseleave', function () { paused = false; });
    el.addEventListener('focusin', function () { paused = true; });
    el.addEventListener('focusout', function () { paused = false; });
    el.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { api.go(api.i - 1); api.restart(); }
      if (e.key === 'ArrowRight') { api.go(api.i + 1); api.restart(); }
    });
    // swipe on touch
    var sx = null, sy = null;
    el.addEventListener('pointerdown', function (e) { if (e.pointerType === 'mouse') return; sx = e.clientX; sy = e.clientY; });
    el.addEventListener('pointerup', function (e) {
      if (sx === null) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      sx = sy = null;
      if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) { api.go(api.i + (dx < 0 ? 1 : -1)); api.restart(); }
    });
    el.addEventListener('pointercancel', function () { sx = sy = null; });
    api.restart();
  }

  /* ---------- My Work viewer ---------- */
  var viewerOpener = null;
  function viewerEl() { return $('#viewer'); }
  function viewerOpen() { var v = viewerEl(); return !!(v && !v.hidden); }
  function openViewer(card) {
    var v = viewerEl();
    if (!v) return;
    viewerOpener = card;
    var im = $('#viewer-img', v);
    im.src = card.getAttribute('data-src') || '';
    im.alt = card.getAttribute('data-title') || '';
    $('#viewer-title', v).textContent = card.getAttribute('data-title') || '';
    $('#viewer-desc', v).textContent = card.getAttribute('data-desc') || '';
    v.hidden = false;
    root.classList.add('no-scroll');
    window.requestAnimationFrame(function () { v.classList.add('is-open'); });
    var cb = $('.viewer-close', v);
    if (cb) cb.focus();
  }
  function closeViewer() {
    var v = viewerEl();
    root.classList.remove('no-scroll');
    if (!v || v.hidden) return;
    v.classList.remove('is-open');
    v.hidden = true;
    if (viewerOpener && doc.body.contains(viewerOpener)) viewerOpener.focus();
    viewerOpener = null;
  }
  function trapTab(e) {
    var v = viewerEl();
    var f = $$('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])', v).filter(function (x) { return !x.disabled && x.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (!v.contains(doc.activeElement)) { e.preventDefault(); first.focus(); }
    else if (e.shiftKey && doc.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && doc.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ---------- Testimonials: swap a review into the featured panel ---------- */
  var FIELDS = ['service', 'text', 'name', 'role', 'initials', 'c1', 'c2'];
  function readReview(el) { var o = {}; FIELDS.forEach(function (k) { o[k] = el.getAttribute('data-' + k) || ''; }); return o; }
  function fillReview(el, d) {
    FIELDS.forEach(function (k) { el.setAttribute('data-' + k, d[k]); });
    function set(f, v) { var n = $('[data-f="' + f + '"]', el); if (n) n.textContent = v; return n; }
    var tag = set('service', d.service);
    if (tag) tag.hidden = !d.service;
    set('text', d.text); set('name', d.name); set('role', d.role);
    var av = set('avatar', d.initials);
    if (av) { av.style.setProperty('--c1', d.c1); av.style.setProperty('--c2', d.c2); }
    if (el.classList.contains('review')) el.setAttribute('aria-label', 'Show this review from ' + d.name + ' at the top');
  }
  var swapping = false;
  function activateCard(card) {
    if (card.hasAttribute('data-open')) { openViewer(card); return; }
    var feat = $('[data-feature]');
    if (!feat || swapping) return;
    swapping = true;
    var inner = $('.feature-inner', feat);
    var a = readReview(feat), b = readReview(card);
    var y = feat.getBoundingClientRect().top + window.pageYOffset - 116;
    window.scrollTo({ top: Math.max(0, y), behavior: reduce ? 'auto' : 'smooth' });
    if (inner) inner.classList.add('swap');
    setTimeout(function () {
      fillReview(feat, b);
      fillReview(card, a);
      if (inner) inner.classList.remove('swap');
      swapping = false;
    }, reduce ? 0 : 280);
  }

  /* ---------- Contact form ---------- */
  var RULES = {
    name: function (v) { return v.trim().length >= 2 ? '' : 'Please enter your name.'; },
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Please enter a valid email address.'; },
    phone: function (v) { return !v.trim() || /^[0-9+()\-\s.]{6,25}$/.test(v.trim()) ? '' : 'Please enter a valid phone number.'; },
    service: function (v) { return v ? '' : 'Please choose a service.'; },
    message: function (v) { var n = v.trim().length; return n === 0 ? 'Please write a message.' : n < 10 ? 'Your message needs at least 10 characters.' : ''; }
  };
  function showErr(input, msg) {
    var f = closest(input, '.field');
    if (!f) return;
    f.classList.toggle('invalid', !!msg);
    var e = $('.err', f);
    if (e) e.textContent = msg || '';
    if (msg) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid');
  }
  function checkField(input) {
    var rule = RULES[input.name];
    if (!rule) return '';
    var m = rule(input.value || '');
    showErr(input, m);
    return m;
  }
  doc.addEventListener('focusout', function (e) {
    if (e.target && e.target.form && e.target.form.hasAttribute('data-contact-form') && RULES[e.target.name]) checkField(e.target);
  });
  doc.addEventListener('input', function (e) {
    var t = e.target;
    if (t && t.form && t.form.hasAttribute('data-contact-form') && closest(t, '.field.invalid')) checkField(t);
  });

  // The one function that sends a message to the server. Resolves { ok, status, body }.
  window.SiteForm = {
    submit: function (payload) {
      return window.fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok && j && j.ok === true, status: r.status, body: j || {} }; }); });
    }
  };

  function setStatus(form, msg, isErr, withMail) {
    var st = $('[data-form-status]', form);
    if (!st) return;
    st.textContent = msg;
    st.classList.toggle('is-error', !!isErr);
    if (withMail) {
      var m = $('.ccard[href^="mailto:"]') || $('.ft-contact[href^="mailto:"]');
      if (m) {
        var a = doc.createElement('a');
        a.href = m.getAttribute('href');
        a.textContent = m.getAttribute('href').replace(/^mailto:/, '');
        st.appendChild(doc.createTextNode(' '));
        st.appendChild(a);
        st.appendChild(doc.createTextNode('.'));
      }
    }
  }
  function resetForm() {
    var panel = $('[data-form-panel]');
    if (!panel) return;
    var form = $('[data-contact-form]', panel);
    form.reset();
    $$('.field', form).forEach(function (f) { f.classList.remove('invalid'); });
    setStatus(form, '', false);
    $('[data-form-success]', panel).hidden = true;
    $('[data-form-view]', panel).hidden = false;
    var first = $('input[name="name"]', form);
    if (first) first.focus();
  }
  doc.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.hasAttribute || !form.hasAttribute('data-contact-form')) return;
    e.preventDefault();
    var bad = null;
    $$('input,select,textarea', form).forEach(function (i) {
      if (!RULES[i.name]) return;
      if (checkField(i) && !bad) bad = i;
    });
    if (bad) {
      setStatus(form, 'Please fix the highlighted fields and try again.', true);
      bad.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
      bad.focus({ preventScroll: true });
      return;
    }
    var btn = $('button[type="submit"]', form);
    var payload = {};
    $$('input,select,textarea', form).forEach(function (i) { if (i.name) payload[i.name] = i.value; });
    btn.disabled = true;
    setStatus(form, 'Sending your message…', false);
    window.SiteForm.submit(payload).then(function (res) {
      btn.disabled = false;
      if (res.ok) {
        // Only now, after the server confirmed the message was stored.
        setStatus(form, '', false);
        var panel = closest(form, '[data-form-panel]');
        $('[data-form-view]', panel).hidden = true;
        var ok = $('[data-form-success]', panel);
        ok.hidden = false;
        ok.focus();
        panel.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
        return;
      }
      if (res.status === 400 && res.body && res.body.errors) {
        var first = null;
        Object.keys(res.body.errors).forEach(function (k) {
          var inp = $('[name="' + k + '"]', form);
          if (inp) { showErr(inp, String(res.body.errors[k])); if (!first) first = inp; }
        });
        setStatus(form, 'Please fix the highlighted fields and try again.', true);
        if (first) first.focus();
        return;
      }
      if (res.status === 429) { setStatus(form, 'Too many messages were sent from this connection. Please wait a little and try again.', true); return; }
      setStatus(form, 'Your message could not be sent because the server is not available right now. Please try again shortly, or email', true, true);
    }).catch(function () {
      btn.disabled = false;
      setStatus(form, 'Your message could not be sent because the server could not be reached. Please try again shortly, or email', true, true);
    });
  });

  /* ---------- init (runs after the first paint and after every re-render) ---------- */
  function initPage() {
    if (hasGSAP()) { try { window.ScrollTrigger.getAll().forEach(function (t) { t.kill(); }); } catch (e) {} }
    onScroll();
    setupRotor();
    setupReveals();
    setupCounters();
    setupSlider();
  }

  /* ---------- boot: re-render only when newer content has been saved ---------- */
  function apply(c, hash) {
    var app = $('#app');
    if (!app || !window.Render) return;
    var page = app.getAttribute('data-page');
    var built = {};
    (app.getAttribute('data-built') || '').split(',').forEach(function (k) { if (k) built[k] = true; });
    closeMenu(); closeViewer();
    app.innerHTML = window.Render.renderApp(c, { page: page, built: built });
    app.setAttribute('data-hash', hash);
    var st = $('#theme-vars');
    if (st) st.textContent = window.Render.themeCss(c);
    var meta = window.Render.pageMeta(c, page);
    if (meta.title) doc.title = meta.title;
    var d = $('meta[name="description"]');
    if (d) d.setAttribute('content', meta.description || '');
    var ic = $('link[rel="icon"]');
    if (!ic) { ic = doc.createElement('link'); ic.rel = 'icon'; doc.head.appendChild(ic); }
    ic.href = (c.settings && c.settings.favicon) || '/assets/img/favicon.svg';
    initPage();
  }
  function boot() {
    var app = $('#app');
    if (!app || !window.fetch || !window.Render) return;
    var built = app.getAttribute('data-hash') || '';
    window.fetch('/api/content-hash', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (!j || !j.hash || j.hash === built) return null;
        return window.fetch('/api/content?h=' + encodeURIComponent(j.hash), { cache: 'no-store' })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (c) { if (c && c.settings) apply(c, j.hash); });
      })
      .catch(function () { /* no server or no saved content: keep the built page */ });
  }

  setupCursor();
  initPage();
  window.addEventListener('load', function () {
    if (hasGSAP()) { try { window.ScrollTrigger.refresh(); } catch (e) {} }
  });
  boot();
})();
