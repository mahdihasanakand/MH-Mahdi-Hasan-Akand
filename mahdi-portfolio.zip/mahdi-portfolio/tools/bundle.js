// Bundles src/api.src.js into ONE dependency-free file with esbuild.
//   node bundle.js          -> ../netlify/functions/api.js   (the real function, uses Netlify Blobs)
//   node bundle.js --test   -> ../.dev/api.test.js          (local testing only, file-backed Blobs stand-in)
const path = require('path');
const esbuild = require('esbuild');
const root = path.join(__dirname, '..');
const test = process.argv.includes('--test');
esbuild.buildSync({
  entryPoints: [path.join(root, 'src', 'api.src.js')],
  bundle: true,
  platform: 'node',
  target: 'node18',
  format: 'cjs',
  outfile: path.join(root, test ? '.dev/api.test.js' : 'netlify/functions/api.js'),
  nodePaths: [path.join(__dirname, 'node_modules')],
  alias: test ? { '@netlify/blobs': path.join(__dirname, 'fake-blobs.js') } : {},
  legalComments: 'none',
  logLevel: 'info'
});
