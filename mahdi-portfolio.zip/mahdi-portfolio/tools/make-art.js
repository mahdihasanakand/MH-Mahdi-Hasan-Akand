// Generates the original placeholder artwork (portraits + project screenshots).
// Run: node tools/make-art.js
const fs = require('fs');
const path = require('path');
const out = path.join(__dirname, '..', 'assets', 'img');
fs.mkdirSync(out, { recursive: true });

function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

const pal = [
  ['#8b5cf6', '#22d3ee'],
  ['#6366f1', '#f472b6'],
  ['#22d3ee', '#34d399'],
  ['#a78bfa', '#38bdf8'],
  ['#f472b6', '#fbbf24'],
  ['#38bdf8', '#8b5cf6']
];

function work(i) {
  const r = rng(i * 977 + 13);
  const [a, b] = pal[(i - 1) % pal.length];
  const W = 1280, H = 800;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Project screenshot">`;
  s += `<defs>
<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>
<linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}" stop-opacity=".45"/><stop offset="1" stop-color="${a}" stop-opacity="0"/></linearGradient>
<radialGradient id="bg" cx=".2" cy=".1" r="1"><stop offset="0" stop-color="${a}" stop-opacity=".35"/><stop offset="1" stop-color="#0b0d1c" stop-opacity="0"/></radialGradient>
</defs>`;
  s += `<rect width="${W}" height="${H}" fill="#0b0d1c"/><rect width="${W}" height="${H}" fill="url(#bg)"/>`;
  s += `<circle cx="1100" cy="720" r="260" fill="${b}" opacity=".12"/>`;
  // window
  s += `<rect x="70" y="60" width="1140" height="680" rx="26" fill="#111428" stroke="#ffffff" stroke-opacity=".08"/>`;
  s += `<rect x="70" y="60" width="1140" height="58" rx="26" fill="#161a33"/><rect x="70" y="92" width="1140" height="26" fill="#161a33"/>`;
  s += `<circle cx="104" cy="89" r="7" fill="#ff5f57"/><circle cx="128" cy="89" r="7" fill="#febc2e"/><circle cx="152" cy="89" r="7" fill="#28c840"/>`;
  s += `<rect x="440" y="76" width="400" height="26" rx="13" fill="#ffffff" opacity=".06"/>`;
  // sidebar
  s += `<rect x="70" y="118" width="200" height="622" fill="#0e1124"/>`;
  for (let k = 0; k < 7; k++) {
    s += `<rect x="96" y="${150 + k * 46}" width="${90 + Math.round(r() * 60)}" height="12" rx="6" fill="#ffffff" opacity="${k === (i % 4) ? 0.5 : 0.14}"/>`;
    s += `<circle cx="90" cy="${156 + k * 46}" r="0" />`;
  }
  s += `<rect x="86" y="${142 + (i % 4) * 46}" width="168" height="28" rx="10" fill="url(#g)" opacity=".18"/>`;
  // KPI cards
  for (let k = 0; k < 3; k++) {
    const x = 300 + k * 296;
    s += `<rect x="${x}" y="146" width="272" height="118" rx="18" fill="#161a33" stroke="#ffffff" stroke-opacity=".06"/>`;
    s += `<rect x="${x + 22}" y="170" width="90" height="10" rx="5" fill="#ffffff" opacity=".25"/>`;
    s += `<rect x="${x + 22}" y="198" width="${110 + Math.round(r() * 70)}" height="26" rx="8" fill="url(#g)"/>`;
    s += `<rect x="${x + 22}" y="238" width="60" height="8" rx="4" fill="#ffffff" opacity=".14"/>`;
  }
  // chart card
  s += `<rect x="300" y="290" width="580" height="420" rx="20" fill="#161a33" stroke="#ffffff" stroke-opacity=".06"/>`;
  s += `<rect x="326" y="316" width="140" height="12" rx="6" fill="#ffffff" opacity=".28"/>`;
  for (let k = 0; k < 4; k++) s += `<line x1="326" x2="854" y1="${380 + k * 70}" y2="${380 + k * 70}" stroke="#ffffff" stroke-opacity=".07"/>`;
  let pts = [];
  for (let k = 0; k < 10; k++) pts.push([326 + k * 58.7, 620 - (60 + r() * 200 + k * 14)]);
  const d = pts.map((p, k) => (k ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  s += `<path d="${d} L854 650 L326 650 Z" fill="url(#f)"/>`;
  s += `<path d="${d}" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>`;
  pts.forEach((p) => { s += `<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="5" fill="#0b0d1c" stroke="${b}" stroke-width="3"/>`; });
  // side card with bars
  s += `<rect x="910" y="290" width="270" height="420" rx="20" fill="#161a33" stroke="#ffffff" stroke-opacity=".06"/>`;
  s += `<rect x="934" y="316" width="100" height="12" rx="6" fill="#ffffff" opacity=".28"/>`;
  for (let k = 0; k < 7; k++) {
    const w = 60 + Math.round(r() * 150);
    s += `<rect x="934" y="${356 + k * 46}" width="222" height="12" rx="6" fill="#ffffff" opacity=".07"/>`;
    s += `<rect x="934" y="${356 + k * 46}" width="${w}" height="12" rx="6" fill="url(#g)"/>`;
  }
  s += `</svg>`;
  return s;
}

function portrait(kind) {
  const flip = kind === 'about';
  const [a, b] = flip ? ['#22d3ee', '#8b5cf6'] : ['#8b5cf6', '#22d3ee'];
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" width="800" height="1000" role="img" aria-label="Portrait">`;
  s += `<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${flip ? '#0f1b3d' : '#1b1340'}"/><stop offset="1" stop-color="#090b20"/></linearGradient>
<radialGradient id="halo" cx=".5" cy=".42" r=".5"><stop offset="0" stop-color="${a}" stop-opacity=".55"/><stop offset="1" stop-color="${a}" stop-opacity="0"/></radialGradient>
<linearGradient id="body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b2468"/><stop offset="1" stop-color="#14173a"/></linearGradient>
<linearGradient id="head" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4a3f9c"/><stop offset="1" stop-color="#262b6b"/></linearGradient>
<linearGradient id="rim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>
</defs>`;
  s += `<rect width="800" height="1000" fill="url(#bg)"/><rect width="800" height="1000" fill="url(#halo)"/>`;
  for (let k = 0; k < 5; k++) s += `<circle cx="400" cy="430" r="${150 + k * 80}" fill="none" stroke="#ffffff" stroke-opacity="${0.07 - k * 0.01}"/>`;
  s += `<path d="M110 1000 C120 790 250 700 400 700 C550 700 680 790 690 1000 Z" fill="url(#body)"/>`;
  s += `<path d="M110 1000 C120 790 250 700 400 700 C550 700 680 790 690 1000" fill="none" stroke="url(#rim)" stroke-width="3" opacity=".7"/>`;
  s += `<path d="M320 705 L400 830 L480 705" fill="none" stroke="url(#rim)" stroke-width="3" opacity=".6"/>`;
  s += `<path d="M352 640 L352 718 Q400 760 448 718 L448 640 Z" fill="#2a2f78"/>`;
  s += `<ellipse cx="400" cy="460" rx="128" ry="158" fill="url(#head)"/>`;
  s += `<path d="M272 440 C270 330 340 280 410 284 C480 288 540 340 528 440 C500 380 440 360 400 362 C350 364 300 390 272 440 Z" fill="#161a46"/>`;
  s += `<ellipse cx="400" cy="460" rx="128" ry="158" fill="none" stroke="url(#rim)" stroke-width="3" opacity=".6"/>`;
  s += `</svg>`;
  return s;
}

fs.writeFileSync(path.join(out, 'portrait.svg'), portrait('hero'));
fs.writeFileSync(path.join(out, 'about.svg'), portrait('about'));
for (let i = 1; i <= 9; i++) fs.writeFileSync(path.join(out, `work-${i}.svg`), work(i));

const fav = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="url(#g)"/><text x="32" y="42" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="28" fill="#070812">MH</text></svg>`;
fs.writeFileSync(path.join(out, 'favicon.svg'), fav);
console.log('art written to', out);
