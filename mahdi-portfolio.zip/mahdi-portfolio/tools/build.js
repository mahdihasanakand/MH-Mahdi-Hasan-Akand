// Pre-builds the finished .html files from content/site.json using the shared renderer.
// Run: node tools/build.js
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Render = require('../assets/js/render.js');

const root = path.join(__dirname, '..');
const content = JSON.parse(fs.readFileSync(path.join(root, 'content', 'site.json'), 'utf8'));
const hash = crypto.createHash('sha256').update(Render.stable(content)).digest('hex').slice(0, 24);

// Pages that exist as real .html files.
const BUILT = { home: true, services: true, work: true, about: true, testimonials: true, contact: true };
const built = Object.keys(BUILT).join(',');

const GSAP = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js';
const ST = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js';

function shell(page, file, robots) {
  const meta = Render.pageMeta(content, page);
  const s = content.settings;
  const e = Render.esc;
  const fav = s.favicon ? `<link rel="icon" href="${e(s.favicon)}">` : '';
  const html = `<!doctype html>
<html lang="en" data-page="${page}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${e(meta.title)}</title>
<meta name="description" content="${e(meta.description)}">
<meta name="theme-color" content="${e(content.theme.bg)}">
${robots ? `<meta name="robots" content="${robots}">` : ''}
<meta property="og:title" content="${e(meta.title)}">
<meta property="og:description" content="${e(meta.description)}">
<meta property="og:type" content="website">
${fav}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700&family=Sora:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/site.css">
<style id="theme-vars">${Render.themeCss(content)}</style>
<script>document.documentElement.classList.add('js');setTimeout(function(){document.documentElement.classList.add('reveal-all')},5000);</script>
</head>
<body>
<div class="preloader" id="preloader" aria-hidden="true"><div class="pl-inner"><span class="pl-mark">${e(s.logoInitials || 'MH')}</span><span class="pl-bar"><i></i></span></div></div>
<div class="ambient" aria-hidden="true"><div class="orb o1"></div><div class="orb o2"></div><div class="orb o3"></div><div class="grid-layer"></div><div class="noise"></div></div>
<div class="cursor-dot" id="cursor-dot"><i></i></div><div class="cursor-ring" id="cursor-ring"><i></i></div>
<div id="app" data-page="${page}" data-hash="${hash}" data-built="${built}">${Render.renderApp(content, { page, built: BUILT })}</div>
<script src="${GSAP}" defer></script>
<script src="${ST}" defer></script>
<script src="/assets/js/render.js" defer></script>
<script src="/assets/js/app.js" defer></script>
</body>
</html>
`;
  fs.writeFileSync(path.join(root, file), html);
  console.log('built', file, '(' + html.length + ' bytes)');
}

const PAGE_FILES = { home: 'index.html', services: 'services.html', work: 'my-work.html', about: 'about.html', testimonials: 'testimonials.html', contact: 'contact.html' };
Object.keys(PAGE_FILES).forEach(function (k) { shell(k, PAGE_FILES[k]); });
shell('notfound', '404.html', 'noindex');
console.log('content hash', hash);
