// LOCAL TESTING ONLY. Serves the site and routes /api/* to the function bundled by `npm run bundle:test`
// (which uses tools/fake-blobs.js instead of Netlify Blobs). Mirrors the _redirects rules.
//   ADMIN_USERNAME=... ADMIN_PASSWORD=... node tools/dev-server.js [port]
const http = require('http');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const port = +(process.argv[2] || process.env.PORT || 8888);
const api = require(path.join(root, '.dev', 'api.test.js'));
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'application/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain', '.md': 'text/markdown' };
const BLOCK = /^\/(netlify|src|tools|content|\.dev|\.devdata|node_modules|tests)(\/|$)/;

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  let p = decodeURIComponent(u.pathname);
  if (p.startsWith('/api/')) {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', async () => {
      const body = Buffer.concat(chunks);
      const out = await api.handler({ path: p, httpMethod: req.method, headers: req.headers, body: body.length ? body.toString('utf8') : null, isBase64Encoded: false, queryStringParameters: Object.fromEntries(u.searchParams) });
      res.writeHead(out.statusCode, out.headers);
      res.end(out.isBase64Encoded ? Buffer.from(out.body, 'base64') : out.body);
    });
    return;
  }
  if (BLOCK.test(p)) { p = '/404.html'; }
  let f = path.join(root, p);
  if (!f.startsWith(root)) { res.writeHead(403); return res.end(); }
  const tryFiles = [f, f + '.html', path.join(f, 'index.html')];
  const hit = tryFiles.find((x) => fs.existsSync(x) && fs.statSync(x).isFile());
  if (!hit) { res.writeHead(404, { 'Content-Type': 'text/html' }); return res.end(fs.readFileSync(path.join(root, '404.html'))); }
  res.writeHead(BLOCK.test(u.pathname) ? 404 : 200, { 'Content-Type': MIME[path.extname(hit)] || 'application/octet-stream' });
  res.end(fs.readFileSync(hit));
}).listen(port, '127.0.0.1', () => console.log('dev server on http://127.0.0.1:' + port));
