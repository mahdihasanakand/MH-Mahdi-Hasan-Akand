// LOCAL TESTING ONLY. A file-backed stand-in for @netlify/blobs so the Netlify Function can be
// exercised on a laptop. It is never part of the deployed function: `npm run bundle` uses the real
// @netlify/blobs. Used by `npm run bundle:test` and tools/dev-server.js.
const fs = require('fs');
const path = require('path');
const ROOT = process.env.FAKE_BLOBS_DIR || path.join(__dirname, '..', '.devdata');
const enc = (k) => Buffer.from(k).toString('hex');
const dec = (f) => Buffer.from(f, 'hex').toString();

class Store {
  constructor(name) { this.dir = path.join(ROOT, name); fs.mkdirSync(this.dir, { recursive: true }); }
  f(key) { return path.join(this.dir, enc(key)); }
  async get(key, opts) {
    const f = this.f(key);
    if (!fs.existsSync(f)) return null;
    const buf = fs.readFileSync(f);
    const t = opts && opts.type;
    if (t === 'json') return JSON.parse(buf.toString());
    if (t === 'arrayBuffer') return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    return buf.toString();
  }
  meta(key) { const m = this.f(key) + '.meta'; return fs.existsSync(m) ? JSON.parse(fs.readFileSync(m, 'utf8')) : {}; }
  async getMetadata(key) { if (!fs.existsSync(this.f(key))) return null; return { etag: 'x', metadata: this.meta(key) }; }
  async getWithMetadata(key, opts) {
    const data = await this.get(key, opts);
    if (data === null) return null;
    return { data, etag: 'x', metadata: this.meta(key) };
  }
  async set(key, data, opts) {
    const b = typeof data === 'string' ? Buffer.from(data) : Buffer.from(data);
    fs.writeFileSync(this.f(key), b);
    fs.writeFileSync(this.f(key) + '.meta', JSON.stringify((opts && opts.metadata) || {}));
    return { modified: true };
  }
  async setJSON(key, v, opts) { return this.set(key, JSON.stringify(v), opts); }
  async delete(key) { for (const f of [this.f(key), this.f(key) + '.meta']) if (fs.existsSync(f)) fs.unlinkSync(f); }
  async list() {
    return { blobs: fs.readdirSync(this.dir).filter((f) => !f.endsWith('.meta')).map((f) => ({ key: dec(f), etag: 'x' })), directories: [] };
  }
}
module.exports = {
  getStore(arg) { return new Store(typeof arg === 'string' ? arg : arg.name); },
  connectLambda() {}
};
