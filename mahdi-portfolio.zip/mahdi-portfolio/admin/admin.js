/*
 * Admin Panel (vanilla JS).
 *
 * - Everything typed here reaches the page through textContent / .value, never innerHTML.
 * - Every Save is a real request to the server (PUT /api/admin/content). After it succeeds the
 *   public copy is read back, so "Saved" is only shown when the website really has the change.
 * - There is no browser-only storage: refresh, another browser or another device all see the same data.
 */
(function () {
  'use strict';

  var R = window.Render;
  var root = document.getElementById('admin');
  var toastBox = document.getElementById('toasts');
  if (!R || !root) { if (root) root.textContent = 'The admin panel could not start.'; return; }
  var SVGNS = 'http://www.w3.org/2000/svg';

  /* ---------- static config ---------- */
  var SECTIONS = [
    ['dashboard', 'Dashboard', 'dashboard'],
    ['home', 'Home Page', 'home'],
    ['work', 'My Work', 'work'],
    ['about', 'About Me', 'about'],
    ['services', 'Services', 'services'],
    ['testimonials', 'Testimonials', 'testimonials'],
    ['contact', 'Contact Information', 'contact'],
    ['inbox', 'Inbox', 'inbox'],
    ['media', 'Images / Media', 'images'],
    ['theme', 'Theme / Colors', 'theme'],
    ['settings', 'Website Settings', 'settings'],
    ['account', 'Admin Account', 'account']
  ];
  var CONTENT_SECTIONS = ['home', 'work', 'about', 'services', 'testimonials', 'contact', 'theme', 'settings'];
  var PAGE_URL = { home: '/', services: '/services.html', work: '/my-work.html', about: '/about.html', testimonials: '/testimonials.html', contact: '/contact.html' };
  var BUILTIN_ART = ['portrait', 'about', 'work-1', 'work-2', 'work-3', 'work-4', 'work-5', 'work-6', 'work-7', 'work-8', 'work-9', 'favicon'].map(function (n) { return '/assets/img/' + n + '.svg'; });
  var PRESETS = [
    { name: 'Aurora', bg: '#070812', accent: '#8b5cf6', accent2: '#22d3ee', text: '#eef0ff' },
    { name: 'Ember', bg: '#0d0807', accent: '#f97316', accent2: '#f43f5e', text: '#fff1ec' },
    { name: 'Emerald', bg: '#06100d', accent: '#10b981', accent2: '#38bdf8', text: '#ecfdf5' },
    { name: 'Ocean', bg: '#050b17', accent: '#3b82f6', accent2: '#06b6d4', text: '#eaf2ff' },
    { name: 'Rose', bg: '#10070d', accent: '#ec4899', accent2: '#a78bfa', text: '#fff0f7' },
    { name: 'Gold', bg: '#0e0b05', accent: '#f59e0b', accent2: '#f97316', text: '#fff8e6' },
    { name: 'Daylight', bg: '#f5f6fb', accent: '#6d28d9', accent2: '#0891b2', text: '#14162b' }
  ];
  var PAGE_CHOICES = [['', 'None (show the email address instead)'], ['home', 'Home'], ['services', 'Services'], ['work', 'My Work'], ['about', 'About Me'], ['testimonials', 'Testimonials'], ['contact', 'Contact']];
  var IMG_OK = /^(\/[A-Za-z0-9._~\/%-]+|https:\/\/[^\s"'<>]+)$/;
  var MAX_RAW = 3300000;

  var PATHS = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    work: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="9" r="1.6"/><path d="M21 16l-5-5-9 9"/>',
    about: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    services: '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>',
    testimonials: '<path d="M9 7H5.5A1.5 1.5 0 0 0 4 8.5V13a1.5 1.5 0 0 0 1.5 1.5H8V16a3 3 0 0 1-3 3M20 7h-3.5A1.5 1.5 0 0 0 15 8.5V13a1.5 1.5 0 0 0 1.5 1.5H19V16a3 3 0 0 1-3 3"/>',
    contact: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5h13L22 12v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z"/>',
    images: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="9" r="1.6"/><path d="M21 16l-5-5-9 9"/>',
    theme: '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 2-.9 2-2 0-.6-.2-1-.6-1.4-.3-.4-.5-.8-.5-1.3 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4c0-4-4-7.5-9-7.5z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>',
    account: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    ext: '<path d="M7 17L17 7M8 7h9v9"/>',
    out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    save: '<path d="M5 3h11l4 4v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 6L2 7"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>'
  };

  /* ---------- state ---------- */
  var state = { me: null, content: null, snap: '', section: 'dashboard', stats: null, messages: null, images: null, open: {}, saving: false, uid: 0 };

  /* ---------- tiny DOM helpers ---------- */
  function add(el, c) {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
  }
  function h(tag, props) {
    var el = document.createElement(tag);
    if (props) Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') el.className = v;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else el.setAttribute(k, v === true ? '' : String(v));
    });
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function ic(name, cls) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '1.7'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false'); s.setAttribute('class', 'ic' + (cls ? ' ' + cls : ''));
    s.innerHTML = PATHS[name] || '';
    return s;
  }
  function siteIcon(name) {
    var t = document.createElement('template');
    t.innerHTML = R.icon(name);
    return t.content.firstChild;
  }
  function uid() { return 'f' + (++state.uid); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function newId() { return 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function fmtDate(s) { var d = new Date(s); return isNaN(d) ? '' : d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  /* ---------- toasts & modal ---------- */
  function toast(msg, kind) {
    var t = h('div', { class: 'toast ' + (kind || '') }, msg);
    toastBox.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, kind === 'err' ? 9000 : 4500);
  }
  function modal(o) {
    var prev = document.activeElement;
    var m, close, onKey;
    close = function (val) {
      document.removeEventListener('keydown', onKey, true);
      if (m.parentNode) m.parentNode.removeChild(m);
      if (prev && prev.focus && document.body.contains(prev)) prev.focus();
      if (o.onClose) o.onClose(val);
    };
    var acts = h('div', { class: 'modal-acts' }, (o.actions || []).map(function (a) {
      return h('button', { type: 'button', class: 'abtn' + (a.danger ? ' danger' : '') + (a.primary ? ' primary' : ''), onclick: function () { if (a.onClick) a.onClick(close); else close(a.value); } }, a.label);
    }));
    var box = h('div', { class: 'modal-box' + (o.wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': o.title, tabindex: '-1' }, h('h2', null, o.title), o.body, acts);
    m = h('div', { class: 'modal' }, h('div', { class: 'modal-bg', onclick: function () { close(undefined); } }), box);
    onKey = function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); close(undefined); return; }
      if (e.key === 'Tab') {
        var f = Array.prototype.slice.call(box.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')).filter(function (x) { return !x.disabled && x.offsetParent !== null; });
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (!box.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
        else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(m);
    var fo = box.querySelector('[data-autofocus]') || box.querySelector('.modal-acts button') || box;
    fo.focus();
    return { close: close, box: box };
  }
  function confirmBox(title, text, okLabel, danger) {
    return new Promise(function (res) {
      modal({
        title: title, body: h('p', null, text),
        actions: [{ label: 'Cancel', value: false }, { label: okLabel || 'Confirm', danger: !!danger, value: true }],
        onClose: function (v) { res(v === true); }
      });
    });
  }

  /* ---------- API ---------- */
  function apiError(msg, status, data) { var e = new Error(msg); e.status = status; e.data = data; return e; }
  async function api(method, url, body) {
    var res;
    try {
      res = await fetch('/api' + url, {
        method: method, credentials: 'same-origin', cache: 'no-store',
        headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
        body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch (e) { throw apiError('Cannot reach the server. Check your connection and try again.', 0); }
    var data = null;
    try { data = await res.json(); } catch (e) { /* not JSON */ }
    if (res.status === 401 && url.indexOf('/login') !== 0 && url !== '/me') {
      signedOut('Your session has ended. Please sign in again.');
      throw apiError('Not signed in.', 401, data);
    }
    if (!res.ok) throw apiError((data && data.error) || ('The server returned an error (' + res.status + ').'), res.status, data);
    return data;
  }

  /* ---------- content access ---------- */
  function get(path) {
    var o = state.content, ks = path.split('.');
    for (var i = 0; i < ks.length; i++) { if (o === null || o === undefined) return undefined; o = o[ks[i]]; }
    return o;
  }
  function set(path, v) {
    var ks = path.split('.'), o = state.content;
    for (var i = 0; i < ks.length - 1; i++) o = o[ks[i]];
    o[ks[ks.length - 1]] = v;
    markDirty();
  }
  function isDirty() { return !!state.content && JSON.stringify(state.content) !== state.snap; }
  function markDirty() {
    var d = isDirty();
    Array.prototype.forEach.call(document.querySelectorAll('.dirty'), function (el) { el.classList.toggle('on', d); });
  }
  window.addEventListener('beforeunload', function (e) { if (isDirty()) { e.preventDefault(); e.returnValue = ''; } });

  function applyTheme() {
    var st = document.getElementById('theme-vars');
    if (st && state.content) st.textContent = R.themeCss(state.content);
  }

  /* ---------- form building blocks ---------- */
  function card(title, sub) {
    var kids = Array.prototype.slice.call(arguments, 2);
    return h('section', { class: 'acard glass' }, title ? h('h2', null, title) : null, sub ? h('p', { class: 'sub' }, sub) : null, kids);
  }
  function grid(cls) { return h('div', { class: 'agrid' + (cls ? ' ' + cls : '') }, Array.prototype.slice.call(arguments, 1)); }
  function note(text) { return h('p', { class: 'anote' }, text); }

  function field(path, o) {
    o = o || {};
    var id = uid(), el, v = get(path);
    if (o.type === 'textarea') el = h('textarea', { id: id, rows: o.rows || 4, maxlength: o.max });
    else if (o.type === 'select') el = h('select', { id: id }, o.options.map(function (p) { return h('option', { value: p[0] }, p[1]); }));
    else el = h('input', { id: id, type: o.type || 'text', maxlength: o.max, placeholder: o.ph, inputmode: o.inputmode, autocomplete: 'off' });
    el.value = v === undefined || v === null ? '' : v;
    el.addEventListener('input', function () { set(path, el.value); if (o.onInput) o.onInput(el.value); });
    return h('div', { class: 'fld' + (o.wide ? ' wide' : '') }, h('label', { for: id }, o.label, o.hint ? h('span', { class: 'hint' }, ' — ' + o.hint) : null), el);
  }

  function colorField(path, label) {
    var id = uid(), cur = get(path) || '#000000';
    var pick = h('input', { type: 'color', id: id, 'aria-label': label + ' picker' });
    var txt = h('input', { type: 'text', maxlength: 7, 'aria-label': label + ' hex value', spellcheck: 'false' });
    pick.value = cur; txt.value = cur;
    pick.addEventListener('input', function () { txt.value = pick.value; set(path, pick.value.toLowerCase()); });
    txt.addEventListener('input', function () {
      var v = txt.value.trim();
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { pick.value = v; set(path, v.toLowerCase()); }
    });
    return h('div', { class: 'fld' }, h('label', { for: id }, label), h('div', { class: 'colorfld' }, pick, txt));
  }

  function imageField(path, label, o) {
    o = o || {};
    var id = uid(), cur = get(path) || '';
    var thumb = h('img', { class: 'thumb' + (cur ? '' : ' empty'), alt: '', src: cur || null });
    thumb.addEventListener('error', function () { thumb.classList.add('empty'); });
    thumb.addEventListener('load', function () { thumb.classList.remove('empty'); });
    var txt = h('input', { type: 'text', id: id, maxlength: 400, placeholder: '/api/img/… or https://…', spellcheck: 'false' });
    txt.value = cur;
    function update(v, fromInput) {
      set(path, v);
      if (!fromInput) txt.value = v;
      if (v) { thumb.src = v; thumb.classList.remove('empty'); } else { thumb.removeAttribute('src'); thumb.classList.add('empty'); }
    }
    txt.addEventListener('input', function () { update(txt.value.trim(), true); });
    var row = h('div', { class: 'row' },
      h('button', { type: 'button', class: 'abtn sm', onclick: function () { pickImage(function (url) { update(url); }); } }, ic('images'), 'Choose'),
      o.required ? null : h('button', { type: 'button', class: 'abtn sm', onclick: function () { update(''); } }, 'Remove'));
    return h('div', { class: 'fld' + (o.wide ? ' wide' : '') }, h('label', { for: id }, label, o.hint ? h('span', { class: 'hint' }, ' — ' + o.hint) : null), h('div', { class: 'imgfld' }, thumb, h('div', { class: 'stack' }, txt, row)));
  }

  function iconBtn(name, label, onclick, extra) {
    return h('button', { type: 'button', class: 'icon-btn' + (extra ? ' ' + extra : ''), 'aria-label': label, title: label, onclick: onclick }, ic(name));
  }

  function moveItem(arr, i, d) { var j = i + d; if (j < 0 || j >= arr.length) return false; var t = arr[i]; arr[i] = arr[j]; arr[j] = t; return true; }

  // A list of plain strings (roles, bullets, chips, paragraphs).
  function strList(path, label, o) {
    o = o || {};
    var arr = get(path) || [];
    var box = h('div', { class: 'srows', 'data-list': path });
    arr.forEach(function (val, i) {
      var id = uid();
      var inp = o.multiline ? h('textarea', { id: id, rows: 4, maxlength: o.max || 900, 'aria-label': label + ' ' + (i + 1) }) : h('input', { id: id, type: 'text', maxlength: o.max || 120, 'aria-label': label + ' ' + (i + 1), autocomplete: 'off' });
      inp.value = val;
      inp.addEventListener('input', function () { arr[i] = inp.value; markDirty(); });
      box.appendChild(h('div', { class: 'srow' }, inp, h('div', { class: 'acts' },
        iconBtn('up', 'Move up', function () { if (moveItem(arr, i, -1)) { markDirty(); rerender(); } }),
        iconBtn('down', 'Move down', function () { if (moveItem(arr, i, 1)) { markDirty(); rerender(); } }),
        iconBtn('trash', 'Remove', function () { arr.splice(i, 1); markDirty(); rerender(); }, 'danger'))));
    });
    var addBtn = h('button', { type: 'button', class: 'abtn sm', disabled: o.maxItems && arr.length >= o.maxItems, onclick: function () { arr.push(''); markDirty(); rerender(function () { var l = document.querySelector('[data-list="' + path + '"]'); var x = l && l.querySelectorAll('input,textarea'); if (x && x.length) x[x.length - 1].focus(); }); } }, ic('plus'), o.addLabel || 'Add');
    return h('div', { class: 'fld wide' }, h('span', { class: 'lbl' }, label, o.hint ? h('span', { class: 'hint' }, ' — ' + o.hint) : null), box, h('div', { class: 'list-foot' }, addBtn));
  }

  // A list of items with several fields each (services, projects, reviews, stats).
  function repeater(path, o) {
    var arr = get(path) || [];
    var wrap = h('div', { 'data-rep': path });
    if (!arr.length) wrap.appendChild(h('div', { class: 'empty-list' }, o.empty || 'Nothing here yet.'));
    arr.forEach(function (it, i) {
      var base = path + '.' + i;
      var titleEl = h('span', { class: 't' }, o.itemTitle(it, i) || 'Untitled');
      var d = h('details', { class: 'rep' },
        h('summary', null, h('span', { class: 'n' }, i + 1), titleEl, h('span', { class: 'acts' },
          iconBtn('up', 'Move up', function (e) { e.preventDefault(); e.stopPropagation(); if (moveItem(arr, i, -1)) { state.open[path] = i - 1; markDirty(); rerender(); } }),
          iconBtn('down', 'Move down', function (e) { e.preventDefault(); e.stopPropagation(); if (moveItem(arr, i, 1)) { state.open[path] = i + 1; markDirty(); rerender(); } }),
          iconBtn('trash', 'Delete', function (e) {
            e.preventDefault(); e.stopPropagation();
            confirmBox('Delete this ' + o.noun + '?', '“' + (o.itemTitle(it, i) || 'Untitled') + '” will be removed from the list. It is removed from your website when you press Save changes.', 'Delete', true).then(function (yes) {
              if (!yes) return;
              arr.splice(i, 1); state.open[path] = -1; markDirty(); rerender();
            });
          }, 'danger'))),
        h('div', { class: 'rep-body' }, o.fields(base, it, i)));
      if (state.open[path] === i) d.setAttribute('open', '');
      d.addEventListener('toggle', function () { if (d.open) state.open[path] = i; else if (state.open[path] === i) state.open[path] = -1; });
      d.addEventListener('input', function () { titleEl.textContent = o.itemTitle(arr[i], i) || 'Untitled'; });
      wrap.appendChild(d);
    });
    var full = o.max && arr.length >= o.max;
    wrap.appendChild(h('div', { class: 'list-foot' }, h('button', {
      type: 'button', class: 'abtn', disabled: !!full,
      onclick: function () {
        var item = o.make();
        if (o.atTop) { arr.unshift(item); state.open[path] = 0; } else { arr.push(item); state.open[path] = arr.length - 1; }
        markDirty();
        rerender(function () {
          var el = document.querySelector('[data-rep="' + path + '"] details[open]');
          if (el) { el.scrollIntoView({ block: 'center' }); var f = el.querySelector('input,textarea,select'); if (f) f.focus({ preventScroll: true }); }
        });
      }
    }, ic('plus'), o.addLabel || 'Add ' + o.noun), full ? h('span', { class: 'hint' }, 'The limit of ' + o.max + ' has been reached.') : null));
    return wrap;
  }

  function ctaCard(base, title, sub) {
    return card(title, sub, grid('',
      field(base + '.heading', { label: 'Heading (first part)', max: 120 }),
      field(base + '.headingAccent', { label: 'Heading (highlighted part)', max: 120 }),
      field(base + '.text', { label: 'Text', type: 'textarea', rows: 3, max: 300, wide: true }),
      field(base + '.button', { label: 'Main button label', max: 40, hint: 'links to the Contact page' }),
      field(base + '.secondaryLabel', { label: 'Second button label', max: 40, hint: 'leave empty to show the email address instead' }),
      field(base + '.secondaryPage', { label: 'Second button goes to', type: 'select', options: PAGE_CHOICES })));
  }
  function pageHeadCard(page, title) {
    return card(title || 'Page header', 'The breadcrumb, label, two-line heading and intro at the top of the page.', grid('',
      field('pages.' + page + '.eyebrow', { label: 'Small label above the heading', max: 60 }),
      field('pages.' + page + '.heading', { label: 'Heading, line 1', max: 120 }),
      field('pages.' + page + '.headingAccent', { label: 'Heading, line 2 (highlighted)', max: 120 }),
      field('pages.' + page + '.intro', { label: 'Intro paragraph', type: 'textarea', rows: 3, max: 600, wide: true })));
  }
  function secHeadFields(base) {
    return [
      field(base + '.eyebrow', { label: 'Small label', max: 60 }),
      field(base + '.heading', { label: 'Heading (first part)', max: 120 }),
      field(base + '.headingAccent', { label: 'Heading (highlighted part)', max: 120 }),
      field(base + '.sub', { label: 'Short intro', max: 300 })
    ];
  }

  /* ---------- image picker + upload ---------- */
  function readB64(blob) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { res(String(fr.result).split(',')[1] || ''); };
      fr.onerror = function () { rej(new Error('The file could not be read.')); };
      fr.readAsDataURL(blob);
    });
  }
  function shrink(file) {
    return new Promise(function (res, rej) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var max = 2400, k = Math.min(1, max / Math.max(img.width, img.height));
        var cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(img.width * k)); cv.height = Math.max(1, Math.round(img.height * k));
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        var q = 0.9;
        (function attempt() {
          cv.toBlob(function (b) {
            if (!b) return rej(new Error('This image is too large and could not be resized.'));
            if (b.size > MAX_RAW && q > 0.45) { q -= 0.15; return attempt(); }
            if (b.size > MAX_RAW) return rej(new Error('This image is still too large after resizing. Please use a smaller one.'));
            res({ blob: b, name: file.name.replace(/\.[^.]+$/, '') + (b.type === 'image/webp' ? '.webp' : '.jpg') });
          }, 'image/webp', q);
        })();
      };
      img.onerror = function () { URL.revokeObjectURL(url); rej(new Error('This image could not be opened.')); };
      img.src = url;
    });
  }
  async function uploadFile(file) {
    var ext = (/\.([A-Za-z0-9]{2,5})$/.exec(file.name) || [])[1];
    ext = ext ? ext.toLowerCase() : '';
    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico'].indexOf(ext) < 0) throw new Error('“' + file.name + '” is not allowed. Use PNG, JPG, GIF, WEBP, SVG or ICO.');
    var blob = file, name = file.name;
    if (file.size > MAX_RAW) {
      if (['png', 'jpg', 'jpeg', 'webp'].indexOf(ext) < 0) throw new Error('“' + file.name + '” is too large (limit ' + fmtSize(MAX_RAW) + ').');
      var s = await shrink(file); blob = s.blob; name = s.name;
    }
    var data = await readB64(blob);
    var r = await api('POST', '/admin/images', { filename: name, data: data });
    return r.image;
  }
  async function loadImages() {
    var r = await api('GET', '/admin/images');
    state.images = r.images || [];
    return state.images;
  }
  function pickImage(cb) {
    var gridEl = h('div', { class: 'mgrid' }), artEl = h('div', { class: 'mgrid' });
    var fileIn = h('input', { type: 'file', accept: '.png,.jpg,.jpeg,.gif,.webp,.svg,.ico,image/*', multiple: true, class: 'adm-hidden', 'aria-label': 'Upload images' });
    var m;
    function choose(url) { m.close(); cb(url); }
    function tile(url, name, sub) {
      return h('button', { type: 'button', class: 'mcard pick', onclick: function () { choose(url); }, 'aria-label': 'Use ' + name },
        h('div', { class: 'pic' }, h('img', { src: url, alt: '', loading: 'lazy' })), h('div', { class: 'info' }, h('b', null, name), h('span', null, sub)));
    }
    function fill() {
      clear(gridEl);
      var list = state.images || [];
      if (!list.length) gridEl.appendChild(h('p', { class: 'hint' }, 'No uploads yet. Use “Upload new image”.'));
      list.forEach(function (im) { gridEl.appendChild(tile(im.url, im.name, fmtSize(im.size))); });
    }
    BUILTIN_ART.forEach(function (u) { artEl.appendChild(tile(u, u.split('/').pop(), 'Built-in artwork')); });
    fileIn.addEventListener('change', async function () {
      var files = Array.prototype.slice.call(fileIn.files); fileIn.value = '';
      var last = null;
      for (var i = 0; i < files.length; i++) {
        try { toast('Uploading ' + files[i].name + '…'); last = await uploadFile(files[i]); state.images = [last].concat(state.images || []); }
        catch (e) { toast(e.message, 'err'); }
      }
      fill();
      if (last && files.length === 1) { toast('Image uploaded.', 'ok'); choose(last.url); }
      else if (last) toast('Images uploaded. Click one to use it.', 'ok');
    });
    var body = h('div', null,
      h('div', { class: 'drop' }, h('button', { type: 'button', class: 'abtn', onclick: function () { fileIn.click(); } }, ic('upload'), 'Upload new image'), h('p', null, 'PNG, JPG, GIF, WEBP, SVG or ICO. Large photos are resized automatically.'), fileIn),
      h('h3', { class: 'lbl', style: 'margin:0 0 10px' }, 'Your images'), gridEl,
      h('h3', { class: 'lbl', style: 'margin:22px 0 10px' }, 'Built-in artwork'), artEl);
    m = modal({ title: 'Choose an image', body: body, wide: true, actions: [{ label: 'Close', value: null }] });
    fill();
    loadImages().then(fill).catch(function (e) { if (e.status !== 401) toast(e.message, 'err'); });
  }

  /* ---------- validation ---------- */
  function validate() {
    var c = state.content, p = [];
    var EMAIL = /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/;
    if (!String(c.settings.brand).trim()) p.push('Website Settings: the brand name cannot be empty.');
    if (c.contact.email && !EMAIL.test(String(c.contact.email).trim())) p.push('Contact Information: the email address is not valid.');
    (c.contact.socials || []).forEach(function (s, i) { if (!/^https?:\/\/[^\s"'<>]+$/i.test(String(s.url).trim())) p.push('Contact Information: social link ' + (i + 1) + ' must be a full link starting with https://'); });
    (c.home.stats || []).forEach(function (s, i) { if (!/^\d{1,9}(\.\d{1,2})?$/.test(String(s.value).trim())) p.push('Home Page: statistic ' + (i + 1) + ' must be a plain number such as 12 or 4.5.'); });
    (c.services || []).forEach(function (s, i) { if (!String(s.title).trim()) p.push('Services: service ' + (i + 1) + ' needs a name.'); });
    (c.projects || []).forEach(function (s, i) { if (!String(s.title).trim()) p.push('My Work: project ' + (i + 1) + ' needs a title.'); if (!String(s.image).trim()) p.push('My Work: project ' + (i + 1) + ' needs a screenshot.'); });
    (c.testimonials || []).forEach(function (s, i) { if (!String(s.name).trim() || !String(s.text).trim()) p.push('Testimonials: review ' + (i + 1) + ' needs a name and the review text.'); });
    var imgs = [['Website Settings: logo image', c.settings.logoImage], ['Website Settings: tab icon', c.settings.favicon], ['Home Page: hero photo', c.home.hero.portrait], ['Home Page: about photo', c.home.about.photo], ['About Me: photo', c.pages.about.photo]];
    (c.projects || []).forEach(function (s, i) { imgs.push(['My Work: project ' + (i + 1) + ' screenshot', s.image]); });
    imgs.forEach(function (x) { if (x[1] && !IMG_OK.test(String(x[1]))) p.push(x[0] + ' must be chosen with the Choose button, or be a full https:// link.'); });
    return p;
  }

  /* ---------- saving ---------- */
  async function saveContent() {
    if (state.saving || !state.content) return false;
    var problems = validate();
    if (problems.length) {
      toast('Not saved. ' + problems.slice(0, 3).join(' ') + (problems.length > 3 ? ' (and ' + (problems.length - 3) + ' more)' : ''), 'err');
      return false;
    }
    state.saving = true;
    var btn = document.getElementById('save-btn');
    if (btn) { btn.disabled = true; btn.querySelector('span').textContent = 'Saving…'; }
    try {
      var r = await api('PUT', '/admin/content', state.content);
      state.content = r.content; state.snap = JSON.stringify(state.content);
      // Read the public copy back: "Saved" is only reported when the website has it.
      var live = null;
      try { var pr = await fetch('/api/content-hash', { cache: 'no-store' }); live = (await pr.json()).hash; } catch (e) { /* offline check */ }
      if (live === r.hash) toast('Saved. Your website now shows these changes.', 'ok');
      else toast('Saved on the server. The public copy can take a few seconds to catch up.', 'ok');
      applyTheme(); renderShell(); renderSection(true);
      return true;
    } catch (e) {
      if (e.status !== 401) toast('Not saved. ' + e.message, 'err');
      return false;
    } finally {
      state.saving = false;
      var b2 = document.getElementById('save-btn');
      if (b2) { b2.disabled = false; b2.querySelector('span').textContent = 'Save changes'; }
    }
  }
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && state.content && CONTENT_SECTIONS.indexOf(state.section) >= 0 && document.getElementById('save-btn')) { e.preventDefault(); saveContent(); }
  });

  /* ---------- re-render helpers ---------- */
  function rerender(after) {
    var y = window.scrollY;
    renderSection(true);
    window.scrollTo(0, y);
    if (after) after();
  }

  /* ================= SECTIONS ================= */
  function secDashboard() {
    var c = state.content, st = state.stats || {};
    function tile(n, label, sm, to) {
      return h('button', { type: 'button', class: 'tile', onclick: function () { go(to); } }, h('span', { class: 'num' }, String(n)), h('span', { class: 'lab' }, label), sm ? h('span', { class: 'sm' }, sm) : null);
    }
    var tiles = h('div', { class: 'tiles' },
      tile((c.services || []).length, 'Services', 'Shown on Services, Home, footer and the contact form', 'services'),
      tile((c.projects || []).length, 'Projects in My Work', 'The newest four feature on the Home page', 'work'),
      tile((c.testimonials || []).length, 'Testimonials', 'Shown on Testimonials and the Home slider', 'testimonials'),
      tile(st.messages === undefined ? '–' : st.messages, 'Messages in Inbox', st.unread ? st.unread + ' unread' : 'Nothing unread', 'inbox'),
      tile(st.images === undefined ? '–' : st.images, 'Uploaded images', 'In Images / Media', 'media'));
    var shortcuts = h('div', { class: 'shortcuts' }, SECTIONS.filter(function (s) { return s[0] !== 'dashboard'; }).map(function (s) {
      return h('button', { type: 'button', onclick: function () { go(s[0]); } }, ic(s[2]), s[1]);
    }));
    return [h('p', { class: 'adm-intro' }, 'Welcome back. Everything you change here is saved to the server and shows on the live website. Pick a section to edit.'), tiles, card('Jump to a section', null, shortcuts),
      card('Your website', null, h('div', { class: 'list-foot' }, h('a', { class: 'abtn', href: '/', target: '_blank', rel: 'noopener' }, ic('ext'), 'Open the website')))];
  }

  function secHome() {
    var out = [h('p', { class: 'adm-intro' }, 'The text, photo and numbers on the Home page. Services, projects and reviews shown on the Home page come from their own sections in the menu.')];
    out.push(card('Hero', 'The first screen visitors see.', grid('',
      field('home.hero.pill', { label: 'Availability pill', max: 80 }),
      field('home.hero.profession', { label: 'Profession line', max: 140 }),
      field('home.hero.nameLine1', { label: 'Name, line 1', max: 60 }),
      field('home.hero.nameLine2', { label: 'Name, line 2', max: 60 }),
      field('home.hero.rolesLabel', { label: 'Text before the rotating specialities', max: 40 }),
      field('home.hero.taglineA', { label: 'Tagline (first half)', max: 100 }),
      field('home.hero.taglineB', { label: 'Tagline (second half, in the gradient)', max: 100 }),
      field('home.hero.intro', { label: 'Intro paragraph', type: 'textarea', rows: 3, max: 500, wide: true }),
      field('home.hero.btnPrimary', { label: 'First button label', max: 40, hint: 'links to My Work' }),
      field('home.hero.btnSecondary', { label: 'Second button label', max: 40, hint: 'links to Contact; also used for the menu button' }),
      imageField('home.hero.portrait', 'Hero photo', { wide: true, hint: 'portrait works best' }),
      strList('home.hero.roles', 'Rotating specialities', { max: 80, maxItems: 12, addLabel: 'Add speciality', hint: 'shown one by one under the profession' }))));
    var fc = get('home.hero.floatCards');
    while (fc.length < 2) fc.push({ value: '', label: '' });
    out.push(card('Floating cards on the hero photo', 'Two small cards: a headline number and its label.', grid('',
      field('home.hero.floatCards.0.value', { label: 'Card 1 number', max: 16 }), field('home.hero.floatCards.0.label', { label: 'Card 1 label', max: 40 }),
      field('home.hero.floatCards.1.value', { label: 'Card 2 number', max: 16 }), field('home.hero.floatCards.1.label', { label: 'Card 2 label', max: 40 }))));
    out.push(card('Statistics', 'Numbers that count up when scrolled into view. Use a plain number, with an optional prefix and suffix such as + or %.', repeater('home.stats', {
      noun: 'statistic', max: 6, empty: 'No statistics. The statistics panel is hidden while this list is empty.',
      itemTitle: function (s) { return [s.prefix, s.value, s.suffix].join('') + (s.label ? ' — ' + s.label : ''); },
      make: function () { return { prefix: '', value: '0', suffix: '', label: '' }; },
      fields: function (b) { return grid('c4', field(b + '.prefix', { label: 'Prefix', max: 8 }), field(b + '.value', { label: 'Number', max: 14, inputmode: 'decimal' }), field(b + '.suffix', { label: 'Suffix', max: 8 }), field(b + '.label', { label: 'Label', max: 60 })); }
    })));
    out.push(card('Services section heading', 'The cards themselves come from Services in the menu.', grid('', secHeadFields('home.services'))));
    out.push(card('Featured work section', 'Shows the four newest projects from My Work.', grid('', secHeadFields('home.work'), field('home.work.button', { label: 'Button label', max: 40 }))));
    out.push(card('About teaser', 'The photo-and-text block under the work section.', grid('',
      field('home.about.eyebrow', { label: 'Small label', max: 60 }),
      field('home.about.heading', { label: 'Heading (first part)', max: 120 }),
      field('home.about.headingAccent', { label: 'Heading (highlighted part)', max: 120 }),
      field('home.about.button', { label: 'Button label', max: 40 }),
      imageField('home.about.photo', 'Photo', { wide: true }),
      field('home.about.badgeNumber', { label: 'Badge number', max: 16 }),
      field('home.about.badgeLabel', { label: 'Badge label', max: 40, hint: 'two words' }),
      field('home.about.p1', { label: 'Paragraph 1', type: 'textarea', rows: 3, max: 600, wide: true }),
      field('home.about.p2', { label: 'Paragraph 2', type: 'textarea', rows: 3, max: 600, wide: true }),
      strList('home.about.bullets', 'Ticked bullet points', { max: 100, maxItems: 6, addLabel: 'Add bullet point', hint: 'the first four are shown' }))));
    out.push(card('Tools & expertise', 'Tool chips and the scrolling keyword strip.', grid('', secHeadFields('home.tools'),
      strList('home.tools.chips', 'Tools you use daily', { max: 60, maxItems: 24, addLabel: 'Add tool' }),
      strList('home.tools.marquee', 'Scrolling keywords', { max: 60, maxItems: 24, addLabel: 'Add keyword' }))));
    out.push(card('Testimonials section heading', 'The slider appears only while there is at least one review in Testimonials.', grid('',
      field('home.testimonials.eyebrow', { label: 'Small label', max: 60 }),
      field('home.testimonials.heading', { label: 'Heading (first part)', max: 120 }),
      field('home.testimonials.headingAccent', { label: 'Heading (highlighted part)', max: 120 }),
      field('home.testimonials.button', { label: 'Button label', max: 40 }))));
    out.push(card('Closing call to action', 'The glowing panel above the footer.', grid('',
      field('home.cta.heading', { label: 'Heading (first part)', max: 120 }),
      field('home.cta.headingAccent', { label: 'Heading (highlighted part)', max: 120 }),
      field('home.cta.text', { label: 'Text', type: 'textarea', rows: 3, max: 300, wide: true }),
      field('home.cta.button', { label: 'Main button label', max: 40, hint: 'the email address is added as a second button when set in Contact Information' }))));
    return out;
  }

  function secWork() {
    return [
      h('p', { class: 'adm-intro' }, 'Each project is one screenshot, a title and a short description. The four newest projects (by date) also appear as Featured Work on the Home page, so both read from this one list.'),
      pageHeadCard('work', 'My Work page header'),
      card('Projects', 'Click a project to edit it. New projects are added at the top.', repeater('projects', {
        noun: 'project', max: 200, atTop: true, addLabel: 'Add a project', empty: 'No projects yet. The Featured Work section is hidden while this list is empty.',
        itemTitle: function (p) { return p.title; },
        make: function () { return { id: newId(), title: '', description: '', image: '', date: today() }; },
        fields: function (b) { return [grid('', field(b + '.title', { label: 'Title', max: 100 }), field(b + '.date', { label: 'Date', type: 'date', hint: 'newest dates come first' }),
          field(b + '.description', { label: 'Short description', type: 'textarea', rows: 3, max: 300, wide: true })), imageField(b + '.image', 'Screenshot', { required: true })]; }
      })),
      ctaCard('pages.work.cta', 'Page call to action', 'The glowing panel under the gallery.')
    ];
  }

  function secAbout() {
    return [
      h('p', { class: 'adm-intro' }, 'The About Me page: a photo and your story. The short About teaser on the Home page is edited in Home Page.'),
      pageHeadCard('about'),
      card('My story', null, grid('',
        field('pages.about.storyEyebrow', { label: 'Small label', max: 40 }),
        imageField('pages.about.photo', 'Photo'),
        field('pages.about.openingLine', { label: 'Opening line', type: 'textarea', rows: 2, max: 300, wide: true }),
        strList('pages.about.paragraphs', 'Story paragraphs', { multiline: true, max: 900, maxItems: 8, addLabel: 'Add paragraph' }),
        field('pages.about.signatureName', { label: 'Signature name', max: 80 }),
        field('pages.about.signatureTitle', { label: 'Signature title', max: 140 }))),
      ctaCard('pages.about.cta', 'Page call to action', 'The glowing panel at the end of the page.')
    ];
  }

  function secServices() {
    return [
      h('p', { class: 'adm-intro' }, 'Services fill the Services page, the Home page cards (the first three included points), the footer list and the service dropdown on the contact form.'),
      pageHeadCard('services'),
      card('Services', 'Click a service to edit it.', repeater('services', {
        noun: 'service', max: 24, addLabel: 'Add a service', empty: 'No services yet.',
        itemTitle: function (s) { return s.title; },
        make: function () { return { id: newId(), title: '', category: '', icon: 'megaphone', description: '', included: [], note: 'Pricing on request' }; },
        fields: function (b, it) {
          var prev = h('span', { class: 'ic-box svc-prev' }, siteIcon(it.icon || 'megaphone'));
          var sel = field(b + '.icon', { label: 'Icon', type: 'select', options: R.ICON_CHOICES.map(function (n) { return [n, n.charAt(0).toUpperCase() + n.slice(1)]; }),
            onInput: function (v) { clear(prev); prev.appendChild(siteIcon(v)); } });
          return [grid('', field(b + '.title', { label: 'Service name', max: 80 }), field(b + '.category', { label: 'Category tag', max: 40, hint: 'shown top-right on the card' }),
            h('div', { class: 'fld' }, sel.querySelector('label'), h('div', { class: 'row' }, prev, sel.querySelector('select'))),
            field(b + '.note', { label: 'Footer note', max: 80 }),
            field(b + '.description', { label: 'Description', type: 'textarea', rows: 3, max: 400, wide: true }),
            strList(b + '.included', 'What’s included', { max: 120, maxItems: 8, addLabel: 'Add point', hint: 'four to six points work best' }))];
        }
      })),
      ctaCard('pages.services.cta', 'Page call to action', 'The glowing panel at the end of the page.')
    ];
  }

  function secTestimonials() {
    return [
      h('p', { class: 'adm-intro' }, 'Reviews fill the Testimonials page and the slider on the Home page. While the list is empty the slider is hidden. Only add reviews that real clients have given you.'),
      pageHeadCard('testimonials'),
      card('Reviews', 'Click a review to edit it.', repeater('testimonials', {
        noun: 'review', max: 60, addLabel: 'Add a review', empty: 'No reviews yet.',
        itemTitle: function (t) { return t.name + (t.service ? ' — ' + t.service : ''); },
        make: function () { return { name: '', role: '', service: '', text: '', initials: '', c1: '#8b5cf6', c2: '#22d3ee' }; },
        fields: function (b, it) {
          var av = h('span', { class: 'avatar' }, it.initials || '?');
          function paint() { av.textContent = get(b + '.initials') || '?'; av.style.setProperty('--c1', get(b + '.c1')); av.style.setProperty('--c2', get(b + '.c2')); }
          av.style.setProperty('--c1', it.c1); av.style.setProperty('--c2', it.c2);
          var c1 = colorField(b + '.c1', 'Avatar colour 1'), c2 = colorField(b + '.c2', 'Avatar colour 2');
          [c1, c2].forEach(function (x) { x.addEventListener('input', paint); });
          return [grid('', field(b + '.name', { label: 'Name', max: 80 }), field(b + '.role', { label: 'Role / company', max: 80 }),
            field(b + '.service', { label: 'Service tag', max: 60 }), field(b + '.initials', { label: 'Avatar initials', max: 3, onInput: paint }),
            field(b + '.text', { label: 'Review text', type: 'textarea', rows: 4, max: 700, wide: true }), c1, c2), h('div', { class: 'row', style: 'display:flex;align-items:center;gap:12px' }, h('span', { class: 'hint' }, 'Avatar preview'), av)];
        }
      })),
      ctaCard('pages.testimonials.cta', 'Page call to action', 'The glowing panel at the end of the page.')
    ];
  }

  function secContact() {
    var socials = get('contact.socials');
    var rows = h('div', { class: 'srows', 'data-list': 'contact.socials' });
    socials.forEach(function (s, i) {
      var sel = h('select', { 'aria-label': 'Network ' + (i + 1) }, R.SOCIAL_TYPES.map(function (t) { return h('option', { value: t }, R.LABELS[t] || t); }));
      sel.value = s.type;
      sel.addEventListener('change', function () { s.type = sel.value; markDirty(); });
      var url = h('input', { type: 'url', maxlength: 400, placeholder: 'https://…', 'aria-label': 'Link ' + (i + 1), autocomplete: 'off' });
      url.value = s.url;
      url.addEventListener('input', function () { s.url = url.value; markDirty(); });
      rows.appendChild(h('div', { class: 'srow social-row fld' }, sel, url, h('div', { class: 'acts' },
        iconBtn('up', 'Move up', function () { if (moveItem(socials, i, -1)) { markDirty(); rerender(); } }),
        iconBtn('down', 'Move down', function () { if (moveItem(socials, i, 1)) { markDirty(); rerender(); } }),
        iconBtn('trash', 'Remove', function () { socials.splice(i, 1); markDirty(); rerender(); }, 'danger'))));
    });
    return [
      h('p', { class: 'adm-intro' }, 'Your email, phone, WhatsApp and social links. They fill the Contact page, the footer, the closing call to action and every mailto, tel and WhatsApp link. A field left empty simply does not appear on the website.'),
      card('Contact details', null, grid('',
        field('contact.email', { label: 'Email address', type: 'email', max: 120 }),
        field('contact.phone', { label: 'Phone', type: 'tel', max: 40, hint: 'with country code, e.g. +44 …' }),
        field('contact.whatsapp', { label: 'WhatsApp number', type: 'tel', max: 40, hint: 'with country code' }))),
      card('Social links', 'Shown as icons in the Home hero, the footer and the Contact page. Use the full link to your profile.', rows,
        h('div', { class: 'list-foot' }, h('button', { type: 'button', class: 'abtn', disabled: socials.length >= 12, onclick: function () { socials.push({ type: 'linkedin', url: '' }); markDirty(); rerender(function () { var l = document.querySelectorAll('[data-list="contact.socials"] input'); if (l.length) l[l.length - 1].focus(); }); } }, ic('plus'), 'Add a social link'))),
      pageHeadCard('contact', 'Contact page header'),
      card('Contact page wording', 'The form, the success message and the contact cards.', grid('',
        field('pages.contact.formHeading', { label: 'Form heading', max: 80 }),
        field('pages.contact.formSub', { label: 'Form sub-heading', max: 200 }),
        field('pages.contact.serviceUnsure', { label: 'Last option in the service dropdown', max: 40 }),
        field('pages.contact.submitLabel', { label: 'Send button label', max: 40 }),
        field('pages.contact.privacyNote', { label: 'Privacy line under the button', max: 200, wide: true }),
        field('pages.contact.successHeading', { label: 'Success heading', max: 60 }),
        field('pages.contact.successText', { label: 'Success message', max: 240 }),
        field('pages.contact.successButton', { label: 'Success button label', max: 40 }),
        field('pages.contact.emailHint', { label: 'Email card hint', max: 80 }),
        field('pages.contact.phoneHint', { label: 'Phone card hint', max: 80 }),
        field('pages.contact.whatsappHint', { label: 'WhatsApp card hint', max: 80 }),
        field('pages.contact.findMeTitle', { label: '“Find me online” title', max: 60 })))
    ];
  }

  /* ----- inbox ----- */
  function secInbox() {
    var host = h('div');
    function paint() {
      clear(host);
      var list = state.messages;
      if (list === null) { host.appendChild(h('p', { class: 'hint' }, 'Loading messages…')); return; }
      if (!list.length) { host.appendChild(card(null, null, h('div', { class: 'empty-list' }, 'No messages yet. Messages sent from the Contact page form appear here.'))); return; }
      list.forEach(function (m) {
        var row = h('details', { class: 'mrow' + (m.read ? '' : ' unread'), 'data-id': m.id },
          h('summary', null, h('span', { class: 'dot' }), h('span', { class: 'who2' }, m.name, h('span', null, m.service)), h('span', { class: 'meta' }, fmtDate(m.createdAt))),
          h('div', { class: 'mbody' },
            h('dl', null, h('dt', null, 'Name'), h('dd', null, m.name), h('dt', null, 'Email'), h('dd', null, h('a', { href: 'mailto:' + m.email }, m.email)),
              m.phone ? [h('dt', null, 'Phone'), h('dd', null, m.phone)] : null, h('dt', null, 'Service'), h('dd', null, m.service), h('dt', null, 'Received'), h('dd', null, fmtDate(m.createdAt))),
            h('div', { class: 'text' }, m.message),
            h('div', { class: 'list-foot' },
              h('a', { class: 'abtn', href: 'mailto:' + m.email + '?subject=' + encodeURIComponent('Re: your message') }, ic('mail'), 'Reply by email'),
              h('button', { type: 'button', class: 'abtn danger', onclick: function () {
                confirmBox('Delete this message?', 'The message from ' + m.name + ' will be deleted permanently.', 'Delete', true).then(async function (yes) {
                  if (!yes) return;
                  try { await api('DELETE', '/admin/messages/' + encodeURIComponent(m.id)); state.messages = state.messages.filter(function (x) { return x.id !== m.id; }); await loadStats(); paint(); toast('Message deleted.', 'ok'); }
                  catch (e) { if (e.status !== 401) toast(e.message, 'err'); }
                });
              } }, ic('trash'), 'Delete'))));
        row.addEventListener('toggle', async function () {
          if (!row.open || m.read) return;
          try { await api('POST', '/admin/messages/' + encodeURIComponent(m.id) + '/read', {}); m.read = true; row.classList.remove('unread'); await loadStats(); }
          catch (e) { /* stays unread */ }
        });
        host.appendChild(row);
      });
    }
    async function load() {
      try { var r = await api('GET', '/admin/messages'); state.messages = r.messages || []; await loadStats(); }
      catch (e) { state.messages = state.messages || []; if (e.status !== 401) toast(e.message, 'err'); }
      if (state.section === 'inbox') paint();
    }
    paint(); load();
    return [h('p', { class: 'adm-intro' }, 'Every message sent from the Contact page form. Opening a message marks it as read.'),
      h('div', { class: 'list-foot', style: 'margin-bottom:18px' }, h('button', { type: 'button', class: 'abtn', onclick: function () { state.messages = null; paint(); load(); } }, ic('refresh'), 'Refresh')), host];
  }

  /* ----- media ----- */
  function secMedia() {
    var host = h('div', { class: 'mgrid' });
    var fileIn = h('input', { type: 'file', accept: '.png,.jpg,.jpeg,.gif,.webp,.svg,.ico,image/*', multiple: true, class: 'adm-hidden', 'aria-label': 'Upload images' });
    function inUse(url) { return JSON.stringify(state.content).indexOf(JSON.stringify(url).slice(1, -1)) >= 0; }
    function paint() {
      clear(host);
      var list = state.images;
      if (list === null) { host.appendChild(h('p', { class: 'hint' }, 'Loading images…')); return; }
      if (!list.length) { host.appendChild(h('div', { class: 'empty-list', style: 'grid-column:1/-1' }, 'No images uploaded yet.')); return; }
      list.forEach(function (im) {
        host.appendChild(h('div', { class: 'mcard' },
          h('div', { class: 'pic' }, h('img', { src: im.url, alt: '', loading: 'lazy' })),
          h('div', { class: 'info' }, h('b', { title: im.name }, im.name), h('span', null, fmtSize(im.size)), h('span', { class: 'path' }, im.url),
            h('div', { class: 'row' },
              h('button', { type: 'button', class: 'abtn sm', onclick: function () { copyText(im.url); } }, ic('copy'), 'Copy path'),
              h('button', { type: 'button', class: 'abtn sm danger', onclick: function () {
                var used = inUse(im.url);
                confirmBox('Delete this image?', used ? 'This image is currently used on your website. If you delete it, that spot will show a broken image until you choose another one.' : '“' + im.name + '” will be deleted permanently.', 'Delete', true).then(async function (yes) {
                  if (!yes) return;
                  try { await api('DELETE', '/admin/images/' + encodeURIComponent(im.key)); state.images = state.images.filter(function (x) { return x.key !== im.key; }); await loadStats(); paint(); toast('Image deleted.', 'ok'); }
                  catch (e) { if (e.status !== 401) toast(e.message, 'err'); }
                });
              } }, ic('trash'), 'Delete')))));
      });
    }
    fileIn.addEventListener('change', async function () {
      var files = Array.prototype.slice.call(fileIn.files); fileIn.value = '';
      for (var i = 0; i < files.length; i++) {
        try { toast('Uploading ' + files[i].name + '…'); var im = await uploadFile(files[i]); state.images = [im].concat(state.images || []); toast('Uploaded ' + im.name + '.', 'ok'); paint(); }
        catch (e) { if (e.status !== 401) toast(e.message, 'err'); }
      }
      loadStats();
    });
    paint();
    loadImages().then(function () { if (state.section === 'media') paint(); }).catch(function (e) { state.images = state.images || []; if (state.section === 'media') paint(); if (e.status !== 401) toast(e.message, 'err'); });
    return [h('p', { class: 'adm-intro' }, 'Upload images once, then pick them anywhere with a Choose button. Each image gets a permanent path you can copy.'),
      h('div', { class: 'drop' }, h('button', { type: 'button', class: 'abtn', onclick: function () { fileIn.click(); } }, ic('upload'), 'Upload images'), h('p', null, 'PNG, JPG, GIF, WEBP, SVG or ICO. Photos over ' + fmtSize(MAX_RAW) + ' are resized automatically.'), fileIn), host];
  }
  function copyText(t) {
    function fallback() { var ta = h('textarea', { style: 'position:fixed;opacity:0' }); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); toast('Path copied.', 'ok'); } catch (e) { toast('Copy failed. Select and copy it by hand: ' + t, 'err'); } document.body.removeChild(ta); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { toast('Path copied.', 'ok'); }, fallback); else fallback();
  }

  /* ----- theme ----- */
  function secTheme() {
    var prev = h('div', { class: 'tprev' },
      h('div', { class: 'row' }, h('span', { class: 'eyebrow' }, 'Live preview')),
      h('h3', null, 'Marketing built on ', h('span', { class: 'grad-text' }, 'clean data')),
      h('p', null, 'This is how headings, buttons, chips, cards and glows look with the colours you are editing.'),
      h('div', { class: 'row' }, h('span', { class: 'btn btn-primary btn-sm' }, h('span', null, 'Primary button')), h('span', { class: 'btn btn-ghost btn-sm' }, h('span', null, 'Ghost button')), h('span', { class: 'chip' }, h('i'), 'Chip')),
      h('div', { class: 'row' }, h('div', { class: 'card-mini' }, 'A card with the accent glow')));
    function paint() {
      var t = get('theme');
      prev.style.setProperty('--bg', t.bg); prev.style.setProperty('--accent', t.accent); prev.style.setProperty('--accent-2', t.accent2); prev.style.setProperty('--text', t.text);
    }
    var pickers = grid('c4', colorField('theme.bg', 'Background'), colorField('theme.accent', 'Accent colour 1'), colorField('theme.accent2', 'Accent colour 2'), colorField('theme.text', 'Text colour'));
    pickers.addEventListener('input', paint);
    var presets = h('div', { class: 'presets' }, PRESETS.map(function (p) {
      return h('button', { type: 'button', class: 'preset', onclick: function () { set('theme.bg', p.bg); set('theme.accent', p.accent); set('theme.accent2', p.accent2); set('theme.text', p.text); rerender(); } },
        h('div', { class: 'sw' }, h('i', { style: 'background:' + p.bg }), h('i', { style: 'background:' + p.accent }), h('i', { style: 'background:' + p.accent2 }), h('i', { style: 'background:' + p.text })), h('b', null, p.name));
    }));
    paint();
    return [h('p', { class: 'adm-intro' }, 'Four colours drive every accent, gradient and glow on all six pages. Change them, check the preview, then press Save changes.'),
      card('Ready-made themes', 'Click one to try it in the preview.', presets), card('Your four colours', null, pickers), card('Preview', null, prev)];
  }

  /* ----- settings ----- */
  function secSettings() {
    return [
      h('p', { class: 'adm-intro' }, 'Your brand, logo, browser tab icon and footer text.'),
      card('Brand', null, grid('',
        field('settings.brand', { label: 'Brand name', max: 80, hint: 'shown next to the logo' }),
        field('settings.logoInitials', { label: 'Logo initials', max: 4, hint: 'used when there is no logo image' }),
        imageField('settings.logoImage', 'Logo image', { hint: 'optional, replaces the initials' }),
        imageField('settings.favicon', 'Browser tab icon', { hint: 'a small square image; SVG, PNG or ICO' }))),
      card('Search engines and browser tab', null, grid('',
        field('settings.siteTitle', { label: 'Browser title of the Home page', max: 160, wide: true }),
        field('settings.metaDescription', { label: 'Description for search results', type: 'textarea', rows: 3, max: 320, wide: true }))),
      card('Footer', null, grid('',
        field('settings.footerDescription', { label: 'Short description under the footer logo', type: 'textarea', rows: 3, max: 300, wide: true }),
        field('settings.footerText', { label: 'Text after the copyright year and name', max: 160, wide: true }))),
      h('section', { class: 'acard glass danger-zone' }, h('h2', null, 'Reset website content'),
        h('p', { class: 'sub' }, 'Restores the original text, services and projects. Your uploaded images, theme colours, logo, tab icon, inbox and login are kept.'),
        h('div', { class: 'list-foot' }, h('button', { type: 'button', class: 'abtn danger', onclick: resetSite }, 'Reset content…')))
    ];
  }
  async function resetSite() {
    var yes = await confirmBox('Reset all website content?', 'Every text, service, project, review and contact detail goes back to the original. This is saved straight away and cannot be undone. Images, theme, logo, tab icon, inbox and login are kept.', 'Reset content', true);
    if (!yes) return;
    try {
      var r = await api('POST', '/admin/reset', {});
      state.content = r.content; state.snap = JSON.stringify(state.content); state.open = {};
      applyTheme(); renderShell(); renderSection(); toast('Content reset to the original.', 'ok');
    } catch (e) { if (e.status !== 401) toast(e.message, 'err'); }
  }

  /* ----- account ----- */
  function secAccount() {
    var msg = h('div', { class: 'msg adm-hidden', role: 'status' });
    var cur = h('input', { type: 'password', id: 'ac-cur', autocomplete: 'current-password', required: true });
    var nu = h('input', { type: 'text', id: 'ac-user', autocomplete: 'username', maxlength: 40, placeholder: state.me ? state.me.username : '' });
    var np = h('input', { type: 'password', id: 'ac-pw', autocomplete: 'new-password', maxlength: 200 });
    var np2 = h('input', { type: 'password', id: 'ac-pw2', autocomplete: 'new-password', maxlength: 200 });
    function say(text, kind) { msg.textContent = text; msg.className = 'msg ' + kind; }
    var form = h('form', { class: 'agrid', novalidate: true, onsubmit: async function (e) {
      e.preventDefault();
      if (!cur.value) return say('Enter your current password.', 'err');
      if (!nu.value.trim() && !np.value) return say('Enter a new username, a new password, or both.', 'err');
      if (nu.value.trim() && !/^[A-Za-z0-9._@-]{3,40}$/.test(nu.value.trim())) return say('The username must be 3 to 40 characters: letters, numbers and . _ @ - only.', 'err');
      if (np.value && np.value.length < 10) return say('The new password must be at least 10 characters.', 'err');
      if (np.value !== np2.value) return say('The two new passwords do not match.', 'err');
      try {
        var r = await api('POST', '/admin/account', { currentPassword: cur.value, newUsername: nu.value.trim(), newPassword: np.value });
        state.me = { username: r.username }; cur.value = nu.value = np.value = np2.value = '';
        nu.placeholder = r.username;
        // Only the name shown in the sidebar changes. (Rebuilding the whole shell here would blank the page.)
        Array.prototype.forEach.call(document.querySelectorAll('.adm-user b'), function (b) { b.textContent = r.username; });
        Array.prototype.forEach.call(document.querySelectorAll('#adm-view .fld p'), function (el) { if (el.previousSibling && /Signed in as/.test(el.previousSibling.textContent)) el.textContent = r.username; });
        say('Saved. Your login has been updated and every other signed-in device has been signed out.', 'ok');
        toast('Login details updated.', 'ok');
      } catch (er) { if (er.status !== 401 || /password/i.test(er.message)) say(er.message, 'err'); }
    } },
      h('div', { class: 'fld wide' }, h('label', { for: 'ac-cur' }, 'Current password'), cur),
      h('div', { class: 'fld' }, h('label', { for: 'ac-user' }, 'New username', h('span', { class: 'hint' }, ' — leave empty to keep the current one')), nu),
      h('div', { class: 'fld' }, h('span', { class: 'lbl' }, 'Signed in as'), h('p', { style: 'margin:0;padding:12px 0;font-weight:600' }, state.me ? state.me.username : '')),
      h('div', { class: 'fld' }, h('label', { for: 'ac-pw' }, 'New password', h('span', { class: 'hint' }, ' — at least 10 characters, leave empty to keep it')), np),
      h('div', { class: 'fld' }, h('label', { for: 'ac-pw2' }, 'Repeat the new password'), np2),
      h('div', { class: 'fld wide' }, msg),
      h('div', { class: 'fld wide' }, h('div', { class: 'list-foot' }, h('button', { type: 'submit', class: 'btn btn-primary btn-sm' }, h('span', null, 'Update login details')))));
    return [h('p', { class: 'adm-intro' }, 'Change the username or password used to sign in. Your password is stored only as a salted scrypt hash and can never be read back. After a change, all other signed-in devices are signed out.'), card('Login details', null, form)];
  }

  /* ================= SHELL & ROUTING ================= */
  var BUILD = { dashboard: secDashboard, home: secHome, work: secWork, about: secAbout, services: secServices, testimonials: secTestimonials, contact: secContact, inbox: secInbox, media: secMedia, theme: secTheme, settings: secSettings, account: secAccount };

  function secName(id) { return (SECTIONS.filter(function (s) { return s[0] === id; })[0] || [])[1] || ''; }

  function renderShell() {
    var s = state.content ? state.content.settings : {};
    var mark = s.logoImage ? h('img', { class: 'brand-logo', src: s.logoImage, alt: '' }) : h('span', { class: 'brand-mark' }, s.logoInitials || 'MH');
    var unread = state.stats && state.stats.unread ? state.stats.unread : 0;
    var nav = h('nav', { class: 'adm-nav', 'aria-label': 'Admin sections' }, SECTIONS.map(function (sec) {
      return h('button', { type: 'button', 'data-sec': sec[0], 'aria-current': state.section === sec[0] ? 'page' : null, onclick: function () { go(sec[0]); } },
        ic(sec[2]), sec[1], sec[0] === 'inbox' ? h('span', { class: 'badge-n' + (unread ? '' : ' adm-hidden'), id: 'badge-inbox' }, String(unread)) : null);
    }));
    var side = h('aside', { class: 'adm-side', id: 'adm-side' },
      h('div', { class: 'adm-brand' }, mark, h('div', null, h('strong', null, 'Admin Panel'), h('small', null, s.brand || ''))), nav,
      h('div', { class: 'adm-side-foot' },
        h('p', { class: 'adm-user' }, 'Signed in as ', h('b', null, state.me ? state.me.username : '')),
        h('a', { class: 'abtn', href: '/', target: '_blank', rel: 'noopener' }, ic('ext'), 'Open the website'),
        h('button', { type: 'button', class: 'abtn', id: 'signout', onclick: signOut }, ic('out'), 'Sign out')));
    var open = root.querySelector('.adm') && root.querySelector('.adm').classList.contains('adm-open');
    var main = h('main', { class: 'adm-main', id: 'adm-main' },
      h('div', { class: 'adm-top' }, h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Open menu', onclick: function () { document.querySelector('.adm').classList.add('adm-open'); } }, ic('menu')), h('strong', null, 'Admin Panel')),
      h('div', { id: 'adm-view' }));
    var shell = h('div', { class: 'adm' + (open ? ' adm-open' : '') }, side, main, h('div', { class: 'adm-scrim', onclick: closeMenu }));
    var scrim = shell.querySelector('.adm-scrim'); scrim.style.display = open ? '' : 'none';
    root.replaceChildren(shell);
  }
  function closeMenu() { var a = document.querySelector('.adm'); if (a) a.classList.remove('adm-open'); }

  function renderSection(keepScroll) {
    var view = document.getElementById('adm-view');
    if (!view) return;
    var id = state.section, name = secName(id);
    var isContent = CONTENT_SECTIONS.indexOf(id) >= 0;
    var bar = h('div', { class: 'adm-bar' }, h('h1', null, name), h('div', { class: 'adm-bar-actions' },
      isContent ? h('span', { class: 'dirty' + (isDirty() ? ' on' : '') }, 'Unsaved changes') : null,
      PAGE_URL[id] ? h('a', { class: 'abtn sm', href: PAGE_URL[id], target: '_blank', rel: 'noopener' }, ic('ext'), 'View page') : null,
      isContent ? h('button', { type: 'button', class: 'btn btn-primary btn-sm', id: 'save-btn', onclick: saveContent }, ic('save'), h('span', null, 'Save changes')) : null));
    var body = BUILD[id]();
    view.replaceChildren(bar);
    add(view, body);
    document.title = name + ' · Admin Panel';
    Array.prototype.forEach.call(document.querySelectorAll('.adm-nav button'), function (b) { if (b.getAttribute('data-sec') === id) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    if (!keepScroll) window.scrollTo(0, 0);
  }

  function go(id) {
    closeMenu();
    if (location.hash === '#' + id) { state.section = id; renderSection(); return; }
    location.hash = '#' + id;
  }
  window.addEventListener('hashchange', function () {
    var id = location.hash.replace('#', '');
    if (!BUILD[id] || !state.content || !document.getElementById('adm-view')) return;
    state.section = id; closeMenu();
    if (id === 'dashboard') loadStats().then(function () { if (state.section === 'dashboard') renderSection(true); });
    renderSection();
  });

  async function loadStats() {
    try {
      state.stats = await api('GET', '/admin/stats');
      var b = document.getElementById('badge-inbox');
      if (b) { b.textContent = String(state.stats.unread || 0); b.classList.toggle('adm-hidden', !state.stats.unread); }
    } catch (e) { /* shown elsewhere */ }
  }

  /* ---------- login / boot ---------- */
  function signedOut(note) {
    state.me = null;
    renderLogin(note);
  }
  async function signOut() {
    if (isDirty() && !(await confirmBox('Sign out with unsaved changes?', 'You have changes that have not been saved. They will be lost if you sign out.', 'Sign out anyway', true))) return;
    try { await api('POST', '/logout', {}); } catch (e) { /* cookie may already be gone */ }
    state.content = null; state.snap = ''; state.stats = null; state.messages = null; state.images = null; state.open = {};
    renderLogin('You have been signed out.', 'ok');
  }

  function renderLogin(note, kind) {
    document.title = 'Sign in · Admin Panel';
    var msg = h('div', { class: 'msg ' + (kind || 'err') + (note ? '' : ' adm-hidden'), role: 'alert', id: 'login-msg' }, note || '');
    var u = h('input', { type: 'text', id: 'lg-user', name: 'username', autocomplete: 'username', required: true, autofocus: true, spellcheck: 'false' });
    var p = h('input', { type: 'password', id: 'lg-pass', name: 'password', autocomplete: 'current-password', required: true });
    var btn = h('button', { type: 'submit', class: 'btn btn-primary' }, h('span', null, 'Sign in'));
    var timer = null;
    function say(t, k) { msg.textContent = t; msg.className = 'msg ' + (k || 'err'); }
    function lock(sec) {
      clearInterval(timer); btn.disabled = true;
      (function tick() {
        if (sec <= 0) { clearInterval(timer); btn.disabled = false; say('You can try again now.', 'ok'); return; }
        say('Too many wrong attempts. Sign-in is locked. Try again in ' + Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0') + '.', 'err'); sec -= 1;
      })();
      timer = setInterval(function () {
        if (sec <= 0) { clearInterval(timer); btn.disabled = false; say('You can try again now.', 'ok'); return; }
        say('Too many wrong attempts. Sign-in is locked. Try again in ' + Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0') + '.', 'err'); sec -= 1;
      }, 1000);
    }
    var form = h('form', { novalidate: true, onsubmit: async function (e) {
      e.preventDefault();
      if (!u.value.trim() || !p.value) return say('Enter your username and password.', 'err');
      btn.disabled = true;
      try {
        var r = await fetch('/api/login', { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u.value.trim(), password: p.value }) });
        var j = {}; try { j = await r.json(); } catch (x) { /* empty */ }
        if (r.ok && j.ok) { clearInterval(timer); p.value = ''; state.me = { username: j.username }; return start(); }
        p.value = '';
        if (r.status === 429) return lock(j.retryAfter || 300);
        if (r.status === 503) { btn.disabled = false; return say(j.error || 'The server is not ready yet.', 'err'); }
        btn.disabled = false;
        say((j.error || 'Sign in failed.') + (j.attemptsLeft !== undefined && j.attemptsLeft < 5 ? ' ' + j.attemptsLeft + ' attempt(s) left before a 5-minute lock.' : ''), 'err');
        p.focus();
      } catch (er) { btn.disabled = false; say('Cannot reach the server. Check your connection and try again.', 'err'); }
    } },
      h('div', { class: 'fld' }, h('label', { for: 'lg-user' }, 'Username'), u),
      h('div', { class: 'fld', style: 'margin-top:18px' }, h('label', { for: 'lg-pass' }, 'Password'), p),
      h('div', { style: 'margin-top:18px' }, msg), h('div', { style: 'margin-top:18px' }, btn));
    var s = state.content ? state.content.settings : null;
    root.replaceChildren(h('div', { class: 'login-wrap' }, h('div', { class: 'login-card glass' },
      h('span', { class: 'brand-mark' }, (s && s.logoInitials) || 'MH'), h('h1', null, 'Admin Panel'), h('p', { class: 'lead' }, 'Sign in to edit your website.'), form,
      h('p', { style: 'margin-top:20px;text-align:center' }, h('a', { href: '/', class: 'hint' }, '← Back to the website')))));
    u.focus();
  }

  async function start() {
    try {
      if (!state.content) {
        state.content = await api('GET', '/admin/content');
        state.snap = JSON.stringify(state.content);
      }
      applyTheme();
      await loadStats();
      var id = location.hash.replace('#', '');
      state.section = BUILD[id] ? id : 'dashboard';
      renderShell(); renderSection();
      markDirty();
    } catch (e) { if (e.status !== 401) { renderLogin(e.message, 'err'); } }
  }

  async function boot() {
    try {
      var r = await fetch('/api/me', { credentials: 'same-origin', cache: 'no-store' });
      if (r.ok) { var j = await r.json(); state.me = { username: j.username }; return start(); }
    } catch (e) { return renderLogin('Cannot reach the server. Check your connection and reload.', 'err'); }
    renderLogin();
  }
  boot();
})();
